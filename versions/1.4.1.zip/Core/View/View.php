<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\DI\Container;
use Forge\Core\Http\Response;
use RuntimeException;

final class View
{
    private static ?array $layout = null;
    private static bool $shouldSuppressLayout = false;
    private static array $sections = [];
    private static string $currentSection = "";

    public static function suppressLayout(bool $suppress = true): void
    {
        self::$shouldSuppressLayout = $suppress;
    }

    public function __construct(
        private readonly Container $container,
        private ?string $viewPath = null,
        private ?string $componentPath = null,
        private readonly ?string $module = null
    ) {
        $basePath = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 5);

        $this->viewPath = $viewPath ?? $basePath . "/app/resources/views";
        $this->componentPath = $componentPath ?? $basePath . "/app/resources/components";
    }

    public static function layout(string $name, bool $loadFromModule = false): void
    {
        if (self::$shouldSuppressLayout) {
            return;
        }
        self::$layout = [
            'name' => $name,
            'useModulePath' => $loadFromModule
        ];
    }

    public static function startSection(string $name): void
    {
        self::$currentSection = $name;
        ob_start();
    }

    public static function endSection(): void
    {
        self::$sections[self::$currentSection] = ob_get_clean();
        self::$currentSection = "";
    }

    public static function section(string $name): string
    {
        return self::$sections[$name] ?? "";
    }

    public static function component(string $name, array|object $props = [], bool $loadFromModule = false): string
    {
        return Component::render($name, $props, $loadFromModule);
    }

    public function render(string $view, array $data = []): Response
    {
        $viewContent = $this->compileView($view, $data);

        if (self::$layout) {
            $layoutName = self::$layout['name'];
            $useModulePath = self::$layout['useModulePath'];

            $layoutData = array_merge($data, ["content" => $viewContent], self::$sections);

            if ($useModulePath || str_contains($layoutName, ':')) {
                $layoutFile = $this->resolveViewFile("layouts/{$layoutName}");
                $viewContent = $this->executeFile($layoutFile, $layoutData);
            } else {
                $appViewPath = defined('BASE_PATH') ? BASE_PATH . "/app/resources/views" : $this->viewPath;
                $layoutFile = $this->resolveViewFile("layouts/{$layoutName}", $appViewPath);
                $viewContent = $this->executeFile($layoutFile, $layoutData);
            }
        }

        self::$layout = null;
        self::$shouldSuppressLayout = false;
        self::$sections = [];
        self::$currentSection = "";

        return new Response($viewContent);
    }

    private function compileView(string $view, array $data, ?string $basePath = null): string
    {
        $viewFile = $this->resolveViewFile($view, $basePath);
        return $this->executeFile($viewFile, $data);
    }

    private function resolveViewFile(string $view, ?string $basePath = null): string
    {
        if (str_contains($view, ":")) {
            [$module, $relative] = explode(":", $view, 2);
            foreach (['Resources', 'resources'] as $res) {
                $modulePath = BASE_PATH . "/modules/{$module}/src/{$res}/views/{$relative}.php";
                if (is_file($modulePath)) {
                    return $modulePath;
                }
            }
        }

        if ($this->module) {
            foreach (['Resources', 'resources'] as $res) {
                $modulePath = BASE_PATH . "/modules/{$this->module}/src/{$res}/views/{$view}.php";
                if (is_file($modulePath)) {
                    return $modulePath;
                }
            }
        }

        $basePath = $basePath ?? $this->viewPath;
        $file = "{$basePath}/{$view}.php";

        if (!is_file($file)) {
            throw new RuntimeException("View file not found: {$view} (Searched in: {$file})");
        }

        return $file;
    }

    private function executeFile(string $file, array|object $data): string
    {
        $vars = is_object($data) ? get_object_vars($data) : $data;
        extract($vars, EXTR_SKIP);

        if (is_object($data)) {
            $props = $data;
        }

        ob_start();
        include $file;
        return ob_get_clean();
    }

    public static function viewComponent(string $path, array|object $props = [], ?string $module = null): string
    {
        $view = new self(container: Container::getInstance(), module: $module);
        return $view->renderComponentView($path, $props);
    }

    public function renderComponentView(string $viewSubPath, array|object $data = []): string
    {
        $file = $this->resolveComponentFile($viewSubPath, $this->module);
        return $this->executeFile($file, $data);
    }

    private function resolveComponentFile(string $component, ?string $module = null): string
    {
        if (str_contains($component, ":")) {
            [$moduleName, $relative] = explode(":", $component, 2);
            foreach (['Resources', 'resources'] as $res) {
                $paths = [
                    BASE_PATH . "/modules/{$moduleName}/src/{$res}/components/{$relative}.php",
                    BASE_PATH . "/modules/{$moduleName}/src/{$res}/views/components/{$relative}.php",
                ];
                foreach ($paths as $file) {
                    if (is_file($file)) {
                        return $file;
                    }
                }
            }
            throw new RuntimeException("Module component template not found: {$relative} in module {$moduleName}");
        }

        if ($module) {
            foreach (['Resources', 'resources'] as $res) {
                $paths = [
                    BASE_PATH . "/modules/{$module}/src/{$res}/components/{$component}.php",
                    BASE_PATH . "/modules/{$module}/src/{$res}/views/components/{$component}.php",
                ];
                foreach ($paths as $file) {
                    if (is_file($file)) {
                        return $file;
                    }
                }
            }
        }

        $file = "{$this->componentPath}/{$component}.php";
        if (is_file($file))
            return $file;

        throw new RuntimeException("Component template not found: {$component}");
    }
}
