<?php

declare(strict_types=1);

namespace Forge\Traits;

trait HasRepositoryMetadata
{
    /**
     * Finds the entity model by its ID.
     *
     * @param int|string $id
     * @return ?\Forge\Core\Database\Model
     */
    protected function findEntityModelById(int|string $id): ?\Forge\Core\Database\Model
    {
        $entity = $this->findById($id);
        if ($entity instanceof \Forge\Core\Dto\BaseDto) {
            $modelClass = $this->modelClass;
            return $modelClass::find($id);
        }
        return $entity;
    }

    public function updateMetadata(int|string $id, string $key, mixed $value): bool
    {
        $model = $this->findEntityModelById($id);
        if (!$model) {
            return false;
        }

        if (method_exists($model, 'setMetadata')) {
            $model->setMetadata($key, $value);
            return true;
        }

        $metadata = $model->metadata ?? [];
        $metadata[$key] = $value;
        return $this->update($id, ['metadata' => $metadata]) > 0;
    }

    public function getMetadata(int|string $id, string $key, mixed $default = null): mixed
    {
        $model = $this->findEntityModelById($id);
        if (!$model) {
            return $default;
        }

        if (method_exists($model, 'getMetadata')) {
            return $model->getMetadata($key, $default);
        }

        return $model->metadata[$key] ?? $default;
    }

    public function hasMetadata(int|string $id, string $key): bool
    {
        $model = $this->findEntityModelById($id);
        if (!$model) {
            return false;
        }

        if (method_exists($model, 'hasMetadata')) {
            return $model->hasMetadata($key);
        }

        return isset($model->metadata[$key]);
    }
}
