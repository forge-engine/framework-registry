<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Migrator;
use Forge\Core\Module\Attributes\CLICommand;

#[CLICommand(name: 'migrate:rollback', description: 'Rollback database migrations')]
class MigrateRollBackCommand extends Command
{
    public function __construct(private Migrator $migrator)
    {
    }

    public function execute(array $args): int
    {
        $steps = 1;
        $preview = false;

        foreach ($args as $arg) {
            if ($arg === '--preview') {
                $preview = true;
            } elseif (is_numeric($args)) {
                $steps = (int) $arg;
            }
        }

        if ($preview) {
            $migrations = $this->migrator->previewRollback($steps);
            if (empty($migrations)) {
                $this->info('No migrations to rollback.');
            } else {
                $this->info('The following migrations would be rolled back:');
                foreach ($migrations as $migration) {
                    $this->info("- {$migration}");
                }
            }
            return 0;
        }

        $this->migrator->rollback($steps);
        $this->success("Rolled back {$steps} batch(es) successfully");
        return 0;
    }
}
