<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Seeders\SeederManager;
use Forge\Core\Module\Attributes\CLICommand;
use RuntimeException;

#[CLICommand(name: 'seed:preview', description: 'Preview all available seeders and their status.')]
class SeedPreviewCommand extends Command
{
    public function __construct(private readonly SeederManager $manager)
    {
    }

    public function execute(array $args): int
    {

        $type = null;
        $module = null;
        foreach ($args as $arg) {
            if (preg_match('/--type=([\w]+)/', $arg, $m)) {
                $type = $m[1];
            } elseif (preg_match('/--module=([\w]+)/', $arg, $m)) {
                $module = $m[1];
            }
        }

        $allSeeders = $this->manager->discoverSeeders($type, $module);
        $ranSeeders = $this->manager->getAllRanSeedersWithDetails();

        if (empty($allSeeders)) {
            $this->info("No seeders found.");
            return 0;
        }

        $this->line("");
        $this->info("Seeder Preview:");
        $tableRows = [];

        foreach ($allSeeders as $seeder) {
            $nameForDisplay = $seeder['name'];
            $source = strtoupper($seeder['source']);

            $lookupKey = $nameForDisplay . '.php';
            $details = $ranSeeders[$lookupKey] ?? null;

            $batch = $details['batch'] ?? '-';
            $ranAt = $details['ran_at'] ?? '-';

            if ($details) {
                $status = "\033[1;32mRan\033[0m";
            } else {
                $status = "\033[0;33mPending\033[0m";
            }

            $tableRows[] = [
                'NAME' => $nameForDisplay,
                'SOURCE' => $source,
                'BATCH' => $batch,
                'RAN AT' => $ranAt,
                'STATUS' => $status,
            ];
        }

        $headers = ['NAME', 'SOURCE', 'BATCH', 'RAN AT', 'STATUS'];

        $this->table($headers, $tableRows);
        $this->line("");

        return 0;
    }
}