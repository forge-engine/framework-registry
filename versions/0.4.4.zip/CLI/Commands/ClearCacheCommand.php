<?php
declare(strict_types=1);

namespace Forge\CLI\Commands;

use FilesystemIterator;
use Forge\CLI\Command;
use Forge\CLI\Traits\OutputHelper;
use Forge\Core\Module\Attributes\CLICommand;

#[CLICommand(name: 'clear:cache', description: 'Clears the application cache')]
class ClearCacheCommand extends Command
{
    use OutputHelper;

    private const string CLASS_MAP_CACHE_FILE =
        BASE_PATH . "/storage/framework/cache/class-map.php";
    private const string VIEW_CACHE_DIR = BASE_PATH . "/storage/framework/views";
    private const string APP_CACHE_DIR = BASE_PATH . "/storage/framework/cache";
    private const string MODULE_REGISTRY_FILE =
        BASE_PATH . "/engine/Core/Module/module_registry.php";

    public function execute(array $args): int
    {
        $this->clearClassMapCache();
        $this->clearViewCache();
        $this->clearGeneralCache();
        $this->resetModuleRegistry();
        $this->info("Application cache cleared successfully.");
        return 0;
    }

    private function clearClassMapCache(): void
    {
        if (file_exists(self::CLASS_MAP_CACHE_FILE)) {
            if (unlink(self::CLASS_MAP_CACHE_FILE)) {
                $this->success("Class map cache cleared successfully.");
            } else {
                $this->error("Failed to clear class map cache.");
            }
        } else {
            $this->warning("Class map cache file does not exist.");
        }
    }

    private function clearViewCache(): void
    {
        $this->clearFilesInDirRecursive(
            self::VIEW_CACHE_DIR,
            "View cache"
        );
    }

    private function clearGeneralCache(): void
    {
        $this->clearFilesInDirRecursive(
            self::APP_CACHE_DIR,
            "General application cache",
            [self::CLASS_MAP_CACHE_FILE]
        );
    }

    private function resetModuleRegistry(): void
    {
        $content = "<?php return [];";

        if (file_put_contents(self::MODULE_REGISTRY_FILE, $content) !== false) {
            $this->success("Module registry reset successfully.");
        } else {
            $this->error("Failed to reset module registry.");
        }
    }

    /**
     * Generic method to clear all files recursively within a directory,
     * excluding specified files.
     *
     * @param string $directory The directory path.
     * @param string $name The friendly name for output messages.
     * @param array $excludeFiles Array of file paths to skip.
     */
    private function clearFilesInDirRecursive(
        string $directory,
        string $name,
        array $excludeFiles = []
    ): void {
        if (!is_dir($directory)) {
            $this->warning("$name directory does not exist.");
            return;
        }

        $successCount = 0;
        $failure = false;

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator(
                $directory,
                FilesystemIterator::SKIP_DOTS
            ),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $item) {
            if ($item->isFile()) {
                $filePath = $item->getRealPath();
                if (in_array($filePath, $excludeFiles)) {
                    continue;
                }

                if (!unlink($filePath)) {
                    $this->error("Failed to clear $name file: " . $item->getFilename());
                    $failure = true;
                } else {
                    $successCount++;
                }
            }
        }

        if ($failure) {
            $this->error("Partially failed to clear $name.");
        } elseif ($successCount > 0) {
            $this->success("$name cleared successfully ($successCount files).");
        } else {
            $this->warning("$name directory is empty or only contains excluded files.");
        }
    }
}