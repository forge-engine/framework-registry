<?php
declare(strict_types=1);

namespace Forge\Core\Dto;

use Forge\Core\Dto\Attributes\Sanitize;
use ReflectionClass;
use ReflectionException;

/**
 * @template T of static
 */
abstract class BaseDto
{
    public static function fromList(array $rows): array
    {
        return array_map(static::from(...), $rows);
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }

    /**
     * @throws ReflectionException
     */
    public function sanitize(): static
    {
        $r = new ReflectionClass($this);
        $props = $r->getProperties();
        $clean = [];

        $sanAttr = $r->getAttributes(Sanitize::class)[0] ?? null;
        $toWipe = $sanAttr ? $sanAttr->newInstance()->properties : [];

        foreach ($props as $p) {
            $name = $p->getName();
            $clean[$name] = in_array($name, $toWipe, true)
                ? null
                : $p->getValue($this);
        }

        return static::from($clean);
    }

    /**
     * @throws ReflectionException
     */
    public static function from(array $data): static
    {
        $r = new ReflectionClass(static::class);
        $args = [];

        foreach ($r->getConstructor()->getParameters() as $p) {
            $name = $p->getName();
            $args[$name] = $data[$name] ?? $p->getDefaultValue();
        }

        return $r->newInstanceArgs($args);
    }
}