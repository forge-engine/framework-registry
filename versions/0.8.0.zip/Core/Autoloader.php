<?php
declare(strict_types=1);

namespace Forge\Core;

use Forge\Exceptions\ClassNotFoundException;
use SplFileInfo;
use const PHP_SAPI;

final class Autoloader
{
    /** @var array<string,string>  namespace prefix → base directory (normalised, no trailing slash) */
    private static array $map = [];

    /** @var bool  set to true once App\Modules\ForgeTesting\TestCase is loaded */
    private static bool $testCaseLoaded = false;

    /** @var SplFileInfo[]  fast file-existence cache (APCu in web, array in CLI) */
    private static array $cache = [];

    /** @var int  maximum number of entries in the in-process cache */
    private static int $maxCacheSize = 8_000;

    public static function register(): void
    {
        self::buildMap();
        spl_autoload_register([self::class, 'load'], true, true);
    }

    private static function buildMap(): void
    {
        self::addPath('app', BASE_PATH . '/app');
        self::addPath('forge', BASE_PATH . '/engine');
        self::addPath('modules', BASE_PATH . '/modules');
    }

    public static function addPath(string $namespace, string $path): void
    {
        $ns = strtolower(trim($namespace, '\\'));
        $dir = rtrim(realpath($path), \DIRECTORY_SEPARATOR);
        if ($dir === false || !is_dir($dir)) {
            throw new \InvalidArgumentException("Directory $path does not exist");
        }
        self::$map[$ns] = $dir;
    }

    public static function getPaths(): array
    {
        return self::$map;
    }

    /**
     * PSR-4 autoload callback.
     * @throws ClassNotFoundException
     */
    private static function load(string $class): void
    {
        $class = ltrim($class, '\\');

        if (!self::$testCaseLoaded && str_ends_with($class, 'Test')) {
            return;
        }

        $lower = strtolower($class);

        foreach (self::$map as $prefix => $dir) {
            if (!str_starts_with($lower, $prefix)) {
                continue;
            }
            $relative = substr($class, strlen($prefix));
            $relative = str_replace('\\', \DIRECTORY_SEPARATOR, $relative) . '.php';
            $file = $dir . \DIRECTORY_SEPARATOR . ltrim($relative, \DIRECTORY_SEPARATOR);

            if (isset(self::$cache[$file])) {
                /** @var SplFileInfo $info */
                $info = self::$cache[$file];
                if ($info->isFile()) {
                    self::requireFile($info->getRealPath(), $class);
                    return;
                }
                unset(self::$cache[$file]);
            }

            if (is_file($file)) {
                self::cache($file);
                self::requireFile($file, $class);
                return;
            }
        }

        if (!str_ends_with($class, 'Test') || self::$testCaseLoaded) {
            throw new ClassNotFoundException($class);
        }
    }

    /** Require the file in a way that survives concurrent includes. */
    private static function requireFile(string $realPath, string $class): void
    {
        /** @psalm-suppress UnresolvableInclude */
        require $realPath;

        if ($class === 'App\\Modules\\ForgeTesting\\TestCase') {
            self::$testCaseLoaded = true;
        }
    }

    private static function cache(string $path): void
    {
        if (PHP_SAPI === 'cli' || !function_exists('apcu_store')) {
            if (count(self::$cache) >= self::$maxCacheSize) {
                self::$cache = [];
            }
            self::$cache[$path] = new SplFileInfo($path);
        } else {
            $key = 'forge:al:' . md5($path);
            if (apcu_exists($key)) {
                return;
            }
            apcu_store($key, new SplFileInfo($path), 3600);
            self::$cache[$path] = new SplFileInfo($path);
        }
    }
}