<?php
declare(strict_types=1);

namespace Forge\tests\Engine;

use App\Modules\ForgeTesting\Attributes\Group;
use App\Modules\ForgeTesting\Attributes\Test;
use App\Modules\ForgeTesting\TestCase;
use Forge\Core\Dto\BaseDto;
use Forge\tests\Engine\Fixtures\DummyDto;

#[Group('dto')]
final class BaseDtoEngineTest extends TestCase
{
    #[Test("Sanitize removes specified properties")]
    public function sanitize_removes_specified_properties(): void
    {
        $dto = new DummyDto([
            'username' => 'alice',
            'secret' => '123',
            'password' => 'abc',
        ]);

        $sanitized = $dto->sanitize();

        $this->assertNull($sanitized->secret);
        $this->assertNull($sanitized->password);
        $this->assertEquals('alice', $sanitized->username);
    }

    #[Test("Sanitize leaves properties untouched if not listed")]
    public function sanitize_keeps_other_properties(): void
    {
        $dto = new DummyDto([
            'username' => 'bob',
            'secret' => 'hidden',
            'password' => '1234',
        ]);

        $sanitized = $dto->sanitize();

        $this->assertEquals('bob', $sanitized->username);
    }

    #[Test("Sanitize works when no Sanitize attribute is present")]
    public function sanitize_no_attribute_keeps_all_properties(): void
    {
        $dto = new class(['foo' => 'bar', 'baz' => 'qux']) extends BaseDto {
            public string $foo;
            public string $baz;

            public function __construct(array $data = [])
            {
                $this->foo = $data['foo'] ?? '';
                $this->baz = $data['baz'] ?? '';
            }
        };

        $sanitized = $dto->sanitize();

        $this->assertEquals('bar', $sanitized->foo);
        $this->assertEquals('qux', $sanitized->baz);
    }
}