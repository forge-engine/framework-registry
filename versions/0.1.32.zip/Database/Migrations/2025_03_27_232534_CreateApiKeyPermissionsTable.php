<?php

declare(strict_types=1);

use Forge\Core\Database\Attributes\Table;
use Forge\Core\Database\Attributes\Column;
use Forge\Core\Database\Attributes\Relations\BelongsTo;
use Forge\Core\Database\Enums\ColumnType;
use Forge\Core\Database\Migrations\Migration;

#[Table(name: 'api_key_permissions')]
#[BelongsTo(foreignKey:'api_key_id', onDelete: 'CASCADE')]
#[BelongsTo(foreignKey:'permission_id', onDelete: 'CASCADE')]
class CreateApiKeyPermissionsTable extends Migration
{
    #[Column(name: 'id', type: ColumnType::INTEGER, primaryKey: true, autoIncrement: true)]
    public readonly int $id;

    #[Column(name: 'api_key_id', type: ColumnType::INTEGER, nullable: false)]
    public readonly int $api_key_id;

    #[Column(name: 'permission_id', type: ColumnType::INTEGER, nullable: true)]
    public readonly int $permission_id;




    // $this->queryBuilder->setTable('api_key_permissions')
        //     ->createTable(
        //         'api_key_permissions',
        //         [
        //             'id' => 'INTEGER PRIMARY KEY AUTOINCREMENT',
        //             'api_key_id' => 'INTEGER NOT NULL',
        //             'permission_id' => 'INTEGER',
        //         ],
        //         [
        //             'CONSTRAINT fk_api_key_id FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE CASCADE',
        //             'CONSTRAINT fk_permission_id FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE',
        //         ]
        //     );
        // $this->execute($this->queryBuilder->getSql());
}
