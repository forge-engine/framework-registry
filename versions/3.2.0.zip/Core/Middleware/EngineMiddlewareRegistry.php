<?php

declare(strict_types=1);

namespace Forge\Core\Middleware;

/**
 * Registry of all engine-provided middlewares with their default configurations.
 * This helps users discover available middlewares and understand their default groups and orders.
 */
final class EngineMiddlewareRegistry
{
  /**
   * Get all engine-provided middlewares with their metadata.
   *
   * @return array<string, array{group: string, order: int, enabled: bool, description: string, class: string}>
   */
  public static function getMiddlewares(): array
  {
    return [
      // Global middlewares
      \Forge\Core\Http\Middlewares\RateLimitMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\RateLimitMiddleware::class,
        'group' => 'global',
        'order' => 0,
        'enabled' => true,
        'description' => 'Rate limiting middleware to prevent abuse',
      ],
      \Forge\Core\Http\Middlewares\CircuitBreakerMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\CircuitBreakerMiddleware::class,
        'group' => 'global',
        'order' => 1,
        'enabled' => true,
        'description' => 'Circuit breaker pattern for fault tolerance',
      ],
      \Forge\Core\Http\Middlewares\CorsMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\CorsMiddleware::class,
        'group' => 'global',
        'order' => 2,
        'enabled' => true,
        'description' => 'Cross-Origin Resource Sharing (CORS) headers',
      ],
      \Forge\Core\Http\Middlewares\SanitizeInputMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\SanitizeInputMiddleware::class,
        'group' => 'global',
        'order' => 3,
        'enabled' => false, // Disabled by default
        'description' => 'Sanitizes input data to prevent XSS attacks',
      ],
      \Forge\Core\Http\Middlewares\CompressionMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\CompressionMiddleware::class,
        'group' => 'global',
        'order' => 4,
        'enabled' => true,
        'description' => 'Compresses response content (gzip, deflate)',
      ],

      // Web middlewares
      \Forge\Core\Http\Middlewares\SessionMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\SessionMiddleware::class,
        'group' => 'web',
        'order' => 0,
        'enabled' => true,
        'description' => 'Session management for web requests',
      ],
      \Forge\Core\Http\Middlewares\CsrfMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\CsrfMiddleware::class,
        'group' => 'web',
        'order' => 1,
        'enabled' => true,
        'description' => 'CSRF protection for web forms',
      ],
      \Forge\Core\Http\Middlewares\RelaxSecurityHeadersMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\RelaxSecurityHeadersMiddleware::class,
        'group' => 'web',
        'order' => 3,
        'enabled' => true,
        'description' => 'Security headers (CSP, X-Frame-Options, etc.)',
      ],

      // API middlewares
      \Forge\Core\Http\Middlewares\IpWhiteListMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\IpWhiteListMiddleware::class,
        'group' => 'api',
        'order' => 0,
        'enabled' => true,
        'description' => 'IP whitelist filtering for API endpoints',
      ],
      \Forge\Core\Http\Middlewares\ApiKeyMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\ApiKeyMiddleware::class,
        'group' => 'api',
        'order' => 1,
        'enabled' => true,
        'description' => 'API key authentication',
      ],
      \Forge\Core\Http\Middlewares\CookieMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\CookieMiddleware::class,
        'group' => 'api',
        'order' => 2,
        'enabled' => true,
        'description' => 'Cookie handling for API requests',
      ],
      \Forge\Core\Http\Middlewares\ApiMiddleware::class => [
        'class' => \Forge\Core\Http\Middlewares\ApiMiddleware::class,
        'group' => 'api',
        'order' => 2,
        'enabled' => true,
        'description' => 'API response formatting (XML, CSV, HTML, plain text)',
      ],
    ];
  }

  /**
   * Get middlewares by group.
   *
   * @param string $group The middleware group (e.g., 'global', 'web', 'api')
   * @return array<string, array{group: string, order: int, enabled: bool, description: string, class: string}>
   */
  public static function getMiddlewaresByGroup(string $group): array
  {
    return array_filter(
      self::getMiddlewares(),
      fn($middleware) => $middleware['group'] === $group
    );
  }

  /**
   * Get all middleware class names.
   *
   * @return array<string>
   */
  public static function getMiddlewareClasses(): array
  {
    return array_keys(self::getMiddlewares());
  }

  /**
   * Check if a class is an engine middleware.
   *
   * @param string $className The middleware class name
   * @return bool True if it's an engine middleware
   */
  public static function isEngineMiddleware(string $className): bool
  {
    return isset(self::getMiddlewares()[$className]);
  }
}
