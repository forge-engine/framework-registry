<?php

declare(strict_types=1);

namespace Forge\Core\Http\Middlewares;

use Forge\CLI\Traits\OutputHelper;
use Forge\Core\Config\Config;
use Forge\Core\Config\Environment;
use Forge\Core\Contracts\Database\QueryBuilderInterface;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Middleware\Attributes\RegisterMiddleware;
use Forge\Traits\ResponseHelper;

#[Service]
#[RegisterMiddleware(group: "global", order: 0, allowDuplicate: false, overrideClass: null, enabled: true)]
class RateLimitMiddleware extends Middleware
{
  use OutputHelper;
  use ResponseHelper;

  public function __construct(
    private readonly Config $config,
    private readonly QueryBuilderInterface $queryBuilder
  ) {
  }

  public function handle(Request $request, callable $next): Response
  {
    $enabled = $this->config->get('security.rate_limit.enabled', true);
    if (!$enabled) {
      return $next($request);
    }

    $isDev = Environment::getInstance()->isDevelopment();
    $path = $request->getPath();

    if ($isDev && str_contains($path, 'tailwind-watch.php')) {
      return $next($request);
    }

    $disableInDev = $this->config->get('security.rate_limit.disable_in_dev', true);
    if ($isDev && $disableInDev) {
      return $next($request);
    }

    if (($_ENV['RATE_LIMIT_ENABLED'] ?? 'true') === 'false') {
      return $next($request);
    }

    if (in_array($path, ['/health', '/healthz', '/ping', '/status'], true)) {
      return $next($request);
    }

    $clientIp = $request->getClientIp();

    $bypassIps = $this->config->get('security.rate_limit.bypass_ips', ['127.0.0.1', '::1', 'localhost']);
    if (in_array($clientIp, $bypassIps, true)) {
      return $next($request);
    }

    $queryBuilder = clone $this->queryBuilder;

    $maxRequests = $this->config->get('security.rate_limit.max_requests', 100);
    $timeWindow = $this->config->get('security.rate_limit.time_window', 60);
    $table = 'rate_limits';
    $now = time();
    $nowFormatted = date('Y-m-d H:i:s');

    $updated = $this->tryAtomicUpdate($queryBuilder, $table, $clientIp, $maxRequests, $timeWindow, $now, $nowFormatted, $clientIp);

    if ($updated === 'rate_limited') {
      return $this->createErrorResponse($request);
    }

    if ($updated === false) {
      try {
        $this->createNewRateLimitRecord($clientIp, $queryBuilder, $nowFormatted);
      } catch (\Throwable $e) {
        $updated = $this->tryAtomicUpdate($queryBuilder, $table, $clientIp, $maxRequests, $timeWindow, $now, $nowFormatted, $clientIp);
        if ($updated === 'rate_limited') {
          return $this->createErrorResponse($request);
        }
      }
    }

    return $next($request);
  }

  /**
   * Attempts to atomically update the rate limit record.
   * Returns 'rate_limited' if limit exceeded, true if updated, false if no record found.
   */
  private function tryAtomicUpdate(
    QueryBuilderInterface $queryBuilder,
    string $table,
    string $clientIp,
    int $maxRequests,
    int $timeWindow,
    int $now,
    string $nowFormatted,
    string $logIp
  ): string|bool {
    $record = $queryBuilder->reset()
      ->setTable($table)
      ->select('*')
      ->where('ip_address', '=', $clientIp)
      ->first();

    if (!$record) {
      return false;
    }

    $timeDiff = $now - strtotime($record['last_request']);

    if ($timeDiff >= $timeWindow) {
      $queryBuilder->reset()
        ->setTable($table)
        ->where('id', '=', $record['id'])
        ->update([
          'request_count' => 1,
          'last_request' => $nowFormatted,
        ]);
      return true;
    }

    if ($record['request_count'] >= $maxRequests) {
      if (function_exists('error_log')) {
        error_log(sprintf(
          '[RateLimit] IP %s exceeded limit: %d/%d requests in %d seconds',
          $logIp,
          $record['request_count'],
          $maxRequests,
          $timeWindow
        ));
      }
      return 'rate_limited';
    }

    $queryBuilder->reset()
      ->setTable($table)
      ->where('id', '=', $record['id'])
      ->where('request_count', '<', $maxRequests)
      ->update([
        'request_count' => $record['request_count'] + 1,
        'last_request' => $nowFormatted,
      ]);

    return true;
  }

  private function createNewRateLimitRecord(string $clientIp, QueryBuilderInterface $queryBuilder, string $nowFormatted): void
  {
    $queryBuilder->reset()
      ->setTable('rate_limits')
      ->insert([
        'ip_address' => $clientIp,
        'request_count' => 1,
        'last_request' => $nowFormatted,
      ]);
  }
}
