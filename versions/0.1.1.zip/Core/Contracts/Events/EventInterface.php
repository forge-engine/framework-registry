<?php

namespace Forge\Core\Contracts\Events;

interface EventInterface
{
    //
}