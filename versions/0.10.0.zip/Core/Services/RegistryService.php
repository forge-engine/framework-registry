<?php

declare(strict_types=1);

namespace Forge\Core\Services;

use Forge\Core\Config\Environment;
use Forge\Core\DI\Attributes\Service;

#[Service]
final class RegistryService
{
    public function __construct(
        private readonly GitService $gitService
    ) {}
    
    private function getRegistryConfigData(): array
    {
        $configPath = BASE_PATH . '/config/registry.php';
        if (file_exists($configPath)) {
            return require $configPath;
        }
        return [];
    }
    
    public function isRegistryConfigured(string $type): bool
    {
        $defaultPath = BASE_PATH . "/{$type}-registry";
        
        $config = $this->getRegistryConfigData();
        $registryConfig = $config[$type] ?? null;
        
        if ($registryConfig && isset($registryConfig['path'])) {
            $path = $registryConfig['path'];
        } else {
            $path = $defaultPath;
        }
        
        if (!is_dir($path)) {
            return false;
        }
        
        if (!$this->gitService->isGitRepository($path)) {
            return false;
        }
        
        return true;
    }
    
    public function isRegistryDirectoryInitialized(string $type): bool
    {
        $defaultPath = BASE_PATH . "/{$type}-registry";
        
        if (!is_dir($defaultPath)) {
            return false;
        }
        
        return $this->gitService->isGitRepository($defaultPath);
    }
    
    public function validateRegistry(string $type): bool
    {
        if (!$this->isRegistryConfigured($type) && !$this->isRegistryDirectoryInitialized($type)) {
            return false;
        }
        
        $path = $this->getRegistryPath($type);
        
        if ($type === 'modules') {
            return file_exists($path . '/modules.json');
        } else {
            return file_exists($path . '/forge.json');
        }
    }
    
    public function getRegistryPath(string $type): string
    {
        $config = $this->getRegistryConfigData();
        $registryConfig = $config[$type] ?? [];
        if (isset($registryConfig['path'])) {
            return $registryConfig['path'];
        }
        
        return BASE_PATH . "/{$type}-registry";
    }
    
    public function getRegistryConfig(string $type): ?array
    {
        $config = $this->getRegistryConfigData();
        return $config[$type] ?? null;
    }
    
    public function initializeRegistry(
        string $type,
        string $url,
        string $branch,
        bool $isPrivate
    ): void {
        $path = BASE_PATH . "/{$type}-registry";
        
        if (!is_dir($path)) {
            mkdir($path, 0755, true);
        }
        
        $this->createInitialStructure($type, $path);
        
        if (!$this->gitService->isGitRepository($path)) {
            $this->gitService->init($path);
        }
        
        $this->gitService->setRemote($path, 'origin', $url);
        
        $env = Environment::getInstance();
        $token = $isPrivate ? $env->get('GITHUB_TOKEN') : null;
        if ($token) {
            $this->gitService->setAuth($path, $token);
        }
        
        $this->gitService->addAll($path);
        $this->gitService->commit($path, 'Initial registry structure');
        
        if ($token) {
            $this->gitService->push($path, $branch, $token);
        }
        
        $this->saveConfig($type, $url, $branch, $isPrivate, $path);
    }
    
    private function createInitialStructure(string $type, string $path): void
    {
        if ($type === 'framework') {
            $this->createFrameworkStructure($path);
        } else {
            $this->createModulesStructure($path);
        }
    }
    
    private function createFrameworkStructure(string $path): void
    {
        if (!is_dir($path . '/versions')) {
            mkdir($path . '/versions', 0755, true);
        }
        
        if (!file_exists($path . '/forge.json')) {
            $manifest = [
                'name' => 'forge-engine/framework',
                'version' => '0.1.0',
                'manifest_version' => '1.0',
                'description' => 'Forge PHP Framework - Core Engine',
                'homepage' => 'https://forge-engine.github.io/',
                'repository' => '',
                'require' => [
                    'php' => '>=8.3'
                ],
                'authors' => [],
                'versions' => [
                    'latest' => '0.1.0'
                ]
            ];
            file_put_contents($path . '/forge.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
        
        if (!file_exists($path . '/README.md')) {
            file_put_contents($path . '/README.md', "# Framework Registry\n\nFramework version registry.\n");
        }
        
        if (!file_exists($path . '/LICENSE')) {
            file_put_contents($path . '/LICENSE', "MIT License\n");
        }
    }
    
    private function createModulesStructure(string $path): void
    {
        if (!is_dir($path . '/modules')) {
            mkdir($path . '/modules', 0755, true);
        }
        
        if (!file_exists($path . '/modules.json')) {
            file_put_contents($path . '/modules.json', "{\n}\n");
        }
        
        if (!file_exists($path . '/README.md')) {
            file_put_contents($path . '/README.md', "# Modules Registry\n\nModule version registry.\n");
        }
        
        if (!file_exists($path . '/CHANGELOG.md')) {
            file_put_contents($path . '/CHANGELOG.md', "# Changelog\n\nAll notable changes to this registry will be documented in this file.\n");
        }
        
        if (!file_exists($path . '/LICENSE')) {
            file_put_contents($path . '/LICENSE', "MIT License\n");
        }
    }
    
    private function saveConfig(string $type, string $url, string $branch, bool $isPrivate, string $path): void
    {
        $configPath = BASE_PATH . '/config/registry.php';
        $config = [];
        
        if (file_exists($configPath)) {
            $config = require $configPath;
        }
        
        $config[$type] = [
            'url' => $url,
            'branch' => $branch,
            'private' => $isPrivate,
            'path' => $path,
        ];
        
        $content = "<?php\n\nreturn " . var_export($config, true) . ";\n";
        file_put_contents($configPath, $content);
    }
}

