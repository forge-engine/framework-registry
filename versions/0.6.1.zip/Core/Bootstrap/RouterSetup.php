<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\Core\DI\Container;
use Forge\Core\Middleware\MiddlewareLoader;
use Forge\Core\Routing\ControllerLoader;
use Forge\Core\Routing\Router;
use Forge\Exceptions\MissingServiceException;
use ReflectionException;

final class RouterSetup
{
    /**
     * @throws ReflectionException|MissingServiceException
     */
    public static function setup(Container $container): Router
    {
        return self::initRouter($container);
    }

    /**
     * Initializes the router, loads controllers, and prepares middleware.
     *
     * @throws ReflectionException|MissingServiceException
     */
    private static function initRouter(Container $container): Router
    {
        $controllerDirs = [
            BASE_PATH . "/app/Controllers",
            ...glob(BASE_PATH . "/modules/*/src/Controllers", GLOB_ONLYDIR)
        ];

        $loader = new ControllerLoader($container, $controllerDirs);
        $controllers = $loader->registerControllers();

        /** @var MiddlewareLoader $middlewareLoader */
        $middlewareLoader = $container->make(MiddlewareLoader::class);
        $autoLoadedMap = $middlewareLoader->load();

        $appMiddlewareConfigFile = BASE_PATH . "/config/middleware.php";
        $appMiddlewareConfig = [];
        if (file_exists($appMiddlewareConfigFile)) {
            $appMiddlewareConfig = require $appMiddlewareConfigFile;
            $appMiddlewareConfig = is_array($appMiddlewareConfig) ? $appMiddlewareConfig : [];
        }

        $finalMiddlewareConfig = $appMiddlewareConfig;

        foreach ($autoLoadedMap as $group => $middlewareData) {
            if (!isset($finalMiddlewareConfig[$group]) || !is_array($finalMiddlewareConfig[$group])) {
                $finalMiddlewareConfig[$group] = [];
            }

            $currentGroup = array_flip($finalMiddlewareConfig[$group]);

            foreach ($middlewareData as $item) {
                $autoClass = $item['class'];
                $overrideClass = $item['overrideClass'];

                if ($overrideClass) {
                    unset($currentGroup[$overrideClass]);
                }

                $currentGroup[$autoClass] = true;
            }

            $finalMiddlewareConfig[$group] = array_keys($currentGroup);
        }

        $router = Router::init($container, $finalMiddlewareConfig);

        foreach ($controllers as $controller) {
            $router->registerControllers($controller);
        }

        return $router;
    }
}
