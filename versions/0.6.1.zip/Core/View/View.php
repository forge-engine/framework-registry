<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\Bootstrap\Bootstrap;
use Forge\Core\DI\Container;
use Forge\Core\Http\Response;

final class View
{
    private static ?array $layout = null;
    private static array $sections = [];
    private static string $currentSection = "";
    private static array $cache = [];

    public function __construct(
        private Container $container,
        private ?string $viewPath = null,
        private ?string $componentPath = null,
        private ?string $cachePath = null,
        private ?string   $module = null
    ) {
        $this->viewPath = $viewPath ?? BASE_PATH . "/app/resources/views";
        $this->componentPath = $componentPath ?? BASE_PATH . "/app/resources/views/components";
        $this->cachePath = $cachePath ?? BASE_PATH . "/storage/framework/views";

        if (!is_dir($this->cachePath)) {
            mkdir($this->cachePath, 0755, true);
        }
    }

    public function render(string $view, array $data = []): Response
    {
        $this->ensureRequestCollectorExist($view, $data);

        $viewContent = $this->compileView($view, $data);

        if (self::$layout) {
            $layoutName = self::$layout['name'];
            $useModulePath = self::$layout['useModulePath'];
            $layoutData = array_merge($data, ["content" => $viewContent]);
            $viewContent = $this->compileLayout($layoutName, $useModulePath, $layoutData);
        }
        self::$layout = null;
        return new Response($viewContent);
    }

    private function compileView(string $view, array $data): string
    {
        $viewFile = "{$this->viewPath}/{$view}.php";
        $cacheFile = "{$this->cachePath}/" . md5($view) . ".php";

        if ($this->shouldCompile($viewFile, $cacheFile)) {
            $content = $this->compile(file_get_contents($viewFile));
            file_put_contents($cacheFile, $content);
        }

        extract($data);
        ob_start();
        include $cacheFile;
        $content = ob_get_clean();
        return $this->escape($content);
    }

    private function compileLayout(string $layoutName, bool $useModulePath, array $data): string
    {
        if ($useModulePath) {
            return $this->compileView("layouts/{$layoutName}", $data);
        }

        $appView = new self(
            $this->container,
            BASE_PATH . "/app/resources/views",
            BASE_PATH . "/app/resources/views/components",
            $this->cachePath,
            null
        );

        return $appView->compileView("layouts/{$layoutName}", $data);
    }

    private function escape(string $content): string
    {
        return preg_replace_callback('/<\?=\s*(.+?)\s*\?>/', function ($matches) {
            $expression = $matches[1];
            if (str_contains($expression, 'raw(')) {
                return $matches[0];
            }
            return "<?= htmlspecialchars({$expression}, ENT_QUOTES, 'UTF-8') ?>";
        }, $content);
    }

    public function renderComponent(string $viewPath, array|object $data = []): string
    {
        return $this->compileComponent($viewPath, $data);
    }

    private function compileComponent(string $view, array|object $data): string
    {
        $viewFile = "{$this->componentPath}/{$view}.php";
        $cacheFile = "{$this->cachePath}/" . md5($view) . ".php";

        if ($this->shouldCompile($viewFile, $cacheFile)) {
            $content = $this->compile(file_get_contents($viewFile));
            file_put_contents($cacheFile, $content);
        }

        if (is_object($data)) {
            $vars = get_object_vars($data);
        } else {
            $vars = $data;
        }

        if (is_array($vars)) {
            extract($vars, EXTR_SKIP);
        }

        ob_start();
        include $cacheFile;
        $content = ob_get_clean();

        return $this->escape($content);
    }

    private function shouldCompile(string $viewFile, string $cacheFile): bool
    {
        if (!Bootstrap::shouldCacheViews()) {
            return true;
        }
        return !file_exists($cacheFile) ||
            filemtime($viewFile) > filemtime($cacheFile);
    }

    private function compile(string $content): string
    {
        return $content;
    }

    public static function layout(string $name, bool $loadFromModule = false): void
    {
        self::$layout = [
            'name' => $name,
            'useModulePath' => $loadFromModule
        ];
    }

    public static function startSection(string $name): void
    {
        self::$currentSection = $name;
        ob_start();
    }

    public static function endSection(): void
    {
        self::$sections[self::$currentSection] = ob_get_clean();
        self::$currentSection = "";
    }

    public static function section(string $name): string
    {
        return self::$sections[$name] ?? "";
    }

    /**
     * Render a component.
     *
     * @param string $name
     * @param array $props
     * @return string
     */
    public static function component(string $name, array|object $props = [], bool $loadFromModule = false): string
    {
        return Component::render($name, $props, $loadFromModule);
    }

    private function ensureRequestCollectorExist(string $view, array $data): void
    {
        $requestCollectorFile  = BASE_PATH . '/modules/ForgeDebugBar/src/ForgeMultiTenantModule.php';
        $requestCollectorReady =
            is_file($requestCollectorFile)
            && class_exists(\App\Modules\ForgeDebugbar\Collectors\RequestCollector::class);
        if ($requestCollectorReady) {
            collect_view_data($view, $data);
        }
    }
}
