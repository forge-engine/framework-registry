<?php

declare(strict_types=1);

namespace Forge\Core\Module\ModuleLoader;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\DI\Container;
use Forge\Core\Module\Attributes\Provides;
use Forge\Traits\NamespaceHelper;
use ReflectionClass;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class RegisterModuleProvides
{
  use NamespaceHelper;

  public function __construct(private readonly Container $container, private readonly ReflectionClass $reflectionClass)
  {
  }

  public function init(): void
  {
    $this->initModuleProvides();
    $this->initServiceProvides();
  }

  /**
   * Scan the module class itself for #[Provides] attributes.
   */
  private function initModuleProvides(): void
  {
    foreach ($this->reflectionClass->getAttributes(Provides::class) as $attribute) {
      $provideInstance = $attribute->newInstance();
      $this->container->bind($provideInstance->interface, $this->reflectionClass->getName());
    }
  }

  /**
   * Scan service classes within the module for #[Provides] attributes.
   * This ensures that services with #[Provides] attributes are automatically
   * registered, similar to how RegisterModuleService works.
   */
  private function initServiceProvides(): void
  {
    $moduleNamespace = $this->reflectionClass->getNamespaceName();
    $modulePath = dirname($this->reflectionClass->getFileName());

    $directoryIterator = new RecursiveDirectoryIterator($modulePath);
    $iterator = new RecursiveIteratorIterator($directoryIterator);

    foreach ($iterator as $file) {
      if ($file->isFile() && $file->getExtension() === 'php') {
        $filePath = $file->getRealPath();
        $fileNamespace = $this->getNamespaceFromFile($filePath, BASE_PATH);
        if ($fileNamespace !== null && str_starts_with($fileNamespace, $moduleNamespace)) {
          $className = $fileNamespace . '\\' . pathinfo($file->getFilename(), PATHINFO_FILENAME);

          // Load the class file if it hasn't been loaded yet
          if (!class_exists($className, false)) {
            if (file_exists($filePath)) {
              try {
                require_once $filePath;
              } catch (\Exception $e) {
                continue;
              }
            }
          }

          if (!class_exists($className)) {
            continue;
          }

          try {
            $classReflection = new ReflectionClass($className);
            if ($classReflection->getAttributes(Service::class)) {
              foreach ($classReflection->getAttributes(Provides::class) as $attribute) {
                $provideInstance = $attribute->newInstance();
                $this->container->bind($provideInstance->interface, $className);
              }
            }
          } catch (\ReflectionException $e) {
            continue;
          }
        }
      }
    }
  }
}
