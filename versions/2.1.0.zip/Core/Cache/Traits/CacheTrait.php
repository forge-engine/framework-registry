<?php

declare(strict_types=1);

namespace Forge\Core\Cache\Traits;

trait CacheTrait
{
    private function handleData(mixed $raw): mixed
    {
        if ($raw === null) {
            return null;
        }

        $payload = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);

        if (!isset($payload['d'])) {
            return null;
        }

        if (($payload['c'] ?? null) === null || !class_exists($payload['c'])) {
            return $payload['d'];
        }

        $class = $payload['c'];
        return new $class($payload['d']);
    }
}
