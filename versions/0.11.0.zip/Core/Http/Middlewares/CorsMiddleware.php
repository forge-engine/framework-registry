<?php

namespace Forge\Core\Http\Middlewares;

use Forge\Core\Config\Config;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Middleware\Attributes\RegisterMiddleware;
use Forge\Exceptions\InvalidMiddlewareResponse;
use Forge\Traits\ResponseHelper;

#[Service]
#[RegisterMiddleware(group: 'global', order: 2, allowDuplicate: true, enabled: true)]
class CorsMiddleware extends Middleware
{
    use ResponseHelper;

    public function __construct(private readonly Config $config)
    {
    }

    /**
     * @throws InvalidMiddlewareResponse
     */
    public function handle(Request $request, callable $next): Response
    {
        $allowedOrigins = $this->config->get('app.cors.allowed_origins');
        $allowedMethods = $this->config->get('app.cors.allowed_methods');
        $allowedHeaders = $this->config->get('app.cors.allowed_headers');

        $origin = $request->getHeader("Origin");
        $requestMethod = $request->getMethod();
        $requestHeaders = $request->getHeader("Access-Control-Request-Headers");

        if ($origin !== null && !in_array($origin, $allowedOrigins)) {
            return $this->createResponse($request, 'Origin not allowed', 403);
        }

        if (!in_array($requestMethod, $allowedMethods)) {
            return $this->createResponse($request, 'Method not allowed', 403);
        }

        if ($requestMethod === "OPTIONS") {
            if ($requestHeaders !== null) {
                $requestedHeaders = array_map('trim', explode(',', $requestHeaders));
                foreach ($requestedHeaders as $header) {
                    if (!in_array($header, $allowedHeaders)) {
                        return $this->createResponse($request, 'Header not allowed', 403);
                    }
                }
            }
        }

        $response = $next($request);

        if (!$response instanceof Response) {
            throw new InvalidMiddlewareResponse();
        }

        if ($origin === null) {
            $response->setHeader("Access-Control-Allow-Origin", $allowedOrigins[0] ?? "*");
        } else {
            $response->setHeader("Access-Control-Allow-Origin", $origin);
        }

        $response->setHeader("Access-Control-Allow-Methods", implode(", ", $allowedMethods));
        $response->setHeader("Access-Control-Allow-Headers", implode(", ", $allowedHeaders));
        $response->setHeader("Access-Control-Allow-Credentials", "true");
        $response->setHeader("Access-Control-Max-Age", "86400");

        return $response;
    }
}
