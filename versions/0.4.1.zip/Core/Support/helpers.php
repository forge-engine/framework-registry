<?php

declare(strict_types=1);

use App\Modules\ForgeDebugbar\Collectors\TimelineCollector;
use App\Modules\ForgeWire\Core\Hydrator;
use Forge\Core\Config\Environment;
use Forge\Core\DI\Container;
use Forge\Core\Services\TokenManager;
use Forge\Core\View\View;
use Forge\Core\Config\Config;

use Forge\Exceptions\MissingServiceException;

if (!function_exists("env")) {
    /**
     * Get environment value by key.
     *
     * @return mixed
     */
    function env(string $key, mixed $default = null): mixed
    {
        return Environment::getInstance()->get($key) ?? $default;
    }
}


if (!function_exists("cache")) {
    /**
     * Get cache data by key.
     *
     * @return mixed
     */
    function cache(string $key, mixed $value = null, ?int $ttl = null): mixed
    {
        $cache = \Forge\Core\DI\Container::getInstance()->make(
            \Forge\Core\Cache\CacheManager::class,
        );

        if (func_num_args() === 1) {
            return $cache->get($key);
        }

        $cache->set($key, $value, $ttl);
        return $value;
    }
}

if (!function_exists("config")) {
    /**
     * Get the config value by key.
     * @return mixed
     * @throws MissingServiceException
     */
    function config(string $key, mixed $default = null): mixed
    {
        /** @var Config $config */
        $config = Container::getInstance()->make(Config::class);
        return $config->get($key, $default);
    }
}

if (!function_exists("request_host")) {
    /**
     * Get the current request host (domain + port if available).
     *
     */
    function request_host(): string
    {
        $host = $_SERVER["HTTP_HOST"] ?? "localhost";
        return strtolower(trim($host));
    }
}

if (!function_exists("get_data")) {
    /**
     * Get an item from an array or object using dot notation.
     *
     * @param mixed $target The array or object to retrieve from.
     * @param string $key The key, in dot notation (e.g., 'user.address.street').
     * @param mixed $default The default value to return if the key is not found.
     * @return mixed
     */
    function data_get(mixed $target, string $key, mixed $default = null): mixed
    {
        if (empty($key)) {
            return $target;
        }

        $keys = explode(".", $key);
        $current = $target;
        foreach ($keys as $segment) {
            if (is_array($current) && array_key_exists($segment, $current)) {
                $current = $current[$segment];
            } elseif (
                is_object($current) &&
                property_exists($current, $segment)
            ) {
                $current = $current->$segment;
            } else {
                return $default;
            }
        }

        return $current;
    }
}


if (!function_exists("e")) {
    /**
     * Escape HTML entities in a string.
     *
     * @param string $value The string to escape.
     * @return string Returns the escaped string.
     */
    function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
    }
}

if (!function_exists("raw")) {
    /**
     * Output a value without escaping.
     *
     * @param mixed $value The value to output raw.
     * @return string Returns the raw string representation of the value.
     */
    function raw(mixed $value): string
    {
        return (string) $value;
    }
}

if (!function_exists("csrf_token")) {
    function csrf_token(): string
    {
        /** @var TokenManager $mgr */
        $mgr = Container::getInstance()->make(TokenManager::class);
        return $mgr->getToken("web");
    }
}

if (!function_exists("forgetailwind")) {
    function forgetailwind(): string
    {
        $isHmrEnabled = env("APP_HMR", false);
        $env = env("APP_ENV");
        $host = request_host();

        if (!$isHmrEnabled) {
            return "";
        }

        if (in_array($env, ["production", "staging"], true)) {
            return "";
        }

        if (
            !str_starts_with($host, "localhost") &&
            !str_starts_with($host, "127.0.0.1")
        ) {
            return "";
        }

        if (
            class_exists(App\Modules\ForgeTailwind\ForgeTailwindModule::class)
        ) {
            return '<script defer src="/assets/modules/forge-tailwind/js/forge-tailwind-hmr.js" defer></script>';
        }
        return "";
    }
}

if (!function_exists("csrf_meta")) {
    function csrf_meta(): string
    {
        return '<meta name="csrf-token" content="' .
            htmlspecialchars(csrf_token(), ENT_QUOTES, "UTF-8") .
            '">';
    }
}

if (!function_exists("window_csrf_token")) {
    function window_csrf_token(): string
    {
        return "<script>
        window.csrfToken = document.querySelector('meta[name='csrf-token']')?.getAttribute('content') || '';
        </script>";
    }
}

if (!function_exists("csrf_input")) {
    function csrf_input(): string
    {
        return '<input type="hidden" name="_token" value="' .
            htmlspecialchars(csrf_token(), ENT_QUOTES, "UTF-8") .
            '">';
    }
}

if (!function_exists("forgewire_is_available")) {
    function forgewire_is_available(): bool
    {
        return class_exists(\App\Modules\ForgeWire\Support\Renderer::class) &&
            class_exists(\App\Modules\ForgeWire\Core\WireComponent::class);
    }
}

if (!function_exists("wire")) {
    /**
     * Render a ForgeWire component.
     *
     */
    function wire(
        string $componentClass,
        mixed $props = null,
        mixed $componentId = null,
    ): string {
        if (class_exists(App\Modules\ForgeWire\ForgeWireModule::class)) {
            return App\Modules\ForgeWire\Core\Hydrator::wire($componentClass, $props, $componentId);
        }
    }
}

if (!function_exists("w") && function_exists("wire")) {
    /**
     * Alias: shorter name for Forge wire component
     *   w(ProductsTable::class, ['perPage' => 5])
     *   w(ProductsTable::class, 'products-1')
     */
    function w(
        string $componentClass,
        mixed $props = null,
        mixed $componentId = null,
    ): string {
        return wire($componentClass, $props, $componentId);
    }
}

if (!function_exists("wire_name") && function_exists("wire")) {
    /**
     * Name-based resolver (optional):
     *   wire_name('products-table', ['perPage'=>5])
     * => App\Components\ProductsTable
     */
    function wire_name(
        string $name,
        mixed $props = null,
        mixed $componentId = null,
    ): string {
        $pascal = str_replace(
            " ",
            "",
            ucwords(str_replace(["-", "_", "."], " ", $name)),
        );
        $class = "App\\Components\\{$pascal}";
        return wire($class, $props, $componentId);
    }
}

if (!function_exists("tap")) {
    function tap(mixed $value, callable $cb): mixed
    {
        $cb($value);
        return $value;
    }
}

if (!function_exists("layout")) {
    /**
     * Helper for ergonomic load layout file
     */
    function layout(string $name, bool $fromModule = false): void
    {
        View::layout(name: $name, loadFromModule: $fromModule);
    }
}

if (!function_exists("section")) {
    /**
     * Helper for ergonomic load a section
     */
    function section(string $name): void
    {
        View::section(name: $name);
    }
}

if (!function_exists("add_timeline_event")) {
    function add_timeline_event(string $name, string $label, array $data = []): void
    {
        if (class_exists(TimelineCollector::class)) {
            if (filter_var($_ENV["APP_DEBUG"] ?? false, FILTER_VALIDATE_BOOLEAN)) {
                /** @var TimelineCollector $timelineCollector */
                $timelineCollector = Container::getInstance()->get(TimelineCollector::class);
                $timelineCollector::instance()->addEvent($name, $label, $data);
            }
        }
    }
}

if (!function_exists("collect_view_data")) {
    function collect_view_data(string $view, mixed $data = []): void
    {
        if (class_exists(\App\Modules\ForgeDebugbar\DebugBar::class)) {
            if (class_exists(\App\Modules\ForgeDebugbar\Collectors\ViewCollector::class)) {
                \App\Modules\ForgeDebugbar\Collectors\ViewCollector::instance()->addView($view, $data);
            }
        }
    }
}
