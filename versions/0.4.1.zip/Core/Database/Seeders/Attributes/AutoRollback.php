<?php
declare(strict_types=1);
namespace Forge\Core\Database\Seeders\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
class AutoRollback
{
    public function __construct(
        public string $table,
        public array $where
    ) {}
}