<?php


declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Seeders\SeederManager;
use Forge\Core\Module\Attributes\CLICommand;

#[CLICommand(name: 'seed', description: 'Run database seeders')]
class SeedCommand extends Command
{
    public function __construct(private readonly SeederManager $manager)
    {
    }

    /**
     * @throws \Throwable
     */
    public function execute(array $args): int
    {
        $type = $this->getArgValue($args, '--type');
        $module = $this->getArgValue($args, '--module');

        $this->info("Running seeders...");
        $this->manager->run($type, $module);
        $this->success("Seeding completed successfully");
        return 0;
    }

    private function getArgValue(array $args, string $key): ?string
    {
        foreach ($args as $arg) {
            if (str_starts_with($arg, $key . '=')) {
                return explode('=', $arg)[1] ?? null;
            }
        }
        return null;
    }
}