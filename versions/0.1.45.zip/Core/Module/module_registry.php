<?php return array (
  'App\\Modules\\ForgeAuth\\ForgeAuthModule' => 
  array (
    'name' => 'App\\Modules\\ForgeAuth\\ForgeAuthModule',
    'order' => 99,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeAuth',
  ),
  'App\\Modules\\ForgeErrorHandler\\ForgeErrorHandlerModule' => 
  array (
    'name' => 'App\\Modules\\ForgeErrorHandler\\ForgeErrorHandlerModule',
    'order' => 2,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeErrorHandler',
  ),
  'App\\Modules\\ForgeEvents\\ForgeEventsModule' => 
  array (
    'name' => 'App\\Modules\\ForgeEvents\\ForgeEventsModule',
    'order' => 99,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeEvents',
  ),
  'App\\Modules\\ForgeHub\\ForgeHubModule' => 
  array (
    'name' => 'App\\Modules\\ForgeHub\\ForgeHubModule',
    'order' => 1,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeHub',
  ),
  'App\\Modules\\ForgeLogger\\ForgeLoggerModule' => 
  array (
    'name' => 'App\\Modules\\ForgeLogger\\ForgeLoggerModule',
    'order' => 90,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeLogger',
  ),
  'App\\Modules\\ForgeNexus\\ForgeNexusModule' => 
  array (
    'name' => 'App\\Modules\\ForgeNexus\\ForgeNexusModule',
    'order' => 4,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeNexus',
  ),
  'App\\Modules\\ForgeNotification\\ForgeNotificationModule' => 
  array (
    'name' => 'App\\Modules\\ForgeNotification\\ForgeNotificationModule',
    'order' => 99,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeNotification',
  ),
  'App\\Modules\\ForgePackageManager\\ForgePackageManager' => 
  array (
    'name' => 'App\\Modules\\ForgePackageManager\\ForgePackageManager',
    'order' => 0,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgePackageManager',
  ),
  'App\\Modules\\ForgeStorage\\ForgeStorage' => 
  array (
    'name' => 'App\\Modules\\ForgeStorage\\ForgeStorage',
    'order' => 9223372036854775807,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeStorage',
  ),
  'App\\Modules\\ForgeTesting\\ForgeTestingModule' => 
  array (
    'name' => 'App\\Modules\\ForgeTesting\\ForgeTestingModule',
    'order' => 9999,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeTesting',
  ),
  'App\\Modules\\ForgeUi\\ForgeUIModule' => 
  array (
    'name' => 'App\\Modules\\ForgeUi\\ForgeUIModule',
    'order' => 99,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeUI',
  ),
  'App\\Modules\\ForgeWire\\ForgeWireModule' => 
  array (
    'name' => 'App\\Modules\\ForgeWire\\ForgeWireModule',
    'order' => 99,
    'path' => '/Users/acidlake/Development/UPPER/Forge/repos/forge-v3/modules/ForgeWire',
  ),
);