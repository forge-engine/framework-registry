<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Module\Attributes\CLICommand;
use ReflectionClass;
use ReflectionException;

#[Service]
#[CLICommand(name: 'help', description: 'Displays help for available commands.')]
class HelpCommand extends Command
{
    /**
     * @throws ReflectionException
     */
    public function execute(array $args): int
    {
        $this->line();
        $this->info("Forge Framework CLI Tool");
        $this->info("Available commands:");

        $headers = ['Command', 'Description'];
        $rows = [];


        foreach ($args as $name => $commandInfo) {
            $commandClass = $commandInfo[0];
            $reflectionClass = new ReflectionClass($commandClass);
            $commandAttribute = $reflectionClass->getAttributes(CLICommand::class)[0] ?? null;

            if ($commandAttribute) {
                $commandInstance = $commandAttribute->newInstance();
                $rows[] = [
                    'Command' => $name,
                    'Description' => $commandInstance->description,
                ];
            }
        }

        $this->table($headers, $rows);
        $this->line();

        return 0;
    }
}
