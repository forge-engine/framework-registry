<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\Bootstrap\Bootstrap;
use Forge\Core\DI\Container;
use Forge\Core\Http\Response;

final class View
{
    private static ?array $layout = null;
    private static array $sections = [];
    private static string $currentSection = "";
    private static array $cache = [];

    public function __construct(
        private readonly Container $container,
        private ?string            $viewPath = null,
        private ?string            $componentPath = null,
        private ?string            $cachePath = null,
        private readonly ?string   $module = null
    )
    {
        $basePath = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 5);

        $this->viewPath = $viewPath ?? $basePath . "/app/resources/views";
        $this->componentPath = $componentPath ?? $basePath . "/app/resources/components";
        $this->cachePath = $cachePath ?? $basePath . "/storage/framework/views";

        if (!is_dir($this->cachePath)) {
            mkdir($this->cachePath, 0755, true);
        }
    }

    public static function layout(string $name, bool $loadFromModule = false): void
    {
        self::$layout = [
            'name' => $name,
            'useModulePath' => $loadFromModule
        ];
    }

    public static function startSection(string $name): void
    {
        self::$currentSection = $name;
        ob_start();
    }

    public static function endSection(): void
    {
        self::$sections[self::$currentSection] = ob_get_clean();
        self::$currentSection = "";
    }

    public static function section(string $name): string
    {
        return self::$sections[$name] ?? "";
    }

    public static function component(string $name, array|object $props = [], bool $loadFromModule = false): string
    {
        return Component::render($name, $props, $loadFromModule);
    }

    public function render(string $view, array $data = []): Response
    {
        $this->ensureRequestCollectorExist($view, $data);

        $viewContent = $this->compileView($view, $data);

        if (self::$layout) {
            $layoutName = self::$layout['name'];
            $useModulePath = self::$layout['useModulePath'];

            $layoutData = array_merge($data, ["content" => $viewContent], self::$sections);

            if ($useModulePath && $this->module) {
                $viewContent = $this->compileAndExecuteModuleView(
                    $this->module,
                    "layouts/{$layoutName}",
                    $layoutData
                );
            } else {
                $viewContent = $this->compileView("layouts/{$layoutName}", $layoutData);
            }
        }

        self::$layout = null;
        self::$sections = [];
        self::$currentSection = "";

        return new Response($viewContent);
    }

    private function ensureRequestCollectorExist(string $view, array $data): void
    {
        $requestCollectorFile = BASE_PATH . '/modules/ForgeDebugBar/src/ForgeMultiTenantModule.php';
        $ready = is_file($requestCollectorFile)
            && class_exists(\App\Modules\ForgeDebugbar\Collectors\RequestCollector::class);
        if ($ready) {
            if (function_exists('collect_view_data')) {
                collect_view_data($view, $data);
            }
        }
    }

    private function compileView(string $view, array $data): string
    {
        $viewFile = $this->resolveViewFile($view);
        $cacheFile = "{$this->cachePath}/" . md5($viewFile) . ".php";

        if ($this->shouldCompile($viewFile, $cacheFile)) {
            $content = $this->compile(file_get_contents($viewFile));
            file_put_contents($cacheFile, $content);
        }

        return $this->executeCacheFile($cacheFile, $data);
    }

    private function resolveViewFile(string $view): string
    {
        $file = "{$this->viewPath}/{$view}.php";

        if (str_contains($view, ":")) {
            [$module, $relative] = explode(":", $view, 2);
            $modulePath = BASE_PATH . "/modules/{$module}/src/resources/views/{$relative}.php";
            if (is_file($modulePath)) {
                return $modulePath;
            }
        }

        if ($this->module) {
            $modulePath = BASE_PATH . "/modules/{$this->module}/src/resources/views/{$view}.php";
            if (is_file($modulePath)) {
                return $modulePath;
            }
        }

        if (!is_file($file)) {
            throw new \RuntimeException("View file not found: {$view}");
        }

        return $file;
    }

    private function shouldCompile(string $viewFile, string $cacheFile): bool
    {
        if (!Bootstrap::shouldCacheViews()) {
            return true;
        }
        return !file_exists($cacheFile) || filemtime($viewFile) > filemtime($cacheFile);
    }

    private function compile(string $content): string
    {
        return $content;
    }

    private function executeCacheFile(string $cacheFile, array|object $data): string
    {
        if (is_object($data)) {
            $props = $data;
        } else {
            extract($data, EXTR_SKIP);
        }

        ob_start();
        @include $cacheFile;
        return ob_get_clean();
    }

    private function compileAndExecuteModuleView(string $module, string $view, array $data): string
    {
        $viewFile = BASE_PATH . "/modules/{$module}/src/resources/views/{$view}.php";

        if (!is_file($viewFile)) {
            throw new \RuntimeException("Module view not found: {$viewFile}");
        }

        $cacheFile = "{$this->cachePath}/" . md5($viewFile) . ".php";

        if ($this->shouldCompile($viewFile, $cacheFile)) {
            $content = $this->compile(file_get_contents($viewFile));
            file_put_contents($cacheFile, $content);
        }

        return $this->executeCacheFile($cacheFile, $data);
    }

    public function renderComponentView(string $viewSubPath, array|object $data = []): string
    {
        $file = $this->resolveComponentFile($viewSubPath, $this->module);
        $cacheFile = "{$this->cachePath}/" . md5($file) . ".php";

        if ($this->shouldCompile($file, $cacheFile)) {
            $content = $this->compile(file_get_contents($file));
            file_put_contents($cacheFile, $content);
        }

        return $this->executeCacheFile($cacheFile, $data);
    }

    private function resolveComponentFile(string $component, ?string $module = null): string
    {
        if (str_contains($component, ":")) {
            [$moduleName, $relative] = explode(":", $component, 2);
            $file = BASE_PATH . "/modules/{$moduleName}/src/Resources/views/components/{$relative}.php";
            if (is_file($file)) return $file;
            throw new \RuntimeException("Module component template not found: {$relative}");
        }

        if ($module) {
            $file = BASE_PATH . "/modules/{$module}/src/Resources/views/components/{$component}.php";
            if (is_file($file)) return $file;
        }

        $file = "{$this->componentPath}/{$component}.php";
        if (is_file($file)) return $file;

        throw new \RuntimeException("Component template not found: {$component}");
    }

    private function compileComponent(string $view, array|object $data, ?string $module = null): string
    {
        $componentFile = $this->resolveComponentFile($view, $module);
        $cacheFile = "{$this->cachePath}/" . md5($componentFile) . ".php";

        if ($this->shouldCompile($componentFile, $cacheFile)) {
            $content = $this->compile(file_get_contents($componentFile));
            file_put_contents($cacheFile, $content);
        }

        if (is_object($data)) {
            $vars = get_object_vars($data);
        } else {
            $vars = $data;
        }

        return $this->executeCacheFile($cacheFile, $vars);
    }
}
