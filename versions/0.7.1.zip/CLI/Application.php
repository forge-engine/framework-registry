<?php

declare(strict_types=1);

namespace Forge\CLI;

use Forge\CLI\Attributes\Cli;
use Forge\CLI\Commands\Assets\AssetLinkCommand;
use Forge\CLI\Commands\Assets\AssetUnlinkCommand;
use Forge\CLI\Commands\db\MigrateCommand;
use Forge\CLI\Commands\db\MigrateRollBackCommand;
use Forge\CLI\Commands\db\SeedCommand;
use Forge\CLI\Commands\db\SeedPreviewCommand;
use Forge\CLI\Commands\db\SeedRollbackCommand;
use Forge\CLI\Commands\FlushCacheCommand;
use Forge\CLI\Commands\Generate\GenerateCommandCommand;
use Forge\CLI\Commands\Generate\GenerateComponentCommand;
use Forge\CLI\Commands\Generate\GenerateControllerCommand;
use Forge\CLI\Commands\Generate\GenerateDtoCommand;
use Forge\CLI\Commands\Generate\GenerateEnumCommand;
use Forge\CLI\Commands\Generate\GenerateEventCommand;
use Forge\CLI\Commands\Generate\GenerateMiddlewareCommand;
use Forge\CLI\Commands\Generate\GenerateMigrationCommand;
use Forge\CLI\Commands\Generate\GenerateModelCommand;
use Forge\CLI\Commands\Generate\GenerateModuleCommand;
use Forge\CLI\Commands\Generate\GenerateSeederCommand;
use Forge\CLI\Commands\Generate\GenerateServiceCommand;
use Forge\CLI\Commands\Generate\GenerateTestCommand;
use Forge\CLI\Commands\Generate\GenerateTraitCommand;
use Forge\CLI\Commands\HelpCommand;
use Forge\CLI\Commands\KeyGenerateCommand;
use Forge\CLI\Commands\MaintenanceDownCommand;
use Forge\CLI\Commands\MaintenanceUpCommand;
use Forge\CLI\Commands\ServeCommand;
use Forge\CLI\Commands\StatsCommand;
use Forge\CLI\Commands\storage\StorageLinkCommand;
use Forge\CLI\Commands\storage\StorageUnlinkCommand;
use Forge\Core\Bootstrap\AppCommandSetup;
use Forge\Core\DI\Container;
use Forge\Exceptions\MissingServiceException;
use ReflectionClass;
use ReflectionException;

final class Application
{
    private static int $instanceCount = 0;
    private static ?self $instance = null;

    /** @var array<string, array{0:string,1:string}> */
    private array $commands = [];

    private Container $container;
    private int $instanceId;

    /**
     * @throws ReflectionException
     */
    private function __construct(Container $container)
    {
        $this->instanceId = ++self::$instanceCount;
        $this->container = $container;

        // Register core commands
        $this->registerCoreCommands();

        // Register app commands from cached class map
        $this->registerAppCommandsFromCache();
    }

    /**
     * Register all known core commands explicitly.
     * @throws ReflectionException
     */
    private function registerCoreCommands(): void
    {
        $coreCommands = [
            ServeCommand::class,
            MigrateCommand::class,
            FlushCacheCommand::class,
            KeyGenerateCommand::class,
            GenerateModuleCommand::class,
            StorageLinkCommand::class,
            StorageUnlinkCommand::class,
            GenerateMiddlewareCommand::class,
            GenerateControllerCommand::class,
            MaintenanceUpCommand::class,
            MaintenanceDownCommand::class,
            StatsCommand::class,
            AssetLinkCommand::class,
            AssetUnlinkCommand::class,
            MigrateRollBackCommand::class,
            SeedCommand::class,
            SeedRollbackCommand::class,
            SeedPreviewCommand::class,
            GenerateEventCommand::class,
            GenerateMigrationCommand::class,
            GenerateSeederCommand::class,
            GenerateModelCommand::class,
            GenerateCommandCommand::class,
            GenerateDtoCommand::class,
            GenerateServiceCommand::class,
            GenerateEnumCommand::class,
            GenerateTraitCommand::class,
            GenerateTestCommand::class,
            //GenerateComponentCommand::class
        ];

        foreach ($coreCommands as $commandClass) {
            $this->registerCommandClass($commandClass, '');
        }
    }

    /**
     * Register a command with optional prefix
     * @throws ReflectionException
     */
    public function registerCommandClass(string $commandClass, string $prefix = 'module:'): void
    {
        $reflectionClass = new ReflectionClass($commandClass);
        $commandAttribute = $reflectionClass->getAttributes(Cli::class)[0] ?? null;

        if ($commandAttribute) {
            $commandInstance = $commandAttribute->newInstance();
            $this->container->register($commandClass);

            $commandName = $commandInstance->command;
            if ($prefix && !str_starts_with($commandName, $prefix)) {
                $commandName = $prefix . $commandName;
            }

            $this->commands[$commandName] = [
                $commandClass,
                $commandInstance->description
            ];
        }
    }

    private function registerAppCommandsFromCache(): void
    {
        $setup = AppCommandSetup::getInstance($this->container);
        $classMap = $setup->getClassMap();

        foreach ($classMap as $className => $filePath) {
            if (!class_exists($className)) {
                include_once $filePath;
            }

            if (!class_exists($className)) {
                continue;
            }

            $this->registerAppCommandClass($className);
        }
    }

    /**
     * Get singleton instance.
     */
    public static function getInstance(Container $container): self
    {
        if (!self::$instance) {
            self::$instance = new self($container);
        }
        return self::$instance;
    }

    /**
     * Shortcut for registering app commands.
     * @throws ReflectionException
     */
    public function registerAppCommandClass(string $commandClass): void
    {
        $this->registerCommandClass($commandClass, 'app:');
    }

    /**
     * Returns all registered commands.
     */
    public function getCommands(): array
    {
        return $this->commands;
    }

    /**
     * Return instance id.
     */
    public function getInstanceId(): int
    {
        return $this->instanceId;
    }

    /**
     * Run CLI application with argv.
     * @throws ReflectionException|MissingServiceException
     */
    public function run(array $argv): int
    {
        if (count($argv) < 2) {
            $this->showHelp();
            return 1;
        }

        $commandName = $argv[1];

        if ($commandName === "help") {
            $helpCommand = $this->container->make(HelpCommand::class);
            $helpCommand->execute($this->getSortedCommands());
            return 0;
        }

        foreach ($this->commands as $name => $commandInfo) {
            if ($name === $commandName) {
                $commandClass = $commandInfo[0];
                $command = $this->container->make($commandClass);
                $args = array_slice($argv, 2);
                $command->execute($args);
                return 0;
            }
        }

        $this->showHelp();
        echo "Command not found: $commandName\n";
        return 1;
    }

    /**
     * Show help.
     * @throws ReflectionException|MissingServiceException
     */
    private function showHelp(): void
    {
        $helpCommand = $this->container->make(HelpCommand::class);
        $helpCommand->execute($this->getSortedCommands());
    }

    /**
     * Return commands sorted by name.
     */
    private function getSortedCommands(): array
    {
        ksort($this->commands);
        return $this->commands;
    }
}