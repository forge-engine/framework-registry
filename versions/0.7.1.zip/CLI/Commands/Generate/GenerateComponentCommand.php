<?php

declare(strict_types=1);

namespace Forge\CLI\Commands\Generate;

use Exception;
use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\CliGenerator;
use Forge\Traits\StringHelper;

#[Cli(
    command: 'generate:component',
    description: 'Create a new component',
    usage: 'generate:component [--type=app|module] [--module=ModuleName] [--name=Example] [--id=component-id]',
    examples: [
        'generate:component --type=app --name=Example --id=test-component',
        'generate:component --type=app --name=Example --path=Test --id=test-component',
        'generate:component --type=module --module=Blog --name=Example --id=test-component',
        'generate:component   (starts wizard)',
    ]
)]
final class GenerateComponentCommand extends Command
{
    use StringHelper;
    use CliGenerator;

    #[Arg(name: 'type', description: 'app or module', validate: 'app|module')]
    private string $type;

    #[Arg(name: 'module', description: 'Module name when type=module', required: false)]
    private ?string $module = null;

    #[Arg(name: 'name', description: 'Component class name (without suffix)', validate: '/^\w+$/')]
    private string $name;

    #[Arg(name: 'Component Type', description: 'Component type (simple|basic|dto) (simple render, basic component 
    with view, advanced with dto data)', validate: 'simple|basic|dto')]
    private string $componentType;

    #[Arg(name: 'Component Id', description: 'Component id (my-component, suffix:component-id)')]
    private string $componentId;

    #[Arg(name: 'Dto name', description: 'Component Dto name (without suffix) (MyClass)', required: false)]
    private ?string $componentDto;


    #[Arg(
        name: 'path',
        description: 'Optional subfolder inside Models (e.g., Admin, Api/V1)',
        default: '',
        required: false
    )]
    private string $path = '';

    /**
     * @throws Exception
     */
    public function execute(array $args): int
    {
        $this->wizard($args);

        if ($this->type === 'module' && !$this->module) {
            $this->error('--module=Name required when --type=module');
            return 1;
        }

        if ($this->componentType === 'dto' && !$this->componentDto) {
            $this->error('--componentDto=Name required when --componentType=dto');
            return 1;
        }

        $fromModule = 'false';
        if ($this->module) {
            $fromModule = 'true';
        }

        $componentFile = $this->componentPath();
        $componentDtoFile = $this->componentDtoPath();
        $viewFile = $this->viewComponentPath();

        $tokens = [
            '{{ secondNameSpace }}' => $this->toPascalCase($this->name),
            '{{ componentName }}' => $this->name . 'Component',
            '{{ componentId }}' => $this->componentId,
            '{{ componentDto }}' => $this->componentDto . 'Dto',
            '{{ fromModule }}' => "{$fromModule}",
            '{{ componentNameSpace }}' => $this->componentNamespace(),
        ];

        if ($this->componentType === 'simple') {
            $this->generateFromStub('component/class-simple', $componentFile, $tokens);
        } else if ($this->componentType === 'basic') {
            $this->generateFromStub('component/class', $componentFile, $tokens);
            $this->generateFromStub('component/view', $viewFile, []);
        } else {
            $this->generateFromStub('component/class-dto', $componentFile, $tokens);
            $this->generateFromStub('component/dto', $componentDtoFile, $tokens);
            $this->generateFromStub('component/view-dto', $viewFile, []);
        }

        return 0;
    }
}