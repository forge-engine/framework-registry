<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\Core\Contracts\MiddlewarePipelineInterface;
use Forge\Core\DI\Container;
use Forge\Core\Middleware\DefaultMiddlewarePipeline;
use Forge\Core\Middleware\EngineMiddlewareRegistry;
use Forge\Core\Middleware\MiddlewareLoader;
use Forge\Core\Routing\ControllerLoader;
use Forge\Core\Routing\Router;
use Forge\Exceptions\MissingServiceException;
use ReflectionException;

final class RouterSetup
{
  /**
   * @throws ReflectionException|MissingServiceException
   */
  public static function setup(Container $container): Router
  {
    return self::initRouter($container);
  }

  /**
   * Initializes the router, loads controllers, and prepares middleware.
   *
   * @throws ReflectionException|MissingServiceException
   */
  private static function initRouter(Container $container): Router
  {
    $controllerDirs = [
      BASE_PATH . "/app/Controllers",
      ...glob(BASE_PATH . "/modules/*/src/Controllers", GLOB_ONLYDIR),
    ];

    $loader = new ControllerLoader($container, $controllerDirs);
    $controllers = $loader->registerControllers();

    /** @var MiddlewareLoader $middlewareLoader */
    $middlewareLoader = $container->make(MiddlewareLoader::class);
    $autoLoadedMap = $middlewareLoader->load();

    $appMiddlewareConfigFile = BASE_PATH . "/config/middleware.php";
    $appMiddlewareConfig = [];
    if (file_exists($appMiddlewareConfigFile)) {
      $appMiddlewareConfig = require $appMiddlewareConfigFile;
      $appMiddlewareConfig = is_array($appMiddlewareConfig)
        ? $appMiddlewareConfig
        : [];
    }

    $finalMiddlewareConfig = $appMiddlewareConfig;

    foreach ($autoLoadedMap as $group => $middlewareData) {
      if (
        !isset($finalMiddlewareConfig[$group]) ||
        !is_array($finalMiddlewareConfig[$group])
      ) {
        $finalMiddlewareConfig[$group] = [];
      }

      $configMiddlewares = $finalMiddlewareConfig[$group];
      $configMiddlewareSet = array_flip($configMiddlewares);

      $hasExplicitEngineMiddlewares = false;
      foreach ($configMiddlewares as $mw) {
        if (EngineMiddlewareRegistry::isEngineMiddleware($mw)) {
          $hasExplicitEngineMiddlewares = true;
          break;
        }
      }

      if ($hasExplicitEngineMiddlewares) {
        foreach ($middlewareData as $item) {
          if (is_string($item)) {
            $item = ["class" => $item, "overrideClass" => null];
          }

          $autoClass = $item["class"] ?? null;
          $overrideClass = $item["overrideClass"] ?? null;

          if ($overrideClass && isset($configMiddlewareSet[$overrideClass])) {
            unset($configMiddlewareSet[$overrideClass]);
          }

          if (!isset($configMiddlewareSet[$autoClass])) {
            $configMiddlewareSet[$autoClass] = true;
          }
        }

        $finalMiddlewareConfig[$group] = array_keys($configMiddlewareSet);
      } else {
        $currentGroup = array_flip($configMiddlewares);

        foreach ($middlewareData as $item) {
          if (is_string($item)) {
            $item = ["class" => $item, "overrideClass" => null];
          }

          $autoClass = $item["class"] ?? null;
          $overrideClass = $item["overrideClass"] ?? null;

          if ($overrideClass) {
            unset($currentGroup[$overrideClass]);
          }

          $currentGroup[$autoClass] = true;
        }

        $finalMiddlewareConfig[$group] = array_keys($currentGroup);
      }
    }

    if (!$container->has(MiddlewarePipelineInterface::class)) {
      $container->bind(MiddlewarePipelineInterface::class, DefaultMiddlewarePipeline::class);
    }

    $middlewarePipeline = $container->get(MiddlewarePipelineInterface::class);

    $router = Router::init($container, $finalMiddlewareConfig, $middlewarePipeline);

    foreach ($controllers as $controller) {
      $router->registerControllers($controller);
    }

    return $router;
  }
}
