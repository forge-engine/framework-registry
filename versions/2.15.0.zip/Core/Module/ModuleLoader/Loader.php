<?php

declare(strict_types=1);

namespace Forge\Core\Module\ModuleLoader;

use Forge\CLI\Application;
use Forge\CLI\Traits\OutputHelper;
use Forge\Core\Config\Config;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\DI\Container;
use Forge\Core\Module\Attributes\LifecycleHook;
use Forge\Core\Module\Attributes\Module;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;
use Forge\Traits\ModuleHelper;
use Forge\Traits\NamespaceHelper;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use ReflectionClass;

#[Service]
final class Loader
{
  use NamespaceHelper;
  use ModuleHelper;
  use OutputHelper;

  private array $modules = [];
  private array $moduleRequirements = [];
  private array $moduleRegistry = [];
  private ?array $sortedRegistryCache = null;
  private string $registryFilePath = BASE_PATH . '/engine/Core/Module/module_registry.php';
  private array $earlyHooksRegistered = [];
  private bool $earlyHooksDiscovered = false;

  /***
   * @var Application $cliApplication
   */

  public function __construct(
    private readonly Container $container,
    private readonly Config $config,
  ) {
    $this->loadModuleRegistry();
  }

  private function loadModuleRegistry(): void
  {
    if (file_exists($this->registryFilePath)) {
      $registry = include $this->registryFilePath;
      $this->moduleRegistry = is_array($registry) ? $registry : [];
      $this->invalidateSortedCache();
      $this->cleanupRegistry();
    }
  }

  private function cleanupRegistry(): void
  {
    $hasChanges = false;

    foreach ($this->moduleRegistry as $key => $moduleInfo) {
      if (!isset($moduleInfo['path']) || !is_dir($moduleInfo['path'])) {
        unset($this->moduleRegistry[$key]);
        $hasChanges = true;
        $this->info("Removing missing module: $key");
      }
    }

    if ($hasChanges) {
      $this->invalidateSortedCache();
      $this->saveModuleRegistry();
    }
  }

  private function saveModuleRegistry(): void
  {
    $fp = fopen($this->registryFilePath, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
      ftruncate($fp, 0);
      fwrite($fp, '<?php return ' . var_export($this->moduleRegistry, true) . ';');
      fflush($fp);
      flock($fp, LOCK_UN);
      fclose($fp);
    } else {
      file_put_contents($this->registryFilePath, '<?php return ' . var_export($this->moduleRegistry, true) . ';');
    }
  }

  /**
   * Discover and register EARLY_BOOT and BEFORE_MODULE_LOAD hooks before modules are loaded.
   * This allows modules to hook into the bootstrap process early.
   * This method is idempotent - it can be called multiple times safely.
   */
  public function discoverEarlyHooks(): void
  {
    if ($this->earlyHooksDiscovered) {
      return;
    }

    $moduleDirectory = BASE_PATH . '/modules';

    if (!is_dir($moduleDirectory)) {
      $this->earlyHooksDiscovered = true;
      return;
    }

    $directories = array_filter(
      scandir($moduleDirectory),
      fn($item) => is_dir("$moduleDirectory/$item") && !in_array($item, ['.', '..'])
    );

    foreach ($directories as $directoryName) {
      $modulePath = "$moduleDirectory/$directoryName";
      $this->registerModuleAutoloadPath($directoryName, $modulePath);
    }

    foreach ($directories as $directoryName) {
      $modulePath = "$moduleDirectory/$directoryName";
      $srcPath = "$modulePath/src";

      if (!is_dir($srcPath)) {
        continue;
      }

      $moduleClass = $this->findModuleClass($srcPath);
      if ($moduleClass) {
        $this->registerEarlyHooksForModule($moduleClass);
      }
    }

    $this->earlyHooksDiscovered = true;
  }

  /**
   * Register EARLY_BOOT and BEFORE_MODULE_LOAD hooks for a module without fully loading it.
   */
  private function registerEarlyHooksForModule(array $moduleClass): void
  {
    $className = $moduleClass['name'];

    if (!class_exists($className)) {
      return;
    }

    try {
      $reflectionClass = new ReflectionClass($className);

      $moduleAttributes = $reflectionClass->getAttributes(Module::class);
      if (empty($moduleAttributes)) {
        return;
      }

      $moduleAttribute = $moduleAttributes[0]->newInstance();
      $moduleName = $moduleAttribute->name;

      foreach ($reflectionClass->getMethods() as $method) {
        $lifecycleHookAttributes = $method->getAttributes(LifecycleHook::class);

        foreach ($lifecycleHookAttributes as $attribute) {
          $hookInstance = $attribute->newInstance();
          $hookName = $hookInstance->hook;

          if (
            in_array($hookName, [
              LifecycleHookName::EARLY_BOOT,
              LifecycleHookName::BEFORE_MODULE_LOAD
            ], true)
          ) {
            $methodName = $method->getName();
            $forSelf = $hookInstance->forSelf;

            $callback = function (...$args) use ($className, $methodName, $moduleName, $forSelf, $hookName) {
              try {
                $moduleInstance = $this->container->make($className);
                if ($forSelf) {
                  $passedModuleName = $args[0] ?? '';
                  if ($passedModuleName === $moduleName) {
                    return call_user_func_array([$moduleInstance, $methodName], $args);
                  }
                } else {
                  return call_user_func_array([$moduleInstance, $methodName], $args);
                }
              } catch (\Throwable $e) {
                error_log("Error calling early hook {$hookName->value} on {$className}::{$methodName}: " . $e->getMessage());
                return null;
              }
            };

            HookManager::addHook($hookName, $callback);

            $hookKey = "{$className}::{$methodName}::{$hookName->value}";
            $this->earlyHooksRegistered[$hookKey] = true;
          }
        }
      }
    } catch (\ReflectionException $e) {
      error_log("Error discovering early hooks for {$className}: " . $e->getMessage());
    } catch (\Throwable $e) {
      error_log("Error discovering early hooks for {$className}: " . $e->getMessage());
    }
  }

  /**
   * Check if a hook was already registered during early discovery.
   */
  public function wasHookRegisteredEarly(string $className, string $methodName, LifecycleHookName $hookName): bool
  {
    $hookKey = "{$className}::{$methodName}::{$hookName->value}";
    return isset($this->earlyHooksRegistered[$hookKey]);
  }

  public function loadModules(): void
  {
    $moduleDirectory = BASE_PATH . '/modules';

    if (!is_dir($moduleDirectory)) {
      return;
    }

    $directories = array_filter(
      scandir($moduleDirectory),
      fn($item) => is_dir("$moduleDirectory/$item") && !in_array($item, ['.', '..'])
    );

    foreach ($directories as $directoryName) {
      $modulePath = "$moduleDirectory/$directoryName";
      $this->registerModuleAutoloadPath($directoryName, $modulePath);
    }

    $hasChanges = false;
    foreach ($directories as $directoryName) {
      $modulePath = "$moduleDirectory/$directoryName";
      $srcPath = "$modulePath/src";

      if (!is_dir($srcPath)) {
        continue;
      }

      $moduleClass = $this->findModuleClass($srcPath);
      if ($moduleClass) {
        $className = $moduleClass['name'];
        if (!isset($this->moduleRegistry[$className]) || $this->moduleRegistry[$className]['path'] !== $moduleClass['path']) {
          $this->moduleRegistry[$className] = $moduleClass;
          $hasChanges = true;
        }
      }
    }

    if ($hasChanges) {
      $this->invalidateSortedCache();
      $this->saveModuleRegistry();
    }
  }

  private function findModuleClass(string $srcPath): ?array
  {
    $directoryIterator = new RecursiveDirectoryIterator($srcPath);
    $iterator = new RecursiveIteratorIterator($directoryIterator);

    foreach ($iterator as $file) {
      if ($file->isFile() && $file->getExtension() === 'php') {
        $namespace = $this->getNamespaceFromFile($file->getRealPath(), BASE_PATH);
        if ($namespace) {
          $className = $namespace . '\\' . pathinfo($file->getFilename(), PATHINFO_FILENAME);
          try {
            if (class_exists($className)) {
              $reflectionClass = new ReflectionClass($className);
              $attributes = $reflectionClass->getAttributes(Module::class);
              if (!empty($attributes)) {
                $moduleInstance = $attributes[0]->newInstance();
                return [
                  'name' => $className,
                  'order' => $moduleInstance->order ?? 999,
                  'path' => dirname($srcPath),
                ];
              }
            }
          } catch (\Throwable $e) {
            $this->error("Error discovering module class $className: " . $e->getMessage());
          }
        }
      }
    }

    return null;
  }

  public function preloadCliModules(): void
  {
    foreach ($this->getSortedModuleRegistry() as $moduleInfo) {
      $this->loadModuleByName($moduleInfo['name']);
    }
  }

  /**
   * Retrieves the module registry sorted by the 'order' key.
   * Uses cached sorted result to avoid O(n log n) sorting on every call.
   *
   * @return array
   */
  public function getSortedModuleRegistry(): array
  {
    if ($this->sortedRegistryCache === null) {
      $sortedRegistry = $this->moduleRegistry;

      uasort($sortedRegistry, function ($a, $b) {
        $orderA = $a['order'] ?? PHP_INT_MAX;
        $orderB = $b['order'] ?? PHP_INT_MAX;

        if ($orderA === $orderB) {
          return 0;
        }
        return ($orderA < $orderB) ? -1 : 1;
      });

      $this->sortedRegistryCache = $sortedRegistry;
    }

    return $this->sortedRegistryCache;
  }

  /**
   * Invalidates the sorted registry cache.
   * Should be called whenever the module registry is modified.
   */
  private function invalidateSortedCache(): void
  {
    $this->sortedRegistryCache = null;
  }

  public function loadModuleByName(string $moduleName): void
  {
    if (!isset($this->moduleRegistry[$moduleName])) {
      return;
    }

    $moduleInfo = $this->moduleRegistry[$moduleName];
    $this->loadModule($moduleInfo['path'], $moduleInfo);

    $this->checkModuleRequirements($moduleName);
  }

  private function loadModule(string $modulePath, array $moduleClass): void
  {
    $moduleName = basename($modulePath);
    $className = $moduleClass['name'];

    try {
      $reflectionClass = new ReflectionClass($className);
      $attributes = $reflectionClass->getAttributes(Module::class);

      if (!empty($attributes)) {
        $moduleInstance = $attributes[0]->newInstance();
        if (!$moduleInstance->core) {
          $this->registerModule($moduleName, $className, $moduleInstance, $reflectionClass);
        }
      }
    } catch (\ReflectionException $e) {
      $this->error("Failed to load module: $moduleName - " . $e->getMessage());
    }
  }

  private function registerModule(string $moduleName, string $className, Module $moduleInstance, ReflectionClass $reflectionClass): void
  {
    $this->modules[$moduleName] = $className;

    (new RegisterModuleService($this->container, $reflectionClass))->init();
    (new RegisterModuleCommand($this->container, $reflectionClass))->init();
    (new RegisterModuleConfig($this->config, $reflectionClass))->init();
    (new RegisterModuleHooks($this->container, $reflectionClass))->init();
    (new RegisterModuleProvides($this->container, $reflectionClass))->init();
    $requiresRegistrar = new RegisterModuleRequires($reflectionClass, $this->moduleRequirements);
    $requiresRegistrar->init();
    $this->checkModuleRequirements($moduleName);
    //(new RegisterModuleRequires($reflectionClass, $this->moduleRequirements));
    (new RegisterModuleCompatibility($reflectionClass, $moduleInstance))->init();
    (new RegisterModuleRepository($reflectionClass))->init();

    $moduleInstance = $this->container->make($className);
    if (method_exists($moduleInstance, 'register')) {
      $moduleInstance->register($this->container);
    }

    HookManager::triggerHook(LifecycleHookName::AFTER_MODULE_REGISTER, $moduleName, $className, $moduleInstance);
  }

  public function isModuleLoaded(string $moduleClassName): bool
  {
    return isset($this->modules[$moduleClassName]);
  }

  public function getModules(): array
  {
    return $this->modules;
  }

  public function loadCoreModule(string $modulePath): void
  {
    if (!is_dir($modulePath)) {
      echo "Module path does not exist: $modulePath";
      return;
    }

    $moduleName = basename($modulePath);
    $srcPath = "$modulePath/src";

    if (!is_dir($srcPath)) {
      echo "Module source path does not exist: $srcPath";
      return;
    }

    $this->registerModuleAutoloadPath($moduleName, $modulePath);

    $moduleClass = $this->findModuleClass($srcPath);
    if ($moduleClass) {
      $this->loadModule($modulePath, $moduleClass);
    } else {
      echo "No module class found in: $srcPath";
    }
  }
}
