<?php

declare(strict_types=1);

namespace Forge\Exceptions;

final class ValidationException extends BaseException
{
    private array $errors;

    public function __construct(array $errors, string $message = 'Invalid validation')
    {
        parent::__construct($message);
        $this->errors = $errors;
    }

    public function errors(): array
    {
        return $this->errors;
    }
}
