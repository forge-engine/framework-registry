<?php
declare(strict_types=1);

namespace Forge\Core\View;

use Attribute;
use Forge\Core\Helpers\Strings;
use ReflectionClass;
use ReflectionException;
use RuntimeException;

#[Attribute(Attribute::TARGET_CLASS)]
final class Component
{
    public function __construct(
        public string $name
    ) {
    }

    /**
     * Render a component by attribute name.
     *
     * @throws ReflectionException
     */
    public static function render(string $name, array|object $props = [], bool $loadFromModule = false): string
    {
        $fqcn = self::resolveClassName($name, $loadFromModule);

        if (!class_exists($fqcn)) {
            throw new RuntimeException("Component class not found: {$fqcn}");
        }

        $reflection = new ReflectionClass($fqcn);
        $attr = $reflection->getAttributes(self::class)[0] ?? null;
        if ($attr === null || $attr->newInstance()->name !== $name) {
            throw new RuntimeException("Attribute mismatch for {$fqcn}");
        }

        $component = $reflection->newInstance($props);
        return (string) $component->render();
    }

    private static function resolveClassName(string $name, bool $module): string
    {
        $parts = preg_split('#[/:]#', $name);
        $class = Strings::toPascalCase(array_pop($parts));

        if ($module) {
            $module = Strings::toPascalCase($parts[0]);
            $subNs = array_map([Strings::class, 'toPascalCase'], array_slice($parts, 1));
            return 'App\\Modules\\' . $module . '\\Resources\\Components'
                . ($subNs ? '\\' . implode('\\', $subNs) : '')
                . '\\' . $class;
        }

        $subNs = array_map([Strings::class, 'toPascalCase'], $parts);
        return 'App\\Components'
            . ($subNs ? '\\' . implode('\\', $subNs) : '')
            . '\\' . $class;
    }
}