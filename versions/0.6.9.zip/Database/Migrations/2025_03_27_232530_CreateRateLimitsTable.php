<?php

declare(strict_types=1);

use Forge\Core\Database\Attributes\Column;
use Forge\Core\Database\Attributes\GroupMigration;
use Forge\Core\Database\Attributes\Index;
use Forge\Core\Database\Attributes\Table;
use Forge\Core\Database\Enums\ColumnType;
use Forge\Core\Database\Migrations\Migration;

#[GroupMigration(name: 'security')]
#[Table(name: 'rate_limits')]
#[Index(columns: ['id'], name: 'idx_rate_limits_id')]
class CreateRateLimitsTable extends Migration
{
    #[Column(name: 'id', type: ColumnType::INTEGER, primaryKey: true, autoIncrement: true)]
    public readonly int $id;

    #[Column(name: 'ip_address', type:  ColumnType::STRING, length:255, nullable: false)]
    public readonly string $ip_address;

    #[Column(name: 'request_count', type: ColumnType::INTEGER, nullable: false, default: 1)]
    public readonly int $request_count;

    #[Column(name: 'last_request', type: ColumnType::TIMESTAMP, nullable: true)]
    public readonly ?string $last_request;
}
