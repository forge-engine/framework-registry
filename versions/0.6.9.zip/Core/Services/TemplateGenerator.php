<?php

declare(strict_types=1);

namespace Forge\Core\Services;

use Exception;
use Forge\Core\DI\Attributes\Service;

#[Service]
final class TemplateGenerator
{
    private string $baseTemplatePath;

    public function __construct()
    {
        $this->baseTemplatePath = BASE_PATH . "/engine/Core/Templates/";
    }

    /**
     * Generate a file from a template.
     * Automatically creates the directory if missing.
     * Won't overwrite an existing file.
     *
     * @param string $templateName Template file name relative to base path
     * @param string $outputPath Full path where the file should be generated
     * @param array<string,string> $replacements Key=>value replacements in the template
     * @param bool $forceOverwrite Whether to overwrite existing files
     * @throws Exception
     */
    public function generateFileFromTemplate(
        string $templateName,
        string $outputPath,
        array $replacements,
        bool $forceOverwrite = false
    ): void {
        $templatePath = $this->baseTemplatePath . $templateName;
        $templateContent = file_get_contents($templatePath);

        if ($templateContent === false) {
            throw new Exception("Error: Could not read template file from: {$templatePath}");
        }

        $fileContent = str_replace(array_keys($replacements), array_values($replacements), $templateContent);

        $dir = dirname($outputPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        if (file_exists($outputPath) && !$forceOverwrite) {
            echo "File already exists, skipping: {$outputPath}\n";
            return;
        }

        file_put_contents($outputPath, $fileContent);
        echo "Created file: {$outputPath}\n";
    }

    public function askQuestion(string $questionText, string $default): string
    {
        $answer = readline($questionText . " [$default]: ");
        return $answer ?: $default;
    }
}