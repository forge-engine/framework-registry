# 🔧 Forge Engine – The Core Stuff

Hey! 👋 This is the core of the Forge Framework—where all the essential pieces come together. If you're wondering how Forge actually *runs*, this is the place to be.

It's not flashy, just the solid foundation that everything else builds on.

## What's in Here?
This repo powers the whole Forge experience. You'll find:

- 🗃️ **Database Layer** – Lightweight and straightforward
- 🔄 **ORM** – Simple, useful, nothing wild
- 🛣️ **Router** – Maps your requests to the right place
- 📦 **Module Auto-Loader** – Plug in new features easily
- 🧰 **Dependency Injection Container** – Keep things clean and modular
- 🖼️ **View Engine** – PHP-first, no weird templating rules
- ⚙️ **CLI Kernel** – Run commands with ease
- 🗂️ **Config + Env Managers** – Tame your settings and environments
- 🥾 **Bootstrap for CLI + Web** – Gets things running properly
- 🧩 **Helpers + Traits** – Common patterns and shortcuts

Eventually, some parts like the bootstraps will become their own modules to keep the engine lean and mean—but for now, it’s all bundled together here.

## This Isn't a Framework for Everyone
Forge isn’t trying to be everything to everyone. It’s a foundation I built to solve my problems and give me control. If it helps you too, awesome. Fork it, change it, make it yours.

Check out the [Modules Registry](https://github.com/forge-engine/modules) for the official modules, and the [Forge Starter](https://github.com/forge-engine/forge-starter) if you want to kick off a new project.

Have fun exploring!

