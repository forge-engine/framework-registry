<?php
declare(strict_types=1);

namespace Forge\Core\DI\Attributes;

use Attribute;

/**
 * This tells Forge that the class should be treated as a service.
 *
 * When you add this to a class, Forge will automatically register it
 * in the service container. That means you don’t have to manually wire it up —
 * just use it in a constructor and Forge will handle the rest.
 *
 * - You can set a custom `$id` if you want to name the service yourself.
 * - By default, it's a singleton — so the same instance is reused.
 */
#[Attribute(Attribute::TARGET_CLASS)]
final class Service
{
    public function __construct(
        public ?string $id = null,
        public bool $singleton = true
    ) {}
}
