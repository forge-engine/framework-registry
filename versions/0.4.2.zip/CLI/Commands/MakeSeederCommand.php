<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Module\Attributes\CLICommand;
use Forge\Traits\StringHelper;

#[CLICommand(name: 'make:seeder', description: 'Create a new database seeder file')]
class MakeSeederCommand extends Command
{
    use StringHelper;
    private const DEFAULT_TYPE = 'app';
    private const BASE_PATH = BASE_PATH;

    public function execute(array $args): int
    {
        if (empty($args[0])) {
            $this->error("Error: Seeder name required");
            return 1;
        }

        $options = $this->parseOptions($args);
        $rawName = $args[0];

        $className = $this->toPascalCase($rawName);

        $path = $this->getSeederPath($className, $options['type'], $options['module']);

        if ($path === null) {
            $this->error("Error: Could not determine path for type '{$options['type']}' or module '{$options['module']}'.");
            return 1;
        }

        $filenameNamePart = $this->normalizeName($rawName);
        $filename = date("Y_m_d_His") . "_{$filenameNamePart}.php";
        $fullPath = rtrim($path, '/') . '/' . $filename;

        if (!is_dir(dirname($fullPath))) {
            mkdir(dirname($fullPath), 0755, true);
        }

        file_put_contents($fullPath, $this->generateStub($className));
        $this->success("Seeder created: {$filename} in " . str_replace(self::BASE_PATH . '/', '', dirname($fullPath)));
        return 0;
    }

    /**
     * Parse command-line options.
     * * @param array $args
     * @return array
     */
    private function parseOptions(array $args): array
    {
        $options = [
            'type' => self::DEFAULT_TYPE,
            'module' => null,
        ];

        foreach ($args as $arg) {
            if (str_starts_with($arg, '--')) {
                [$key, $value] = explode('=', substr($arg, 2)) + [1 => null];

                if ($key === 'type' && in_array($value, ['app', 'modules', 'engine'])) {
                    $options['type'] = $value;
                } elseif ($key === 'module' && $value !== null) {
                    $options['module'] = $value;
                }
            }
        }

        if ($options['type'] === 'modules' && $options['module'] === null) {
            $this->error("Error: The --module option is required when --type=modules.");
            exit(1);
        }

        return $options;
    }

    /**
     * Determine the directory path for the new seeder file.
     *
     * @param string $className
     * @param string $type
     * @param string|null $moduleName
     * @return string|null
     */
    private function getSeederPath(string $className, string $type, ?string $moduleName): ?string
    {
        return match ($type) {
            'app' => self::BASE_PATH . '/app/Database/seeders/',
            'engine' => self::BASE_PATH . '/engine/Database/seeders/',
            'modules' => $this->getModuleSeederPath($moduleName),
            default => null,
        };
    }

    /**
     * Determine the path for a module seeder.
     *
     * @param string $moduleName
     * @return string|null
     */
    private function getModuleSeederPath(string $moduleName): ?string
    {
        $pascalCaseName = $this->toPascalCase($moduleName);
        $path = self::BASE_PATH . "/app/modules/{$pascalCaseName}/src/Database/seeders/";

        if (is_dir($path) || mkdir($path, 0755, true)) {
            return $path;
        }

        return null;
    }

    /**
     * Generate the seeder file content stub.
     *
     * @param string $className
     * @return string
     */
    private function generateStub(string $className): string
    {
        return <<<PHP
<?php

declare(strict_types=1);

use Forge\Core\Database\Seeders\Seeder;
use Forge\Core\Database\Seeders\Attributes\SeederInfo;
use Forge\Core\Database\Seeders\Attributes\AutoRollback;

#[SeederInfo(description: 'Seed for {$className}', author: 'CLI')]
#[AutoRollback('table_name', ['column' => 'value'])]
class $className extends Seeder
{
    public function up(): void
    {
        // \$this->insertBatch('table_name', [/* data */]);
    }
}
PHP;
    }


    /**
     * Normalize the name for the filename part (similar to make:migration).
     *
     * @param string $name
     * @return string
     */
    private function normalizeName(string $name): string
    {
        $normalized = preg_replace("/[^a-zA-Z0-9]/", "_", $name);
        return $this->toSnakeCase($normalized);
    }
}