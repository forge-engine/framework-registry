<?php
declare(strict_types=1);

namespace Forge\CLI\Traits;

trait CommandOptionTrait
{
    /**
     * Check if an option is present in CLI args and optionally return its value.
     *
     * Usage:
     * ```php
     * $force = $this->option('force', $args);
     * $name = $this->option('name', $args) ?? 'default';
     * ```
     *
     * @param string $name Option name without leading dashes
     * @param array $args Raw CLI args
     * @return string|null Returns value if exists, or null
     */
    public function option(string $name, array $args): ?string
    {
        $prefix = '--' . $name;

        foreach ($args as $i => $arg) {
            if (str_starts_with($arg, $prefix . '=')) {
                return substr($arg, strlen($prefix) + 1);
            }

            if ($arg === $prefix && isset($args[$i + 1])) {
                return $args[$i + 1];
            }
            if ($arg === $prefix) {
                return '';
            }
        }

        return null;
    }

    /**
     * Check if a boolean flag is present in CLI args
     */
    public function flag(string $name, array $args): bool
    {
        return $this->option($name, $args) !== null;
    }
}