<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\Core\Config\Config;
use Forge\Core\Debug\Metrics;
use Forge\Core\DI\Container;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;
use Forge\Core\Module\ModuleLoader\Loader;

final class ModuleSetup
{
    private static bool $modulesLoaded = false;

    public static function loadModules(Container $container): void
    {
        if (self::$modulesLoaded) {
            return;
        }

        $container->singleton(Loader::class, function () use ($container) {
            return new Loader(
                container: $container,
                config: $container->get(Config::class)
            );
        });

        Metrics::start('module_discovery');
        /*** @var Loader $moduleLoader */
        $moduleLoader = $container->get(Loader::class);
        $moduleLoader->loadModules();

        Metrics::stop('module_discovery');

        HookManager::triggerHook(LifecycleHookName::AFTER_MODULE_LOAD);
        self::$modulesLoaded = true;
    }

    public static function preloadModules(Container $container): void
    {
        /*** @var Loader $moduleLoader */
        $moduleLoader = $container->get(Loader::class);
        $moduleLoader->loadModules();

        $moduleLoader->preloadCliModules();
    }
}
