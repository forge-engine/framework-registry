<?php

declare(strict_types=1);

namespace Forge\CLI\Commands\Generate;

use Exception;
use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\CliGenerator;
use Forge\Traits\StringHelper;
use Forge\Core\Services\TemplateGenerator;
use Forge\Core\Structure\StructureResolver;

#[Cli(
  command: 'generate:module',
  description: 'Create a new module with basic structure',
  usage: 'generate:module [--name=ModuleName] [--description="Module description"] [--version=1.0.0]',
  examples: [
    'generate:module --name=Blog',
    'generate:module --name=Blog --description="Blog module" --version=1.0.0',
    'generate:module   (starts wizard)',
  ]
)]
final class GenerateModuleCommand extends Command
{
  use StringHelper;
  use CliGenerator;

  #[Arg(name: 'name', description: 'Module name in PascalCase (without suffix)', validate: '/^\w+$/')]
  private string $name;

  #[Arg(name: 'description', description: 'Module description', required: false)]
  private ?string $description = null;

  #[Arg(name: 'version', description: 'Module version (e.g., 0.1.0)', default: '0.1.0', required: false)]
  private string $version = '0.1.0';

  public function __construct(
    private readonly TemplateGenerator $templateGenerator,
    private readonly StructureResolver $structureResolver
  ) {
  }

  /**
   * @throws Exception
   */
  public function execute(array $args): int
  {
    $this->wizard($args);

    $this->name = $this->toPascalCase($this->name);
    if (!$this->isPascalCase($this->name)) {
      $this->error("Invalid module name. Use PascalCase (e.g., MyModule).");
      return 1;
    }

    if (!$this->description) {
      $this->description = $this->templateGenerator->askQuestion(
        "Module description: ",
        "A brief description of the module."
      );
    }

    if (!$this->version) {
      $this->version = $this->templateGenerator->askQuestion(
        "Module version (e.g., 1.0.0): ",
        "1.0.0"
      );
    }

    $moduleDir = BASE_PATH . '/modules/' . $this->name;
    if (is_dir($moduleDir)) {
      $this->error("Module directory already exists: $moduleDir");
      return 1;
    }

    $moduleStructure = $this->getDefaultModuleStructure();
    $this->createModuleDirectories($moduleDir, $moduleStructure);

    $persistStructure = $this->templateGenerator->askQuestion(
      "Persist structure configuration? (y/n): ",
      "n"
    );
    $persistStructure = strtolower(trim($persistStructure)) === 'y';

    $this->generateModuleFiles($moduleDir, $moduleStructure, $persistStructure);

    $this->success("Module '{$this->name}' created successfully!");
    if ($persistStructure) {
      $this->info("Structure configuration has been persisted in the module class.");
    }
    return 0;
  }

  private function getDefaultModuleStructure(): array
  {
    $internalStructurePath = BASE_PATH . '/engine/Core/Structure/forge_structure.php';
    $internalStructure = require $internalStructurePath;
    $defaultStructure = $internalStructure['modules'] ?? [];

    $userStructurePath = BASE_PATH . '/forge_structure.php';
    if (file_exists($userStructurePath)) {
      $userStructure = require $userStructurePath;
      if (is_array($userStructure) && isset($userStructure['modules'])) {
        $defaultStructure = array_merge($defaultStructure, $userStructure['modules']);
      }
    }

    return $defaultStructure;
  }

  private function createModuleDirectories(string $moduleDir, array $structure): void
  {
    $basePath = $moduleDir;

    foreach ($structure as $type => $path) {
      $fullPath = $basePath . '/' . $path;
      $dir = dirname($fullPath);
      if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
      }
    }

    $contractsPath = 'src/Contracts';
    $contractsDir = $basePath . '/' . $contractsPath;
    if (!is_dir($contractsDir)) {
      mkdir($contractsDir, 0755, true);
    }

    $srcDir = $basePath . '/src';
    if (!is_dir($srcDir)) {
      mkdir($srcDir, 0755, true);
    }
  }

  private function generateModuleFiles(string $moduleDir, array $moduleStructure, bool $persistStructure): void
  {
    $structureAttribute = '';
    if ($persistStructure) {
      $structureArray = $this->formatStructureArray($moduleStructure);
      $structureAttribute = "use Forge\Core\Module\Attributes\Structure;\n\n";
      $structureAttribute .= "#[Structure(structure: {$structureArray})]\n";
    }

    $tokens = [
      '{{ moduleName }}' => $this->name,
      '{{ command }}' => $this->toKebabCase($this->name),
      '{{ interfaceName }}' => $this->name . 'Interface',
      '{{ serviceName }}' => $this->name . 'Service',
      '{{ moduleDescription }}' => $this->description,
      '{{ moduleVersion }}' => $this->version,
      '{{ moduleConfig }}' => $this->toSnakeCase($this->name),
      '{{ structureAttribute }}' => $structureAttribute,
    ];

    $commandsPath = $moduleStructure['commands'] ?? 'src/Commands';
    $servicesPath = $moduleStructure['services'] ?? 'src/Services';
    $contractsPath = 'src/Contracts';
    $modulePath = 'src';

    $this->generateFromStub(
      'modules/command',
      $moduleDir . '/' . $commandsPath . '/' . $this->name . 'Command.php',
      $tokens
    );

    $this->generateFromStub(
      'modules/interface',
      $moduleDir . '/' . $contractsPath . '/' . $this->name . 'Interface.php',
      $tokens
    );

    $this->generateFromStub(
      'modules/service',
      $moduleDir . '/' . $servicesPath . '/' . $this->name . 'Service.php',
      $tokens
    );

    $this->generateFromStub(
      'modules/module',
      $moduleDir . '/' . $modulePath . '/' . $this->name . 'Module.php',
      $tokens
    );
  }

  private function formatStructureArray(array $structure): string
  {
    $lines = ['['];
    foreach ($structure as $key => $value) {
      $lines[] = "    '{$key}' => '{$value}',";
    }
    $lines[] = ']';
    return implode("\n", $lines);
  }
}
