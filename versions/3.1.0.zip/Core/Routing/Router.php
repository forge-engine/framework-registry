<?php

declare(strict_types=1);

namespace Forge\Core\Routing;

use Forge\Core\Contracts\MiddlewarePipelineInterface;
use Forge\Core\Contracts\RouteScopeFilterInterface;
use Forge\Core\Debug\Metrics;
use Forge\Core\DI\Container;
use Forge\Core\Helpers\ModuleHelper;
use Forge\Core\Http\Attributes\Middleware;
use Forge\Core\Http\Attributes\ApiRoute;
use Forge\Exceptions\MissingServiceException;
use ReflectionClass;
use Forge\Core\Http\Request;
use Forge\Traits\ResponseHelper;
use ReflectionMethod;

final class Router
{
  use ResponseHelper;

  private static ?self $instance = null;
  private array $middlewareGroups;
  /** @var array<string, array{controller: class-string, method: string, handler: array, params: array, middleware: array, permissions: array}> */
  private array $routes = [];
  /** @var array<string, array{controller: class-string, method: string, handler: array, params: array, middleware: array, permissions: array}> */
  private array $staticRoutes = [];
  /** @var array<string, array{controller: class-string, method: string, handler: array, params: array, middleware: array, permissions: array, regex: string}> */
  private array $dynamicRoutes = [];
  private Container $container;
  private ?array $currentRoute = null;
  private MiddlewarePipelineInterface $middlewarePipeline;
  /** @var array<string, array{reflection: ReflectionMethod, parameters: array<int, array{name: string, type: ?string, hasType: bool, isRequest: bool}>}> */
  private static array $reflectionCache = [];

  private function __construct(
    Container $container,
    array $middlewareConfig = [],
    ?MiddlewarePipelineInterface $middlewarePipeline = null,
  ) {
    $this->container = $container;
    $this->middlewareGroups = $middlewareConfig;

    if ($middlewarePipeline !== null) {
      $this->middlewarePipeline = $middlewarePipeline;
    } else {
      if ($container->has(MiddlewarePipelineInterface::class)) {
        $this->middlewarePipeline = $container->get(MiddlewarePipelineInterface::class);
      } else {
        $this->middlewarePipeline = new \Forge\Core\Middleware\DefaultMiddlewarePipeline();
      }
    }
  }

  /**
   * @throws \Exception
   */
  public static function getInstance(): Router
  {
    if (self::$instance === null) {
      throw new \Exception(
        "Router not initialized. Use RouterSetup::setup() first.",
      );
    }
    return self::$instance;
  }

  public static function init(
    Container $container,
    array $middlewareConfig = [],
    ?MiddlewarePipelineInterface $middlewarePipeline = null,
  ): Router {
    if (self::$instance === null) {
      self::$instance = new self($container, $middlewareConfig, $middlewarePipeline);
    }
    return self::$instance;
  }

  public function getCurrentRoute(): array|null
  {
    return $this->currentRoute;
  }

  public function getRoutes(): array
  {
    return $this->routes;
  }

  /**
   * Auto-register controllers (recursively) and **skip** wrong-scope ones when route scope filter is available.
   * @throws \ReflectionException
   */
  public function registerControllers(string $controllerClass): void
  {
    $moduleName = ModuleHelper::extractModuleNameFromNamespace($controllerClass);
    if ($moduleName !== null && ModuleHelper::isModuleDisabled($moduleName)) {
      return;
    }

    $reflection = new ReflectionClass($controllerClass);

    $scopeFilter = $this->getRouteScopeFilter();

    if ($scopeFilter === null) {
      $this->registerAll($reflection);
      return;
    }

    $onCentral = $scopeFilter::isCentralDomain();

    $ctrlScope = $scopeFilter->extractScope($reflection);
    if ($ctrlScope && !$scopeFilter->allowedHere($ctrlScope, $onCentral)) {
      return;
    }

    foreach ($reflection->getMethods() as $method) {
      $methScope = $scopeFilter->extractScope($method) ?? $ctrlScope;
      if ($methScope && !$scopeFilter->allowedHere($methScope, $onCentral)) {
        continue;
      }

      $this->registerMethodRoutes($method, $controllerClass);
    }
  }

  private function registerAll(ReflectionClass $reflection): void
  {
    foreach ($reflection->getMethods() as $method) {
      $this->registerMethodRoutes($method, $reflection->getName());
    }
  }

  private function registerMethodRoutes(
    ReflectionMethod $method,
    string $controllerClass,
  ): void {
    $routeAttributes = array_merge(
      $method->getAttributes(Route::class),
      $method->getAttributes(ApiRoute::class),
    );

    $attr = new ReflectionClass($controllerClass);
    $middlewareAttributes = array_merge(
      $attr->getAttributes(Middleware::class),
      $method->getAttributes(Middleware::class),
    );

    $middleware = [];
    foreach ($middlewareAttributes as $attr) {
      $instance = $attr->newInstance();
      $middleware = array_merge(
        $middleware,
        $this->middlewareGroups[$instance->nameOrClass] ?? [
          $instance->nameOrClass,
        ],
      );
    }

    foreach ($routeAttributes as $attr) {
      $route = $attr->newInstance();
      $routeMiddlewares = $this->resolveMiddlewareGroups(
        $route->middlewares,
      );
      $middleware = array_merge($middleware, $routeMiddlewares);
      $permissions = $route->permissions;

      $paramNames = [];
      $pattern = preg_replace_callback(
        "/\{([a-zA-Z0-9_]+)(?::(.+))?\}/",
        function ($m) use (&$paramNames) {
          $paramNames[] = $m[1];
          return ($m[2] ?? "") === ".+" ? "(.+)" : "([a-zA-Z0-9_-]+)";
        },
        $route->path,
      );
      $regex = "#^{$pattern}/?$#";
      $key = $route->method . $regex;

      if (isset($this->routes[$key])) {
        $existing = $this->routes[$key];
        $existingIsPreferred = $existing['preferred'] ?? false;
        $newIsPreferred = $route->preferred;

        if ($existingIsPreferred && !$newIsPreferred) {
          continue;
        }

      }

      $routeData = [
        "controller" => $controllerClass,
        "method" => $method->getName(),
        "handler" => [$controllerClass, $method->getName()],
        "params" => $paramNames,
        "middleware" => $middleware,
        "permissions" => $permissions,
        "preferred" => $route->preferred,
      ];

      $this->routes[$key] = $routeData;

      if (empty($paramNames)) {
        $staticKey = $route->method . ':' . $route->path;
        $this->staticRoutes[$staticKey] = $routeData;
      } else {
        $this->dynamicRoutes[$key] = array_merge($routeData, ['regex' => $regex]);
      }
    }
  }

  private function resolveMiddlewareGroups(array $groups): array
  {
    $middlewares = [];
    foreach ($groups as $group) {
      $middlewares = array_merge(
        $middlewares,
        $this->middlewareGroups[$group] ?? [],
      );
    }
    return $middlewares;
  }

  /**
   * Get route scope filter from container if available.
   *
   * @return RouteScopeFilterInterface|null The route scope filter, or null if not available
   */
  private function getRouteScopeFilter(): ?RouteScopeFilterInterface
  {
    try {
      if ($this->container->has(RouteScopeFilterInterface::class)) {
        $filter = $this->container->get(RouteScopeFilterInterface::class);
        if ($filter instanceof RouteScopeFilterInterface) {
          return $filter;
        }
      }

      $filters = $this->container->getAll(RouteScopeFilterInterface::class);
      if (!empty($filters)) {
        return $filters[0];
      }
    } catch (\Throwable $e) {
      error_log("Failed to discover route scope filter: " . $e->getMessage());
    }

    return null;
  }

  public function dispatch(Request $request): mixed
  {
    Metrics::start("routing_dispatching");
    $uri = $request->serverParams["REQUEST_URI"] ?? "/";
    $method = $request->getMethod();
    $path = parse_url($uri, PHP_URL_PATH);
    $path = $path !== false ? $path : "/";
    $route = null;
    $this->currentRoute = null;

    $staticKey = $method . ':' . $path;
    if (isset($this->staticRoutes[$staticKey])) {
      $route = $this->staticRoutes[$staticKey];
      $route["uri"] = $path;
      $route["http_method"] = $method;
      $this->currentRoute = $route;
      $request->setAttribute("_route", $route);
    } else {
      foreach ($this->dynamicRoutes as $routeKey => $routeInfo) {
        if (strpos($routeKey, $method) === 0) {
          $regex = $routeInfo['regex'];
          if (preg_match($regex, $path, $matches)) {
            $routeInfo["regex_matches"] = $matches;
            $route = $routeInfo;
            $route["uri"] = $path;
            $route["http_method"] = $method;
            unset($route['regex']);
            $this->currentRoute = $route;
            $request->setAttribute("_route", $route);
            break;
          }
        }
      }
    }

    if ($route === null) {
      $errorCode = 404;
      require_once BASE_PATH . "/engine/Templates/Views/error_page.php";
      return $this->createErrorResponse($request, "", (int) $errorCode);
    }

    $allMiddlewares = $this->middlewarePipeline->resolveMiddlewares(
      $route["middleware"] ?? [],
      $request,
      $route
    );
    $permissions = $route["permissions"] ?? [];
    $request->setAttribute("required_permissions", $permissions);

    $pipeline = array_reduce(
      array_reverse($allMiddlewares),
      fn($next, $mw) => fn($req) => $this->container
        ->make($mw)
        ->handle($req, $next),
      fn($req) => $this->runController($route, $req),
    );

    Metrics::stop("routing_dispatching");
    return $pipeline($request);
  }

  /**
   * @throws \ReflectionException
   * @throws MissingServiceException
   */
  private function runController(array $route, Request $request): mixed
  {
    $controllerClass = $route["controller"];
    $methodName = $route["method"];
    $params = [];
    $arguments = [];

    $reflectionData = $this->getReflectionData($controllerClass, $methodName);
    $reflectionMethod = $reflectionData['reflection'];
    $parameterMetadata = $reflectionData['parameters'];

    if (isset($route["params"], $route["regex_matches"])) {
      array_shift($route["regex_matches"]);
      foreach ($route["params"] as $index => $paramName) {
        $params[$paramName] = $route["regex_matches"][$index];
      }

      foreach ($parameterMetadata as $paramMeta) {
        $name = $paramMeta['name'];
        $value = $params[$name] ?? null;

        if ($paramMeta['hasType'] && $value !== null) {
          $type = $paramMeta['type'];
          if ($type === "int") {
            $value = (int) $value;
          } elseif ($type === "float") {
            $value = (float) $value;
          } elseif ($type === "bool") {
            $value = filter_var($value, FILTER_VALIDATE_BOOLEAN);
          }
        }

        $arguments[] = $paramMeta['isRequest'] ? $request : $value;
      }
    } else {
      foreach ($parameterMetadata as $paramMeta) {
        if ($paramMeta['isRequest']) {
          $arguments[] = $request;
          break;
        }
      }
    }

    $controllerInstance = $this->container->make($controllerClass);
    return $controllerInstance->$methodName(...$arguments);
  }

  /**
   * Get cached reflection data for a controller method.
   * Caches ReflectionMethod and parameter metadata to avoid reflection overhead on every request.
   *
   * @param string $controllerClass
   * @param string $methodName
   * @return array{reflection: ReflectionMethod, parameters: array<int, array{name: string, type: ?string, hasType: bool, isRequest: bool}>}
   * @throws \ReflectionException
   */
  private function getReflectionData(string $controllerClass, string $methodName): array
  {
    $cacheKey = $controllerClass . '::' . $methodName;

    if (!isset(self::$reflectionCache[$cacheKey])) {
      $reflectionMethod = new ReflectionMethod($controllerClass, $methodName);
      $parameters = [];

      foreach ($reflectionMethod->getParameters() as $param) {
        $type = $param->getType();
        $typeName = null;
        $hasType = false;

        if ($type instanceof \ReflectionNamedType) {
          $typeName = $type->getName();
          $hasType = true;
        }

        $parameters[] = [
          'name' => $param->getName(),
          'type' => $typeName,
          'hasType' => $hasType,
          'isRequest' => $param->getName() === 'request',
        ];
      }

      self::$reflectionCache[$cacheKey] = [
        'reflection' => $reflectionMethod,
        'parameters' => $parameters,
      ];
    }

    return self::$reflectionCache[$cacheKey];
  }

}
