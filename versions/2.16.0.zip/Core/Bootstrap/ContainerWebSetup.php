<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\CLI\Application;
use Forge\Core\Config\Config;
use Forge\Core\Config\Environment;
use Forge\Core\DI\Container;
use Forge\Core\Middleware\MiddlewareLoader;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;
use Forge\Core\Module\ModuleLoader\Loader;
use Forge\Core\Session\Drivers\FileSessionDriver;
use Forge\Core\Session\Session;
use Forge\Core\Session\SessionInterface;
use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;
use ReflectionException;

final class ContainerWebSetup
{
  private static bool $containerLoaded = false;

  /**
   * @throws ReflectionException
   * @throws MissingServiceException
   * @throws ResolveParameterException
   */
  public static function initOnce(): Container
  {
    if (!self::$containerLoaded) {
      $container = self::setup();
      self::$containerLoaded = true;
      return $container;
    }
    return Container::getInstance();
  }

  /**
   * @throws ReflectionException
   * @throws MissingServiceException
   * @throws ResolveParameterException
   */
  public static function setup(): Container
  {
    $env = Environment::getInstance();
    $container = Container::getInstance();
    HelperDiscoverSetup::setup();

    $container->singleton(Config::class, function () {
      return new Config(BASE_PATH . '/config');
    });

    $container->singleton(Application::class, function () use ($container) {
      return Application::getInstance($container);
    });

    $container->singleton(SessionInterface::class, function () {
      $fileDriver = new FileSessionDriver();
      return new Session($fileDriver);
    });

    $container->singleton(MiddlewareLoader::class, function () use ($container) {
      return new MiddlewareLoader();
    });

    $container->singleton(Loader::class, function () use ($container) {
      return new Loader(
        container: $container,
        config: $container->get(Config::class)
      );
    });

    $moduleLoader = $container->get(Loader::class);
    $moduleLoader->discoverEarlyHooks();

    HookManager::triggerHook(LifecycleHookName::EARLY_BOOT);

    ModuleSetup::loadModules($container);
    ErrorHandlerSetup::setup($container);
    ServiceDiscoverSetup::setup($container);
    AppCommandSetup::getInstance($container);

    HookManager::triggerHook(LifecycleHookName::APP_BOOTED);

    return $container;
  }
}
