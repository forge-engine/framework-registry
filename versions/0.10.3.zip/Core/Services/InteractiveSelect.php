<?php

declare(strict_types=1);

namespace Forge\Core\Services;

use Forge\Core\DI\Attributes\Service;

#[Service]
final class InteractiveSelect
{
    private bool $initialRender = true;
    private const VISIBLE_ITEMS = 7;
    
    public function select(array $options, string $prompt = "Select an option", ?int $defaultIndex = null): ?int
    {
        if (empty($options)) {
            return null;
        }
        
        $selectedIndex = $defaultIndex ?? 0;
        $totalOptions = count($options);
        $startIndex = 0;
        
        if (!$this->isInteractive()) {
            return $this->fallbackSelection($options, $prompt, $defaultIndex);
        }
        
        $this->hideCursor();
        
        try {
            $this->setRawMode();
            
            echo "\033[1;36m{$prompt}:\033[0m\n";
            echo "Use ↑↓ to navigate, Enter to select, Esc to cancel\n\n";
            
            $this->initialRender = true;
            
            while (true) {
                $startIndex = $this->calculateStartIndex($selectedIndex, $totalOptions);
                $this->renderMenu($options, $selectedIndex, $startIndex);
                $this->initialRender = false;
                
                $key = $this->readKey();
                
                if ($key === 'up' && $selectedIndex > 0) {
                    $selectedIndex--;
                } elseif ($key === 'down' && $selectedIndex < $totalOptions - 1) {
                    $selectedIndex++;
                } elseif ($key === 'enter') {
                    $this->showCursor();
                    $this->restoreMode();
                    echo "\n";
                    return $selectedIndex;
                } elseif ($key === 'escape') {
                    $this->showCursor();
                    $this->restoreMode();
                    echo "\n";
                    return null;
                }
            }
        } catch (\Exception $e) {
            $this->showCursor();
            $this->restoreMode();
            return $this->fallbackSelection($options, $prompt, $defaultIndex);
        }
    }
    
    private function calculateStartIndex(int $selectedIndex, int $totalOptions): int
    {
        $visibleCount = min(self::VISIBLE_ITEMS, $totalOptions);
        
        if ($selectedIndex < $visibleCount) {
            return 0;
        }
        
        if ($selectedIndex >= $totalOptions - $visibleCount) {
            return max(0, $totalOptions - $visibleCount);
        }
        
        return $selectedIndex - (int)floor($visibleCount / 2);
    }
    
    private function renderMenu(array $options, int $selectedIndex, int $startIndex): void
    {
        $totalOptions = count($options);
        $visibleCount = min(self::VISIBLE_ITEMS, $totalOptions);
        $endIndex = min($startIndex + $visibleCount, $totalOptions);
        
        if (!$this->initialRender) {
            echo "\033[{$visibleCount}A";
        }
        
        for ($i = $startIndex; $i < $endIndex; $i++) {
            $option = $options[$i] ?? '';
            $line = rtrim($option);
            
            if ($i === $selectedIndex) {
                echo "\033[K\033[1;32m> {$line}\033[0m\n";
            } else {
                echo "\033[K  {$line}\033[0m\n";
            }
        }
    }
    
    private function readKey(): ?string
    {
        $read = [STDIN];
        $write = null;
        $except = null;
        
        if (stream_select($read, $write, $except, 0, 200000) === 0) {
            return null;
        }
        
        $char = fread(STDIN, 1);
        
        if ($char === "\033") {
            $char2 = fread(STDIN, 1);
            if ($char2 === '[') {
                $char3 = fread(STDIN, 1);
                if ($char3 === 'A') {
                    return 'up';
                } elseif ($char3 === 'B') {
                    return 'down';
                }
            } elseif ($char2 === false || $char2 === '') {
                return 'escape';
            }
        } elseif ($char === "\n" || $char === "\r") {
            return 'enter';
        }
        
        return null;
    }
    
    private function setRawMode(): void
    {
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            return;
        }
        
        system('stty -icanon -echo');
    }
    
    private function restoreMode(): void
    {
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            return;
        }
        
        system('stty icanon echo');
    }
    
    private function hideCursor(): void
    {
        echo "\033[?25l";
    }
    
    private function showCursor(): void
    {
        echo "\033[?25h";
    }
    
    private function isInteractive(): bool
    {
        if (!function_exists('posix_isatty')) {
            return false;
        }
        return posix_isatty(STDIN);
    }
    
    private function fallbackSelection(array $options, string $prompt, ?int $defaultIndex): ?int
    {
        echo "\033[1;36m{$prompt}:\033[0m\n\n";
        
        foreach ($options as $index => $option) {
            $number = $index + 1;
            echo "[{$number}] {$option}\n";
        }
        
        echo "\n";
        $input = readline("Enter number (1-" . count($options) . "): ");
        
        if (is_numeric($input)) {
            $selected = (int)$input - 1;
            if ($selected >= 0 && $selected < count($options)) {
                return $selected;
            }
        }
        
        return $defaultIndex;
    }
}

