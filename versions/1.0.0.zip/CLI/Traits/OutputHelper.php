<?php

declare(strict_types=1);

namespace Forge\CLI\Traits;

trait OutputHelper
{
    protected function info(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[0;34m" . $prefix . $message . "\033[0m");
    }

    protected function clearScreen(): void
    {
        echo "\033[H\033[2J";
    }

    protected function warning(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[1;33m" . $prefix . $message . "\033[0m");
    }

    protected function error(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[0;31m" . $prefix . $message . "\033[0m");
    }

    protected function comment(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[0;33m" . $prefix . $message . "\033[0m");
    }

    protected function debug(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        echo "\033[35m{$prefix}{$message}\033[0m\n";
    }

    protected function log(string $message, string $context = 'LOG'): void
    {
        $logMessage = "[" . date('Y-m-d H:i:s') . "] [" . $context . "]: {$message}";
        $this->output($logMessage);
    }

    protected function prompt(string $message): void
    {
        echo "\033[36m{$message}\033[0m ";
    }

    protected function array(array $data, ?string $title = null): void
    {
        if ($title) {
            $this->info($title);
        }

        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $this->array($value, (string)$key);
                continue;
            }
            $this->output(sprintf("\033[0;36m%s:\033[0m %s", $key, $value));
        }
    }

    protected function line(string $message = ""): void
    {
        $this->output($message);
    }

    protected function success(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[1;32m" . $prefix . $message . "\033[0m");
    }

    private function output(string $message): void
    {
        echo $message . PHP_EOL;
    }

    protected function table(array $headers, array $rows): void
    {
        if (empty($headers) || empty($rows)) {
            return;
        }

        $columnsWidth = array_map('strlen', $headers);

        foreach ($rows as $row) {
            if (is_array($row)) {
                foreach ($headers as $index => $header) {
                    $value = $row[$header] ?? '';
                    $columnsWidth[$index] = max($columnsWidth[$index], strlen((string)$value));
                }
            } elseif (is_object($row)) {
                foreach ($headers as $index => $header) {
                    if (isset($row->$header)) {
                        $columnsWidth[$index] = max($columnsWidth[$index], strlen((string)$row->$header));
                    } else {
                        $columnsWidth[$index] = max($columnsWidth[$index], strlen(''));
                    }
                }
            }
        }

        $headerLine = '| ' . implode(' | ', array_map(function ($header, $width) {
            return str_pad($header, $width);
        }, $headers, $columnsWidth)) . ' |';
        $this->line($headerLine);

        $separator = '+';
        foreach ($columnsWidth as $width) {
            $separator .= str_repeat('-', $width + 2) . '+';
        }
        $this->line($separator);

        foreach ($rows as $row) {
            $rowOutput = '| ';

            foreach ($headers as $index => $header) {
                $value = '';
                if (is_array($row) && array_key_exists($header, $row)) {
                    $value = $row[$header];
                } elseif (is_object($row) && isset($row->$header)) {
                    $value = $row->$header;
                }

                $rowOutput .= str_pad((string)$value, $columnsWidth[$index]) . ' | ';
            }

            $this->line($rowOutput);
        }
    }
}
