<?php

declare(strict_types=1);

namespace Forge\Traits;

use Forge\Core\Helpers\Url;
use Forge\Core\Http\Request;

trait PaginationHelper
{
    protected static function getPaginationLinks(
        int $page,
        int $perPage,
        int $totalPages,
        ?string $sortColumn = 'created_at',
        ?string $sortDirection = 'ASC',
        ?string $search = ''
    ): array {
        $baseUrl = Url::baseUrl();
        $links = [];
        $queryParams = http_build_query([
            'per_page' => $perPage,
            'sort' => $sortColumn,
            'direction' => $sortDirection,
            'search' => $search
        ]);
        $links['self'] = "$baseUrl?page=$page&$queryParams";

        if ($page > 1) {
            $links['first'] = "$baseUrl?page=1&$queryParams";
            $links['prev'] = "$baseUrl?page=" . ($page - 1) . "&$queryParams";
        }

        if ($page < $totalPages) {
            $links['next'] = "$baseUrl?page=" . ($page + 1) . "&$queryParams";
            $links['last'] = "$baseUrl?page=$totalPages&$queryParams";
        }

        return $links;
    }

    protected function getPaginationParams(Request $request): array
    {
        $page = isset($request->queryParams['page']) && is_numeric($request->queryParams['page']) ? (int)$request->queryParams['page'] : 1;
        $limit = isset($request->queryParams['per_page']) && is_numeric($request->queryParams['per_page']) ? (int)$request->queryParams['per_page'] : 10;
        $sortColumn = isset($request->queryParams['sort']) && is_string($request->queryParams['sort']) ? (string)$request->queryParams['sort'] : 'created_at';
        $sortDirection = isset($request->queryParams['direction']) && is_string($request->queryParams['direction']) ? (string)$request->queryParams['direction'] : 'ASC';
        $search = isset($request->queryParams['search']) && is_string($request->queryParams['search']) ? (string)$request->queryParams['search'] : '';

        $page = max(1, $page);
        $limit = max(1, $limit);

        return [
            'page' => $page,
            'limit' => $limit,
            'column' => $sortColumn,
            'direction' => $sortDirection,
            'search' => $search
        ];
    }
}
