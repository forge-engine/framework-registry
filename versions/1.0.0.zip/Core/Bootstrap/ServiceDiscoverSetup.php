<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use App\Modules\ForgeEvents\Attributes\EventListener;
use App\Modules\ForgeEvents\Services\EventDispatcher;
use Forge\Core\DI\Attributes\Discoverable;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\DI\Container;
use Forge\Core\Services\AttributeDiscoveryService;
use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;
use ReflectionClass;
use ReflectionException;
use ReflectionMethod;

final class ServiceDiscoverSetup
{
    private const string CLASS_MAP_CACHE_FILE =
        BASE_PATH . "/storage/framework/cache/class-map.php";

    /**
     * @throws ReflectionException
     * @throws MissingServiceException
     * @throws ResolveParameterException
     */
    public static function setup(Container $container): void
    {
        if ($container->has(\App\Modules\ForgeEvents\Services\EventDispatcher::class)) {
            /** @var EventDispatcher $eventDispatcherService */
            $eventDispatcherService = $container->get(EventDispatcher::class);
        } else {
            $eventDispatcherService = null;
        }

        $discoveryService = new AttributeDiscoveryService();

        // Get base paths to scan
        $basePaths = self::getBasePaths();

        // Discover classes with Service or Discoverable attributes
        $attributeClasses = [
            Service::class,
            Discoverable::class,
        ];

        $classMap = $discoveryService->discover($basePaths, $attributeClasses);

        // Register services and event listeners
        foreach ($classMap as $className => $metadata) {
            if (!class_exists($className)) {
                // Try to load the class
                $filepath = $metadata['file'] ?? '';
                if ($filepath && file_exists($filepath)) {
                    try {
                        require_once $filepath;
                    } catch (\Exception $e) {
                        continue;
                    }
                }
            }

            if (!class_exists($className)) {
                continue;
            }

            try {
                $reflectionClass = new ReflectionClass($className);
                
                // Register service if it has Service or Discoverable attribute
                if (self::hasServiceAttribute($reflectionClass)) {
                    self::registerService($reflectionClass, $container);
                }

                // Register event listeners
                if ($eventDispatcherService) {
                    self::registerEventListeners($reflectionClass, $eventDispatcherService, $container);
                }
            } catch (ReflectionException $e) {
                // Skip classes with reflection errors
            }
        }

        // Maintain backward compatibility: generate old cache format
        self::generateLegacyClassMapCache($classMap);
    }

    /**
     * Get base paths to scan for services
     * 
     * @return array<string>
     */
    private static function getBasePaths(): array
    {
        $basePaths = ['app'];

        // Add engine core paths
        $basePaths[] = 'engine/Core';

        // Add module paths
        $modulesPath = BASE_PATH . '/modules';
        if (is_dir($modulesPath)) {
            $modules = array_filter(
                scandir($modulesPath),
                fn($item) => is_dir("$modulesPath/$item") && !in_array($item, ['.', '..'])
            );

            foreach ($modules as $moduleName) {
                $moduleSrcPath = "$modulesPath/$moduleName/src";
                if (is_dir($moduleSrcPath)) {
                    $basePaths[] = "modules/$moduleName/src";
                }
            }
        }

        return $basePaths;
    }

    /**
     * Check if a class has Service or Discoverable attribute
     */
    private static function hasServiceAttribute(ReflectionClass $reflectionClass): bool
    {
        return !empty($reflectionClass->getAttributes(Service::class)) ||
               !empty($reflectionClass->getAttributes(Discoverable::class));
    }

    /**
     * @throws ReflectionException
     */
    private static function registerService(ReflectionClass $reflectionClass, Container $container): void
    {
        if (
            !$reflectionClass->isInterface() &&
            !$reflectionClass->isAbstract() &&
            self::hasServiceAttribute($reflectionClass)
        ) {
            $container->register($reflectionClass->getName());
        }
    }

    /**
     * @throws ReflectionException
     * @throws MissingServiceException
     * @throws ResolveParameterException
     */
    private static function registerEventListeners(ReflectionClass $reflectionClass, EventDispatcher $eventDispatcher, Container $container): void
    {
        foreach ($reflectionClass->getMethods(ReflectionMethod::IS_PUBLIC) as $method) {
            $attributes = $method->getAttributes(EventListener::class);
            foreach ($attributes as $attribute) {
                $listenerAttributeInstance = $attribute->newInstance();
                $eventClass = $listenerAttributeInstance->eventClass;

                $listenerInstance = $container->has($reflectionClass->getName())
                    ? $container->get($reflectionClass->getName())
                    : $reflectionClass->newInstance();

                $eventDispatcher->addListener($eventClass, [$listenerInstance, $method->getName()]);
            }
        }
    }

    /**
     * Generate legacy class map cache for backward compatibility
     * 
     * @param array<string, array{file: string, mtime: int, attributes: array<string>}> $classMap
     */
    private static function generateLegacyClassMapCache(array $classMap): void
    {
        if (!is_dir(dirname(self::CLASS_MAP_CACHE_FILE))) {
            mkdir(dirname(self::CLASS_MAP_CACHE_FILE), 0777, true);
        }

        $legacyClassMap = [];
        foreach ($classMap as $className => $metadata) {
            $legacyClassMap[$className] = $metadata['file'] ?? '';
        }

        $cacheContent = "<?php return " . var_export($legacyClassMap, true) . ";";
        file_put_contents(self::CLASS_MAP_CACHE_FILE, $cacheContent);
    }
}
