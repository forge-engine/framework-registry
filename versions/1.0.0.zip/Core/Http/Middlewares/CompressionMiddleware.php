<?php

declare(strict_types=1);

namespace Forge\Core\Http\Middlewares;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Middleware\Attributes\RegisterMiddleware;
use Forge\Exceptions\InvalidMiddlewareResponse;

#[Service]
#[RegisterMiddleware(group: 'global', order: 4, allowDuplicate: true, enabled: true)]
class CompressionMiddleware extends Middleware
{
    public function handle(Request $request, callable $next): Response
    {
        $response = $next($request);

        if (!$response instanceof Response) {
            throw new InvalidMiddlewareResponse();
        }

        if (isset($response->getHeaders()['Content-Encoding'])) {
            return $response;
        }

        $acceptEncoding = $request->getHeader('Accept-Encoding');
        $contentType = $response->getHeaders()['Content-Type'] ?? '';

        if (!str_contains($contentType, 'text/') && !str_contains($contentType, 'json')) {
            return $response;
        }

        $content = $response->getContent();
        if (empty($content) || $acceptEncoding === null) {
            return $response;
        }

        if (str_contains($acceptEncoding, 'gzip')) {
            $compressedContent = gzencode($content, 9);
            if ($compressedContent !== false) {
                $response->setHeader('Content-Encoding', 'gzip');
                $response->setContent($compressedContent);
                $response->setHeader('Content-Length', (string)strlen($compressedContent));
            }
        } elseif (str_contains($acceptEncoding, 'deflate')) {
            $compressedContent = gzdeflate($content, 9);
            if ($compressedContent !== false) {
                $response->setHeader('Content-Encoding', 'deflate');
                $response->setContent($compressedContent);
                $response->setHeader('Content-Length', (string)strlen($compressedContent));
            }
        }

        return $response;
    }
}
