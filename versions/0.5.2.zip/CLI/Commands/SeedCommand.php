<?php


declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Seeders\SeederManager;
use Forge\Core\Module\Attributes\CLICommand;
use Throwable;

#[CLICommand(name: 'seed', description: 'Run database seeders')]
class SeedCommand extends Command
{
    public function __construct(private readonly SeederManager $manager)
    {
    }

    /**
     * @throws Throwable
     */
    public function execute(array $args): int
    {
        $type = $this->getArgValue($args, '--type');
        $module = $this->getArgValue($args, '--module');

        if ($type === null) {
            $type = 'app';
        }

        $managerType = match ($type) {
            'app' => 'app',
            'engine' => 'core',
            'module' => 'module',
            default => 'all',
        };

        $this->info("Running seeders...");

        $this->manager->run($managerType, $module);

        $this->success("Seeding completed successfully");
        return 0;
    }

    private function getArgValue(array $args, string $key): ?string
    {
        foreach ($args as $arg) {
            if (str_starts_with($arg, $key . '=')) {
                return explode('=', $arg)[1] ?? null;
            }
        }
        return null;
    }
}