<?php

declare(strict_types=1);

namespace Forge\Core;

if (preg_match('/\.env$/i', $_SERVER["REQUEST_URI"])) {
    header("HTTP/1.1 403 Forbidden");
    exit();
}

use Forge\Core\Bootstrap\Bootstrap;
use Forge\Core\Debug\Metrics;
use Forge\Core\Http\Request;
use Throwable;

final class Engine
{
    /**
     * @throws Throwable
     */
    public static function init(): void
    {
        Metrics::start('engine_resolution');
        $bootstrap = Bootstrap::getInstance();
        $kernel = $bootstrap->getKernel();

        $compiledFile = BASE_PATH . '/storage/framework/cache/compiled_hooks.php';
        if (file_exists($compiledFile)) {
            include $compiledFile;
        }

        Metrics::stop('engine_resolution');
        $response = $kernel->handler(Request::createFromGlobals());

        $response->send();
    }
}
