<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use App\Modules\ForgeEvents\Attributes\EventListener;
use App\Modules\ForgeEvents\Services\EventDispatcher;
use Forge\Core\Config\Config;
use Forge\Core\DI\Attributes\Discoverable;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\DI\Container;
use Forge\Core\Helpers\ModuleHelper;
use Forge\Core\Module\Attributes\LifecycleHook;
use Forge\Core\Module\HookManager;
use Forge\Core\Services\AttributeDiscoveryService;
use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;
use ReflectionClass;
use ReflectionException;
use ReflectionMethod;

final class ServiceDiscoverSetup
{
  private const string CLASS_MAP_CACHE_FILE =
    BASE_PATH . "/storage/framework/cache/class-map.php";

  /**
   * @throws ReflectionException
   * @throws MissingServiceException
   * @throws ResolveParameterException
   */
  public static function setup(Container $container): void
  {
    if ($container->has(\App\Modules\ForgeEvents\Services\EventDispatcher::class)) {
      /** @var EventDispatcher $eventDispatcherService */
      $eventDispatcherService = $container->get(EventDispatcher::class);
    } else {
      $eventDispatcherService = null;
    }

    $discoveryService = new AttributeDiscoveryService();
    $basePaths = self::getBasePaths($container);

    $attributeClasses = [
      Service::class,
      Discoverable::class,
    ];

    $classMap = $discoveryService->discover($basePaths, $attributeClasses);

    foreach ($classMap as $className => $metadata) {
      if (!class_exists($className)) {
        $filepath = $metadata['file'] ?? '';
        if ($filepath && file_exists($filepath)) {
          try {
            require_once $filepath;
          } catch (\Exception $e) {
            continue;
          }
        }
      }

      if (!class_exists($className)) {
        continue;
      }

      try {
        $reflectionClass = new ReflectionClass($className);
        if (self::hasServiceAttribute($reflectionClass)) {
          self::registerService($reflectionClass, $container);
        }

        if ($eventDispatcherService) {
          self::registerEventListeners($reflectionClass, $eventDispatcherService, $container);
        }

        // Register lifecycle hooks from services
        self::registerServiceLifecycleHooks($reflectionClass, $container);
      } catch (ReflectionException $e) {
        //
      }
    }
    self::generateLegacyClassMapCache($classMap);
  }

  /**
   * Get base paths to scan for services
   * Excludes disabled modules from discovery
   *
   * @return array<string>
   */
  private static function getBasePaths(Container $container): array
  {
    $basePaths = ['app'];
    $basePaths[] = 'engine/Core';
    $modulesPath = BASE_PATH . '/modules';

    if (is_dir($modulesPath)) {
      $config = null;
      try {
        if ($container->has(Config::class)) {
          $config = $container->get(Config::class);
        }
      } catch (\Throwable $e) {
      }

      $modules = array_filter(
        scandir($modulesPath),
        fn($item) => is_dir("$modulesPath/$item") && !in_array($item, ['.', '..'])
      );

      foreach ($modules as $moduleName) {
        if (ModuleHelper::isModuleDisabled($moduleName, $config)) {
          continue;
        }

        $moduleSrcPath = "$modulesPath/$moduleName/src";
        if (is_dir($moduleSrcPath)) {
          $basePaths[] = "modules/$moduleName/src";
        }
      }
    }

    return $basePaths;
  }

  /**
   * Check if a class has Service or Discoverable attribute
   */
  private static function hasServiceAttribute(ReflectionClass $reflectionClass): bool
  {
    return !empty($reflectionClass->getAttributes(Service::class)) ||
      !empty($reflectionClass->getAttributes(Discoverable::class));
  }

  /**
   * @throws ReflectionException
   */
  private static function registerService(ReflectionClass $reflectionClass, Container $container): void
  {
    if (
      !$reflectionClass->isInterface() &&
      !$reflectionClass->isAbstract() &&
      self::hasServiceAttribute($reflectionClass)
    ) {
      $container->register($reflectionClass->getName());
    }
  }

  /**
   * @throws ReflectionException
   * @throws MissingServiceException
   * @throws ResolveParameterException
   */
  private static function registerEventListeners(ReflectionClass $reflectionClass, EventDispatcher $eventDispatcher, Container $container): void
  {
    foreach ($reflectionClass->getMethods(ReflectionMethod::IS_PUBLIC) as $method) {
      $attributes = $method->getAttributes(EventListener::class);
      foreach ($attributes as $attribute) {
        $listenerAttributeInstance = $attribute->newInstance();
        $eventClass = $listenerAttributeInstance->eventClass;

        $listenerInstance = $container->has($reflectionClass->getName())
          ? $container->get($reflectionClass->getName())
          : $reflectionClass->newInstance();

        $eventDispatcher->addListener($eventClass, [$listenerInstance, $method->getName()]);
      }
    }
  }

  /**
   * Register lifecycle hooks from services (non-module classes)
   *
   * @throws ReflectionException
   * @throws MissingServiceException
   * @throws ResolveParameterException
   */
  private static function registerServiceLifecycleHooks(ReflectionClass $reflectionClass, Container $container): void
  {
    $hasModuleAttribute = !empty($reflectionClass->getAttributes(\Forge\Core\Module\Attributes\Module::class));
    if ($hasModuleAttribute) {
      return;
    }

    foreach ($reflectionClass->getMethods(ReflectionMethod::IS_PUBLIC) as $method) {
      $lifecycleHookAttributes = $method->getAttributes(LifecycleHook::class);
      foreach ($lifecycleHookAttributes as $attribute) {
        $hookInstance = $attribute->newInstance();
        $hookName = $hookInstance->hook;
        $methodName = $method->getName();

        $serviceInstance = $container->has($reflectionClass->getName())
          ? $container->get($reflectionClass->getName())
          : $container->make($reflectionClass->getName());

        $callback = [$serviceInstance, $methodName];
        HookManager::addHook($hookName, $callback);
      }
    }
  }

  /**
   * Generate legacy class map cache for backward compatibility
   *
   * @param array<string, array{file: string, mtime: int, attributes: array<string>}> $classMap
   */
  private static function generateLegacyClassMapCache(array $classMap): void
  {
    if (!is_dir(dirname(self::CLASS_MAP_CACHE_FILE))) {
      mkdir(dirname(self::CLASS_MAP_CACHE_FILE), 0777, true);
    }

    $legacyClassMap = [];
    foreach ($classMap as $className => $metadata) {
      $legacyClassMap[$className] = $metadata['file'] ?? '';
    }

    $cacheContent = "<?php return " . var_export($legacyClassMap, true) . ";";
    file_put_contents(self::CLASS_MAP_CACHE_FILE, $cacheContent);
  }
}
