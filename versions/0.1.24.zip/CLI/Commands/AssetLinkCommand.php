<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Helpers\Strings;
use Forge\Core\Module\Attributes\CLICommand;

#[CLICommand(name:'asset:link', description: 'Create a symbolic assets link to public/assets')]
final class AssetLinkCommand extends Command
{
    private const MODULES_PATH = BASE_PATH . '/modules/';
    private const PUBLIC_ASSETS_MODULES_PATH = BASE_PATH . '/public/assets/modules/';

    private const APP_ASSET_PATH = BASE_PATH . '/app/resources/';
    private const PUBLIC_ASSETS_APP_PATH = BASE_PATH . '/public/assets/';

    private const ALLOWED_TYPES = ['app', 'module'];

    public function execute(array $args): int
    {
        if (count($args) < 1) {
            $this->error('Asset type is required');
            $this->line('Usage: php forge.php asset:link --type=module|app <module-name>');
            return 1;
        }

        $type = $this->getPublishType($args);

        if ($type === 'app') {
            $targetPath = self::APP_ASSET_PATH . 'assets';
            $linkPath = self::PUBLIC_ASSETS_APP_PATH . 'app';
            $this->linkAppAsset($targetPath, $linkPath);
            return 0;
        } elseif ($type === 'module') {
            if (!isset($args[1])) {
                $this->error('Module name required');
                $this->line('Usage: php forge.php asset:link --type=module <module-name>');
                return 1;
            }

            $moduleName = Strings::toKebabCase($args[1]);
            $modulePascalCase = Strings::toPascalCase($args[1]);

            $targetPath = self::MODULES_PATH . $modulePascalCase . "/src/resources/assets";
            $linkPath = self::PUBLIC_ASSETS_MODULES_PATH . $moduleName;

            $this->linkModuleAsset($targetPath, $linkPath);
            return 0;
        } else {
            return 0;
        }

        return 0;
    }

    private function linkAppAsset(string $targetPath, string $linkPath): int
    {
        if ($this->ensureTargetDirectoryExist($linkPath) !== 0) {
            return 1;
        }

        if ($this->checkIfModuleAssetDirectoryExists($targetPath) !== 0) {
            return 1;
        }

        if ($this->checkIfModuleAssetIsLinked($linkPath) === 0) {
            $this->info("The link [$linkPath] already exists.");
            return 0;
        }

        if ($this->symLinkModuleAsset($targetPath, $linkPath) !== 0) {
            return 1;
        }
        return 0;
    }

    private function linkModuleAsset($targetPath, $linkPath): int
    {
        if ($this->ensureTargetDirectoryExist($linkPath) !== 0) {
            return 1;
        }

        if ($this->checkIfModuleAssetDirectoryExists($targetPath) !== 0) {
            return 1;
        }

        if ($this->checkIfModuleAssetIsLinked($linkPath) === 0) {
            $this->info("The link [$linkPath] already exists.");
            return 0;
        }

        if ($this->symLinkModuleAsset($targetPath, $linkPath) !== 0) {
            return 1;
        }
        return 0;
    }


    private function getPublishType(array $args): string
    {
        foreach ($args as $arg) {
            if (str_starts_with($arg, '--type=')) {
                $type = strtolower(substr($arg, 7));
                if (in_array($type, self::ALLOWED_TYPES)) {
                    return $type;
                }
            }
        }
        return 'app';
    }

    private function checkIfModuleAssetDirectoryExists(string $targetPath): int
    {
        if (!is_dir($targetPath)) {
            $this->error("The module asset directory [$targetPath] does not exist.");
            return 1;
        }
        return 0;
    }

    private function checkIfModuleAssetIsLinked(string $linkPath): int
    {
        if (file_exists($linkPath)) {
            $this->info("The link [$linkPath] already exists.");
            return 0;
        }
        return 1;
    }

    private function ensureTargetDirectoryExist(string $linkPath): int
    {
        $directory = dirname($linkPath);

        if (!is_dir($directory)) {
            if (!mkdir($directory, 0755, true)) {
                $this->error("Unable to create the directory [{".$directory."}]");
                return 1;
            }
            $this->success("Created directory: $directory");
        }
        return 0;
    }

    private function symLinkModuleAsset(string $targetPath, string $linkPath): int
    {
        if (symlink($targetPath, $linkPath)) {
            $this->success("The link [$linkPath] has been created, pointing to [$targetPath]");
            return 0;
        } else {
            $this->error("Failed to create the link [$linkPath] pointing to [$targetPath]");
            return 1;
        }
    }
}
