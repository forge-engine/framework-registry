<?php

namespace Forge\Http;

use Forge\Core\Helpers\App;
use Forge\Http\Exceptions\ValidationException;
use Forge\Modules\ForgeDatabase\Contracts\DatabaseInterface;

class Validator
{
    protected array $data;
    protected array $rules;
    protected array $messages;
    protected array $errors = [];
    protected array $validated = [];
    protected static array $customRules = [];
    protected ?DatabaseInterface $database;

    public function __construct(array $data, array $rules, array $messages = [])
    {
        $this->data = $data;
        $this->rules = $rules;
        $this->messages = $messages;
        $this->database = App::getContainer()->get(DatabaseInterface::class);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public static function extend(string $rule, \Closure $callback): void
    {
        static::$customRules[$rule] = $callback;
    }

    public function validate(): array
    {
        foreach ($this->rules as $field => $rules) {
            $rules = explode('|', $rules);
            $value = $this->getValue($field);

            foreach ($rules as $rule) {
                $this->validateRule($field, $value, $rule);
            }

            if (!isset($this->errors[$field])) {
                $this->validated[$field] = $value;
            }
        }

        if (!empty($this->errors)) {
            throw new ValidationException($this->errors);
        }

        return $this->validated;
    }

    protected function validateRule(string $field, $value, string $rule): void
    {
        [$ruleName, $parameters] = $this->parseRule($rule);

        if (isset(static::$customRules[$ruleName])) {
            $this->validateCustomRule($field, $value, $ruleName, $parameters);
            return;
        }

        $method = 'validate' . str_replace(' ', '', ucwords(str_replace('_', ' ', $ruleName)));
        if (method_exists($this, $method)) {
            $this->$method($field, $value, $parameters);
        } else {
            throw new \InvalidArgumentException("Validation rule [$ruleName] does not exist.");
        }
    }

    protected function parseRule(string $rule): array
    {
        $parts = explode(':', $rule, 2);
        return [
            $parts[0],
            isset($parts[1]) ? explode(',', $parts[1]) : []
        ];
    }

    protected function getValue(string $field)
    {
        $keys = explode('.', $field);
        $value = $this->data;

        foreach ($keys as $key) {
            if (is_array($value) && array_key_exists($key, $value)) {
                $value = $value[$key];
            } else {
                return null;
            }
        }

        return $value;
    }

    protected function validateCustomRule(string $field, $value, string $rule, array $parameters): void
    {
        $callback = static::$customRules[$rule];
        $valid = $callback($field, $value, $parameters, $this->data);

        if (!$valid) {
            $this->addError($field, $rule, $parameters);
        }
    }

    // Built-in validation rules
    protected function validateRequired(string $field, $value): void
    {
        if (is_null($value) || (is_string($value) && trim($value) === '')) {
            $this->addError($field, 'required');
        }
    }

    protected function validateMax(string $field, $value, array $parameters): void
    {
        if (strlen((string)$value) > $parameters[0]) {
            $this->addError($field, 'max', ['max' => $parameters[0]]);
        }
    }

    protected function validateMin(string $field, $value, array $parameters): void
    {
        if (strlen((string)$value) < $parameters[0]) {
            $this->addError($field, 'min', ['min' => $parameters[0]]);
        }
    }

    protected function validateEmail(string $field, $value): void
    {
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, 'email');
        }
    }

    protected function validateUnique(string $field, $value, array $parameters): void
    {
        if (empty($parameters) || count($parameters) < 1) {
            throw new \InvalidArgumentException("Validation rule [unique] requires at least one parameter: table name.");
        }

        $table = $parameters[0];
        $column = $parameters[1] ?? $field;

        if (!$this->database instanceof DatabaseInterface) {
            throw new \LogicException("DatabaseInterface dependency is not injected into Validator to use 'unique' rule.");
        }

        $query = "SELECT 1 FROM `{$table}` WHERE `{$column}` = :value";
        $result = $this->database->query($query, ['value' => $value]);

        if (!empty($result)) {
            $this->addError($field, 'unique');
        }
    }

    protected function validateConfirmed(string $field, $value): void
    {
        $confirmationField = $field . '_confirmation';
        $confirmationValue = $this->getValue($confirmationField);

        if ($value !== $confirmationValue) {
            $this->addError($field, 'confirmed');
        }
    }

    protected function addError(string $field, string $rule, array $replace = []): void
    {
        $messageKey = "{$field}.{$rule}";

        $message = $this->messages[$messageKey] ?? $this->getDefaultMessage($field, $rule, $replace);

        $this->errors[$field][] = $message;
    }

    protected function getDefaultMessage(string $field, string $rule, array $replace): string
    {
        $messages = [
            'required' => "The :field field is required.",
            'max' => "The :field field must not exceed :max characters.",
            'min' => "The :field field must be minimum :min characters.",
            'email' => "The :field must be a valid email address.",
            'unique' => "The :field has already been taken.",
            'confirmed' => "The :field confirmation does not match.",
        ];

        $message = $messages[$rule] ?? "The :field field is invalid.";

        $replace = array_merge(['field' => $field], $replace);

        foreach ($replace as $key => $value) {
            $message = str_replace(":{$key}", $value, $message);
        }

        return $message;
    }
}