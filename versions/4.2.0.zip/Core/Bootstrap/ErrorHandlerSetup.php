<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\Core\Contracts\ErrorHandlerInterface;
use Forge\Core\DI\Container;
use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;
use ReflectionException;

/**
 * Sets up error handling by discovering ErrorHandlerInterface implementations.
 * This allows any module to provide error handling capabilities.
 */
final class ErrorHandlerSetup
{
  /**
   * Discover and register error handlers from modules.
   * Error handlers are registered early to catch errors during bootstrap.
   *
   * @param Container $container
   * @return void
   * @throws ReflectionException
   * @throws MissingServiceException
   * @throws ResolveParameterException
   */
  public static function setup(Container $container): void
  {

    ini_set(
      "display_errors",
      \Forge\Core\Config\Environment::getInstance()->isDevelopment() ? "1" : "0",
    );
    error_reporting(E_ALL);

    try {
      if ($container->has(ErrorHandlerInterface::class)) {
        $errorHandler = $container->get(ErrorHandlerInterface::class);
        return;
      }

      $errorHandlers = $container->getAll(ErrorHandlerInterface::class);

      if (!empty($errorHandlers)) {
        $errorHandler = $errorHandlers[0];
      }
    } catch (\Throwable $e) {
      error_log("Failed to discover error handler: " . $e->getMessage());
    }
  }
}
