<?php

declare(strict_types=1);

namespace Forge\Core\Structure;

use Forge\Core\DI\Attributes\Service;

#[Service]
final class StructureResolver
{
  private const string INTERNAL_STRUCTURE_PATH = __DIR__ . '/forge_structure.php';
  private const string USER_STRUCTURE_PATH_1 = BASE_PATH . '/forge_structure.php';

  private ?array $internalStructure = null;
  private ?array $userStructure = null;
  private array $appStructure = [];
  private array $moduleStructures = [];
  private array $moduleAttributeStructures = [];

  public function getAppPath(string $type): string
  {
    if (empty($this->appStructure)) {
      $this->loadAppStructure();
    }

    if (!isset($this->appStructure[$type])) {
      throw new \InvalidArgumentException("Unknown structure type: {$type}");
    }

    return $this->appStructure[$type];
  }

  public function getModulePath(string $module, string $type): string
  {
    if (!isset($this->moduleStructures[$module])) {
      $this->loadModuleStructure($module);
    }

    $moduleStructure = $this->moduleStructures[$module];

    if (!isset($moduleStructure[$type])) {
      throw new \InvalidArgumentException("Unknown structure type: {$type} for module: {$module}");
    }

    return $moduleStructure[$type];
  }

  public function registerModuleStructure(string $module, array $structure): void
  {
    $this->moduleAttributeStructures[$module] = $structure;
    unset($this->moduleStructures[$module]);
  }

  private function loadAppStructure(): void
  {
    $internal = $this->getInternalStructure();
    $user = $this->getUserStructure();

    $this->appStructure = $internal['app'] ?? [];

    if ($user !== null && isset($user['app'])) {
      $this->appStructure = array_merge($this->appStructure, $user['app']);
    }
  }

  private function loadModuleStructure(string $module): void
  {
    if (isset($this->moduleAttributeStructures[$module])) {
      $moduleAttr = $this->moduleAttributeStructures[$module];
      $internal = $this->getInternalStructure();
      $internalModules = $internal['modules'] ?? [];

      $this->moduleStructures[$module] = array_merge($internalModules, $moduleAttr);
      return;
    }

    $internal = $this->getInternalStructure();
    $user = $this->getUserStructure();

    $this->moduleStructures[$module] = $internal['modules'] ?? [];

    if ($user !== null && isset($user['modules'])) {
      $this->moduleStructures[$module] = array_merge(
        $this->moduleStructures[$module],
        $user['modules']
      );
    }
  }

  private function getInternalStructure(): array
  {
    if ($this->internalStructure !== null) {
      return $this->internalStructure;
    }

    if (!file_exists(self::INTERNAL_STRUCTURE_PATH)) {
      throw new \RuntimeException("Internal structure file not found: " . self::INTERNAL_STRUCTURE_PATH);
    }

    $this->internalStructure = require self::INTERNAL_STRUCTURE_PATH;

    if (!is_array($this->internalStructure)) {
      throw new \RuntimeException("Internal structure file must return an array");
    }

    return $this->internalStructure;
  }

  private function getUserStructure(): ?array
  {
    if ($this->userStructure !== null) {
      return $this->userStructure;
    }

    $userPath = null;
    if (file_exists(self::USER_STRUCTURE_PATH_1)) {
      $userPath = self::USER_STRUCTURE_PATH_1;
    }

    if ($userPath === null) {
      $this->userStructure = null;
      return null;
    }

    $structure = require $userPath;

    if (!is_array($structure)) {
      throw new \RuntimeException("User structure file must return an array: {$userPath}");
    }

    $this->userStructure = $structure;
    return $this->userStructure;
  }

  public function getFullAppStructure(): array
  {
    if (empty($this->appStructure)) {
      $this->loadAppStructure();
    }
    return $this->appStructure;
  }

  public function getFullModuleStructure(string $module): array
  {
    if (!isset($this->moduleStructures[$module])) {
      $this->loadModuleStructure($module);
    }
    return $this->moduleStructures[$module];
  }
}
