<?php

declare(strict_types=1);

namespace Forge\Core\Contracts;

use Forge\Core\Http\Request;

/**
 * Interface for middleware pipeline resolution.
 * Allows applications to control which middlewares are applied, in what order,
 * and enables filtering/removal based on request/route context.
 */
interface MiddlewarePipelineInterface
{
  /**
   * Get global middlewares for a request.
   * These are middlewares that apply to all routes.
   *
   * @param Request $request The current request
   * @return array<string> Array of middleware class names
   */
  public function getGlobalMiddlewares(Request $request): array;

  /**
   * Resolve the final middleware list for a route.
   * Combines global middlewares with route-specific middlewares.
   *
   * @param array<string> $routeMiddlewares Middlewares specified on the route
   * @param Request $request The current request
   * @param array<string, mixed> $route The route data
   * @return array<string> Final array of middleware class names in execution order
   */
  public function resolveMiddlewares(
    array $routeMiddlewares,
    Request $request,
    array $route
  ): array;
}
