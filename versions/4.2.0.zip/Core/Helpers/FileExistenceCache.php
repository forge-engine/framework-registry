<?php

declare(strict_types=1);

namespace Forge\Core\Helpers;

/**
 * Simple cache for file existence checks to reduce redundant file system calls.
 * Useful during bootstrap when the same files are checked multiple times.
 */
final class FileExistenceCache
{
  /** @var array<string, bool> */
  private static array $cache = [];

  /**
   * Check if a file exists, using cache to avoid redundant file system calls.
   * Cache is cleared automatically if file modification time changes.
   *
   * @param string $filePath Absolute path to the file
   * @return bool True if file exists, false otherwise
   */
  public static function exists(string $filePath): bool
  {
    $normalizedPath = str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $filePath);

    if (isset(self::$cache[$normalizedPath])) {
      return self::$cache[$normalizedPath];
    }

    $exists = file_exists($normalizedPath);
    self::$cache[$normalizedPath] = $exists;

    return $exists;
  }

  /**
   * Clear the cache for a specific file or all files.
   *
   * @param string|null $filePath If provided, clears cache for this file only. If null, clears all caches.
   */
  public static function clear(?string $filePath = null): void
  {
    if ($filePath === null) {
      self::$cache = [];
    } else {
      $normalizedPath = str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $filePath);
      unset(self::$cache[$normalizedPath]);
    }
  }

  /**
   * Get all cached file paths.
   *
   * @return array<string> Array of cached file paths
   */
  public static function getCachedPaths(): array
  {
    return array_keys(self::$cache);
  }
}
