<?php

declare(strict_types=1);

namespace Forge\Core\Http;

use Forge\Core\Routing\Router;
use Forge\Core\DI\Container;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;

final class Kernel
{
    public function __construct(
        private Router $router,
        private Container $container
    ) {
    }

    public function handler(Request $request): Response
    {
        try {
            HookManager::triggerHook(LifecycleHookName::BEFORE_REQUEST);

            $content = $this->router->dispatch($request);
            if ($content instanceof Response) {
                return $content;
            }
            return new Response((string) $content);
        } catch (\Throwable $exception) {
            return new Response("Error: " . $exception->getMessage(), 500);
        }
    }
}
