<?php

declare(strict_types=1);

namespace Forge\Core\Services;

use Forge\Core\DI\Attributes\Service;
use InvalidArgumentException;

#[Service]
final class VersionService
{
    public function detectModuleVersion(string $moduleName): string
    {
        $forgeJsonPath = BASE_PATH . "/modules/{$moduleName}/forge.json";
        if (!file_exists($forgeJsonPath)) {
            return '0.1.0';
        }
        
        $data = json_decode(file_get_contents($forgeJsonPath), true);
        return $data['version'] ?? '0.1.0';
    }
    
    public function detectFrameworkVersion(): string
    {
        $versionFile = BASE_PATH . "/engine/Core/Bootstrap/Version.php";
        if (!file_exists($versionFile)) {
            return '0.1.0';
        }
        
        $content = file_get_contents($versionFile);
        if (preg_match('/define\s*\(\s*["\']FRAMEWORK_VERSION["\']\s*,\s*["\']([^"\']+)["\']/', $content, $matches)) {
            return $matches[1];
        }
        
        return '0.1.0';
    }
    
    public function suggestNextVersion(string $currentVersion, string $type): string
    {
        if (!preg_match('/^(\d+)\.(\d+)\.(\d+)$/', $currentVersion, $matches)) {
            throw new InvalidArgumentException("Invalid version format: {$currentVersion}");
        }
        
        $major = (int)$matches[1];
        $minor = (int)$matches[2];
        $patch = (int)$matches[3];
        
        return match($type) {
            'major' => ($major + 1) . '.0.0',
            'minor' => $major . '.' . ($minor + 1) . '.0',
            'patch' => $major . '.' . $minor . '.' . ($patch + 1),
            default => throw new InvalidArgumentException("Invalid version type: {$type}")
        };
    }
    
    public function updateModuleVersion(string $moduleName, string $version): void
    {
        $forgeJsonPath = BASE_PATH . "/modules/{$moduleName}/forge.json";
        if (!file_exists($forgeJsonPath)) {
            throw new InvalidArgumentException("Module forge.json not found: {$forgeJsonPath}");
        }
        
        $data = json_decode(file_get_contents($forgeJsonPath), true);
        $data['version'] = $version;
        
        file_put_contents($forgeJsonPath, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }
    
    public function updateFrameworkVersion(string $version): void
    {
        $versionFile = BASE_PATH . "/engine/Core/Bootstrap/Version.php";
        if (!file_exists($versionFile)) {
            throw new InvalidArgumentException("Version.php not found: {$versionFile}");
        }
        
        $content = file_get_contents($versionFile);
        $content = preg_replace(
            '/define\s*\(\s*["\']FRAMEWORK_VERSION["\']\s*,\s*["\'][^"\']+["\']\s*\)\s*;/',
            "define(\"FRAMEWORK_VERSION\", \"{$version}\");",
            $content
        );
        
        if ($content === null) {
            throw new \RuntimeException("Failed to update framework version in Version.php");
        }
        
        file_put_contents($versionFile, $content);
    }
    
    public function compareVersions(string $version1, string $version2): int
    {
        return version_compare($version1, $version2);
    }
    
    public function updateModuleEntryFileVersion(string $moduleName, string $version): void
    {
        $possiblePaths = [
            BASE_PATH . "/modules/{$moduleName}/src/{$moduleName}Module.php",
            BASE_PATH . "/modules/{$moduleName}/src/{$moduleName}.php",
        ];
        
        $entryFilePath = null;
        foreach ($possiblePaths as $path) {
            if (file_exists($path)) {
                $entryFilePath = $path;
                break;
            }
        }
        
        if (!$entryFilePath) {
            $dir = BASE_PATH . "/modules/{$moduleName}/src";
            if (is_dir($dir)) {
                $files = glob($dir . "/*Module.php");
                if (!empty($files)) {
                    $entryFilePath = $files[0];
                }
            }
        }
        
        if (!$entryFilePath || !file_exists($entryFilePath)) {
            throw new InvalidArgumentException("Module entry file not found for module: {$moduleName}");
        }
        
        $content = file_get_contents($entryFilePath);
        if ($content === false) {
            throw new \RuntimeException("Failed to read module entry file: {$entryFilePath}");
        }
        
        $pattern = '/(#\[Module\s*\([^)]*version\s*:\s*["\'])([^"\']+)(["\'])/';
        $updatedContent = preg_replace($pattern, '$1' . $version . '$3', $content);
        
        if ($updatedContent === null || $updatedContent === $content) {
            throw new \RuntimeException("Failed to update version in module entry file: {$entryFilePath}. Pattern not found.");
        }
        
        $providesPattern = '/(#\[Provides\s*\([^)]*version\s*:\s*["\'])([^"\']+)(["\'])/';
        $updatedContent = preg_replace($providesPattern, '$1' . $version . '$3', $updatedContent);
        
        if (file_put_contents($entryFilePath, $updatedContent) === false) {
            throw new \RuntimeException("Failed to write updated module entry file: {$entryFilePath}");
        }
    }
}

