<?php

declare(strict_types=1);

namespace Forge\CLI\Commands\Generate;

use Exception;
use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\CliGenerator;
use Forge\Traits\StringHelper;
use Forge\Core\Services\TemplateGenerator;

#[Cli(
    command: 'generate:module',
    description: 'Create a new module with basic structure',
    usage: 'generate:module [--name=ModuleName] [--description="Module description"] [--version=1.0.0]',
    examples: [
        'generate:module --name=Blog',
        'generate:module --name=Blog --description="Blog module" --version=1.0.0',
        'generate:module   (starts wizard)',
    ]
)]
final class GenerateModuleCommand extends Command
{
    use StringHelper;
    use CliGenerator;

    #[Arg(name: 'name', description: 'Module name in PascalCase (without suffix)', validate: '/^\w+$/')]
    private string $name;

    #[Arg(name: 'description', description: 'Module description', required: false)]
    private ?string $description = null;

    #[Arg(name: 'version', description: 'Module version (e.g., 0.1.0)', default: '0.1.0', required: false)]
    private string $version = '0.1.0';

    public function __construct(private readonly TemplateGenerator $templateGenerator)
    {
    }

    /**
     * @throws Exception
     */
    public function execute(array $args): int
    {
        $this->wizard($args);

        $this->name = $this->toPascalCase($this->name);
        if (!$this->isPascalCase($this->name)) {
            $this->error("Invalid module name. Use PascalCase (e.g., MyModule).");
            return 1;
        }

        if (!$this->description) {
            $this->description = $this->templateGenerator->askQuestion(
                "Module description: ",
                "A brief description of the module."
            );
        }

        if (!$this->version) {
            $this->version = $this->templateGenerator->askQuestion(
                "Module version (e.g., 1.0.0): ",
                "1.0.0"
            );
        }

        $moduleDir = BASE_PATH . '/modules/' . $this->name;
        if (is_dir($moduleDir)) {
            $this->error("Module directory already exists: $moduleDir");
            return 1;
        }
        mkdir($moduleDir . '/src/Contracts', 0755, true);
        mkdir($moduleDir . '/src/Services', 0755, true);
        mkdir($moduleDir . '/src/Commands', 0755, true);

        $this->generateModuleFiles($moduleDir);

        $this->success("Module '{$this->name}' created successfully!");
        return 0;
    }

    private function generateModuleFiles(string $moduleDir): void
    {
        $tokens = [
            '{{ moduleName }}' => $this->name,
            '{{ command }}' => $this->toKebabCase($this->name),
            '{{ interfaceName }}' => $this->name . 'Interface',
            '{{ serviceName }}' => $this->name . 'Service',
            '{{ moduleDescription }}' => $this->description,
            '{{ moduleVersion }}' => $this->version,
            '{{ moduleConfig }}' => $this->toSnakeCase($this->name),
        ];

        $this->generateFromStub('modules/forge', $moduleDir . '/forge.json', $tokens);

        $this->generateFromStub(
            'modules/command',
            $moduleDir . '/src/Commands/' . $this->name . 'Command.php',
            $tokens
        );

        $this->generateFromStub(
            'modules/interface',
            $moduleDir . '/src/Contracts/' . $this->name . 'Interface.php',
            $tokens
        );

        $this->generateFromStub(
            'modules/service',
            $moduleDir . '/src/Services/' . $this->name . 'Service.php',
            $tokens
        );

        $this->generateFromStub(
            'modules/module',
            $moduleDir . '/src/' . $this->name . 'Module.php',
            $tokens
        );
    }
}