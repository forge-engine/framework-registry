<?php

declare(strict_types=1);

use Forge\Core\Database\Attributes\GroupMigration;
use Forge\Core\Database\Attributes\Table;
use Forge\Core\Database\Attributes\Column;
use Forge\Core\Database\Attributes\Relations\BelongsTo;
use Forge\Core\Database\Enums\ColumnType;
use Forge\Core\Database\Migrations\Migration;

#[GroupMigration(name: 'security')]
#[Table(name: 'api_key_permissions')]
#[BelongsTo(related: 'api_keys', foreignKey:'api_key_id', onDelete: 'CASCADE')]
#[BelongsTo(related: 'permissions', foreignKey:'permission_id', onDelete: 'CASCADE')]
class CreateApiKeyPermissionsTable extends Migration
{
    #[Column(name: 'id', type: ColumnType::INTEGER, primaryKey: true, autoIncrement: true)]
    public readonly int $id;

    #[Column(name: 'api_key_id', type: ColumnType::INTEGER, nullable: false)]
    public readonly int $api_key_id;

    #[Column(name: 'permission_id', type: ColumnType::INTEGER, nullable: true)]
    public readonly int $permission_id;
}
