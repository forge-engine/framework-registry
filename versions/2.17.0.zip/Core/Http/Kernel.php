<?php

declare(strict_types=1);

namespace Forge\Core\Http;

use Forge\Core\Contracts\RequestCollectorInterface;
use Forge\Core\Routing\Router;
use Forge\Core\DI\Container;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;
use Throwable;

final readonly class Kernel
{
  public function __construct(private Router $router)
  {
  }

  /**
   * @throws Throwable
   */
  public function handler(Request $request): Response
  {
    HookManager::triggerHook(LifecycleHookName::BEFORE_REQUEST, $request);
    $this->ensureRequestCollectorExist($request);

    $content = $this->router->dispatch($request);

    if ($content instanceof Response) {
      HookManager::triggerHook(
        LifecycleHookName::AFTER_REQUEST,
        $request,
        $content,
      );
      return $content;
    }

    $response = new Response((string) $content);
    HookManager::triggerHook(
      LifecycleHookName::AFTER_REQUEST,
      $request,
      $response,
    );
    return $response;
  }

  /**
   * Collect request data using all registered request collectors.
   * Multiple collectors can be registered and will all be called.
   */
  private function ensureRequestCollectorExist(Request $request): void
  {
    try {
      $requestStartTime = microtime(true);
      $container = Container::getInstance();

      if ($container->has(\Forge\Core\Collectors\TimelineCollector::class)) {
        /** @var \Forge\Core\Collectors\TimelineCollector $timelineCollector */
        $timelineCollector = $container->get(\Forge\Core\Collectors\TimelineCollector::class);
        $timelineCollector->setStartTime($requestStartTime);
      }

      if (class_exists(\App\Modules\ForgeDebugbar\Collectors\MessageCollector::class)) {
        \App\Modules\ForgeDebugbar\Collectors\MessageCollector::instance()->setStartTime($requestStartTime);
      }

      $collectors = $this->getRequestCollectors();

      foreach ($collectors as $collector) {
        if ($collector instanceof RequestCollectorInterface) {
          $collector->collect($request);
        }
      }
    } catch (\Throwable $e) {
      error_log("Failed to discover request collectors: " . $e->getMessage());
    }
  }

  /**
   * Get all request collectors from container.
   *
   * @return array<RequestCollectorInterface> Array of request collectors
   */
  private function getRequestCollectors(): array
  {
    $container = Container::getInstance();

    try {
      if ($container->has(RequestCollectorInterface::class)) {
        $collector = $container->get(RequestCollectorInterface::class);
        if ($collector instanceof RequestCollectorInterface) {
          return [$collector];
        }
      }

      $collectors = $container->getAll(RequestCollectorInterface::class);
      return $collectors;
    } catch (\Throwable $e) {
      error_log("Failed to get request collectors: " . $e->getMessage());
      return [];
    }
  }
}
