<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Exception;
use Forge\Core\DI\Container;
use ReflectionClass;

abstract class BaseComponent
{
    protected array|object $props;

    public function __construct(array|object $props)
    {
        $this->props = $props;
    }

    abstract public function render(): mixed;

    /**
     * @throws Exception
     */
    protected function renderview(string $viewPath, array|object $data = [], bool $loadFromModule = false): string
    {
        $view = new View(
            container: Container::getInstance(),
            module: $loadFromModule ? $this->getModuleName() : null
        );
        
        return $view->renderComponentView($viewPath, $data);
    }


    /**
     * @throws Exception
     */
    protected function getModuleName(): string
    {
        $class = static::class;
        preg_match('/\\\\Modules\\\\([^\\\\]+)\\\\/', $class, $matches);
        return $matches[1] ?? throw new Exception(
            "Unable to determine module name from class {$class}"
        );
    }

    /**
     * Convert a DTO object to an array for rendering.
     */
    protected function convertDtoToArray(object $dto): array
    {
        $reflection = new ReflectionClass($dto);
        $propsArray = [];
        foreach ($reflection->getProperties() as $prop) {
            $prop->setAccessible(true);
            $propsArray[$prop->getName()] = $prop->getValue($dto);
        }
        return $propsArray;
    }
}