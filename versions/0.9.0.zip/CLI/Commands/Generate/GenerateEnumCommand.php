<?php

declare(strict_types=1);

namespace Forge\CLI\Commands\Generate;

use Exception;
use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\CliGenerator;
use Forge\Traits\StringHelper;

#[Cli(
    command: 'generate:enum',
    description: 'Create a new enum',
    usage: 'generate:enum [--type=app|module] [--module=ModuleName] [--name=Example]',
    examples: [
        'generate:enum --type=app --name=Example',
        'generate:enum --type=app --name=Example --path=Test',
        'generate:enum --type=module --module=Blog --name=Example',
        'generate:enum   (starts wizard)',
    ]
)]
final class GenerateEnumCommand extends Command
{
    use StringHelper;
    use CliGenerator;

    #[Arg(name: 'type', description: 'app or module', validate: 'app|module')]
    private string $type;

    #[Arg(name: 'module', description: 'Module name when type=module', required: false)]
    private ?string $module = null;

    #[Arg(name: 'name', description: 'Enum class name (without suffix)', validate: '/^\w+$/')]
    private string $name;


    #[Arg(
        name: 'path',
        description: 'Optional subfolder inside Models (e.g., Admin, Api/V1)',
        default: '',
        required: false
    )]
    private string $path = '';

    /**
     * @throws Exception
     */
    public function execute(array $args): int
    {
        $this->wizard($args);

        if ($this->type === 'module' && !$this->module) {
            $this->error('--module=Name required when --type=module');
            return 1;
        }

        $dtoFile = $this->enumPath();

        $tokens = [
            '{{ enumName }}' => $this->name . 'Enum',
            '{{ enumNameSpace }}' => $this->enumNamespace(),
        ];

        $this->generateFromStub('enum', $dtoFile, $tokens);
        return 0;
    }
}