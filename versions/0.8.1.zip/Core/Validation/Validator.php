<?php

declare(strict_types=1);

namespace Forge\Core\Validation;

use Forge\Core\Contracts\Database\QueryBuilderInterface;
use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;
use Forge\Exceptions\ValidationException;
use Forge\Core\DI\Container;
use Forge\Core\Helpers\Flash;
use ReflectionException;

final class Validator
{
    public function __construct(
        private array $data,
        private array $rules,
        private array $messages = [],
    )
    {
    }

    /**
     * @throws ValidationException
     * @throws ReflectionException
     * @throws MissingServiceException
     * @throws ResolveParameterException
     */
    public function validate(): void
    {
        $errors = [];

        foreach ($this->rules as $field => $ruleset) {
            $value = $this->data[$field] ?? "";
            $value = is_string($value) ? $value : (string)$value;

            foreach ($ruleset as $rule) {
                [$ruleName, $param] = explode(":", $rule . ":");

                if ($ruleName === "required" && empty($value)) {
                    $errors[$field][] = $this->format(
                        "required",
                        $field,
                        $param,
                    );
                }

                if ($ruleName === "min" && strlen($value) < (int)$param) {
                    $errors[$field][] = $this->format("min", $field, $param);
                }

                if (
                    $ruleName === "email" &&
                    !filter_var($value, FILTER_VALIDATE_EMAIL)
                ) {
                    $errors[$field][] = $this->format("email", $field);
                }

                if (
                    $ruleName === "match" &&
                    $value !== ($this->data[$param] ?? "")
                ) {
                    $errors[$field][] = $this->format("match", $field);
                }

                if ($ruleName === "unique") {
                    [$table, $column] = explode(",", $param);
                    /*** @var QueryBuilderInterface $query */
                    $query = Container::getInstance()->get(QueryBuilderInterface::class);
                    $exists = $query
                        ->setTable($table)
                        ->where($column, "=", $value)
                        ->first();
                    if ($exists) {
                        $errors[$field][] = $this->format("unique", $field);
                    }
                }
            }
        }

        if (!empty($errors)) {
            Flash::set("error", $errors);
            throw new ValidationException("Invalid validation");
        }
    }

    private function format(
        string $rule,
        string $field,
        string $value = "",
    ): string
    {
        $msg = $this->messages[$rule] ?? "The :field field is invalid.";
        return str_replace([":field", ":value"], [$field, $value], $msg);
    }
}
