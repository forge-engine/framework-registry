<?php

declare(strict_types=1);

namespace Forge\Core\Services;

use Forge\Core\DI\Attributes\Service;

#[Service]
final class MessageBoxService
{
    private const DEFAULT_WIDTH = 70;
    private const BORDER_CHAR = '▓';

    private array $colors = [
        'danger' => ['border' => "\033[0;31m", 'title' => "\033[1;33m", 'message' => "\033[0;31m"],
        'warning' => ['border' => "\033[1;33m", 'title' => "\033[1;33m", 'message' => "\033[1;33m"],
        'info' => ['border' => "\033[0;34m", 'title' => "\033[1;34m", 'message' => "\033[0;34m"],
        'success' => ['border' => "\033[1;32m", 'title' => "\033[1;32m", 'message' => "\033[1;32m"],
        'normal' => ['border' => "\033[0m", 'title' => "\033[0m", 'message' => "\033[0m"],
    ];

    public function showMessageBox(string $type, string $title, array $messages, ?string $footer = null, int $width = self::DEFAULT_WIDTH): void
    {
        $border = str_repeat(self::BORDER_CHAR, $width);
        $color = $this->colors[$type] ?? $this->colors['normal'];
        $reset = "\033[0m";

        $titleSpaced = implode(' ', str_split(strtoupper($title)));
        $titlePadding = (int)(($width - strlen($titleSpaced)) / 2);
        $titleLine = str_repeat(' ', max(0, $titlePadding)) . $titleSpaced;

        echo PHP_EOL;
        echo $color['border'] . $border . $reset . PHP_EOL;
        echo $color['title'] . $titleLine . $reset . PHP_EOL;
        echo $color['border'] . $border . $reset . PHP_EOL;
        echo PHP_EOL;

        foreach ($messages as $message) {
            $formattedMessage = '  – ' . $message;
            echo $color['message'] . $formattedMessage . $reset . PHP_EOL;
        }

        if ($footer !== null) {
            echo PHP_EOL;
            echo $color['message'] . '  ' . $footer . $reset . PHP_EOL;
        }

        echo PHP_EOL;
    }

    public function showDangerBox(string $title, array $messages, ?string $footer = null, int $width = self::DEFAULT_WIDTH): void
    {
        $this->showMessageBox('danger', $title, $messages, $footer, $width);
    }

    public function showWarningBox(string $title, array $messages, ?string $footer = null, int $width = self::DEFAULT_WIDTH): void
    {
        $this->showMessageBox('warning', $title, $messages, $footer, $width);
    }

    public function showInfoBox(string $title, array $messages, ?string $footer = null, int $width = self::DEFAULT_WIDTH): void
    {
        $this->showMessageBox('info', $title, $messages, $footer, $width);
    }

    public function showSuccessBox(string $title, array $messages, ?string $footer = null, int $width = self::DEFAULT_WIDTH): void
    {
        $this->showMessageBox('success', $title, $messages, $footer, $width);
    }

    public function showNormalBox(string $title, array $messages, ?string $footer = null, int $width = self::DEFAULT_WIDTH): void
    {
        $this->showMessageBox('normal', $title, $messages, $footer, $width);
    }
}

