<?php

declare(strict_types=1);

namespace Forge\Core;

$requestUri = $_SERVER["REQUEST_URI"] ?? '';
if ($requestUri !== '' && preg_match('/\.env$/i', $requestUri)) {
  header("HTTP/1.1 403 Forbidden");
  exit();
}

use Forge\Core\Bootstrap\Bootstrap;
use Forge\Core\Contracts\ErrorHandlerInterface;
use Forge\Core\Debug\Metrics;
use Forge\Core\DI\Container;
use Forge\Core\Helpers\FileExistenceCache;
use Forge\Core\Http\Request;
use Throwable;

final class Engine
{
  /**
   * @throws Throwable
   */
  public static function init(): void
  {
    Metrics::start('engine_resolution');
    $bootstrap = Bootstrap::getInstance();
    $kernel = $bootstrap->getKernel();

    $compiledFile = BASE_PATH . '/storage/framework/cache/compiled_hooks.php';
    if (FileExistenceCache::exists($compiledFile)) {
      include $compiledFile;
    }

    Metrics::stop('engine_resolution');

    try {
      $response = $kernel->handler(Request::createFromGlobals());
      $response->send();
    } catch (Throwable $e) {
      self::handleException($e);
    }
  }

  /**
   * Handle an exception using the error handler if available.
   */
  private static function handleException(Throwable $e): void
  {
    try {
      $container = Container::getInstance();
      $request = Request::createFromGlobals();

      if ($container->has(ErrorHandlerInterface::class)) {
        $errorHandler = $container->get(ErrorHandlerInterface::class);
        if ($errorHandler instanceof ErrorHandlerInterface) {
          $response = $errorHandler->handle($e, $request);
          $response->send();
          return;
        }
      }

      $errorHandlers = $container->getAll(ErrorHandlerInterface::class);
      if (!empty($errorHandlers)) {
        $errorHandler = $errorHandlers[0];
        $response = $errorHandler->handle($e, $request);
        $response->send();
        return;
      }
    } catch (Throwable $fatal) {
      http_response_code(500);
      if (ini_get('display_errors')) {
        echo "Fatal error: " . $fatal->getMessage() . "\n";
        echo "Original error: " . $e->getMessage() . "\n";
      } else {
        echo "An error occurred.";
      }
      exit(1);
    }

    throw $e;
  }
}
