<?php

declare(strict_types=1);

namespace Forge\Core\Routing;

use Forge\Core\DI\Container;
use Forge\Core\Helpers\FileExistenceCache;
use ReflectionClass;
use ReflectionMethod;
use ReflectionParameter;

/**
 * Persistent route cache to eliminate reflection overhead.
 * 
 * This service provides persistent caching of route metadata, reflection data,
 * and compiled parameter binding rules to dramatically improve performance in production.
 */
class RouteCache
{
    private string $cachePath;
    private bool $isProduction;
    private array $memoryCache = [];
    private bool $cacheEnabled;

    public function __construct(?string $cachePath = null, ?bool $isProduction = null)
    {
        $this->cachePath = $cachePath ?? (BASE_PATH . '/storage/framework/routes');
        $this->isProduction = $isProduction ?? $this->detectEnvironment();
        $this->cacheEnabled = $this->isProduction && $this->ensureCacheDirectory();
    }

    /**
     * Get cached route data or compute and cache if not available.
     *
     * @param string $key Cache key
     * @param callable $computor Function to compute data if not cached
     * @return mixed Cached or computed data
     */
    public function remember(string $key, callable $computor): mixed
    {
        // Check memory cache first
        if (isset($this->memoryCache[$key])) {
            return $this->memoryCache[$key];
        }

        // Check persistent cache if enabled
        if ($this->cacheEnabled) {
            $cachedData = $this->loadFromPersistentCache($key);
            if ($cachedData !== null) {
                $this->memoryCache[$key] = $cachedData;
                return $cachedData;
            }
        }

        // Compute and cache the data
        $data = $computor();
        $this->memoryCache[$key] = $data;

        if ($this->cacheEnabled) {
            $this->saveToPersistentCache($key, $data);
        }

        return $data;
    }

    /**
     * Get cached reflection data for a controller method.
     *
     * @param string $controllerClass Controller class name
     * @param string $methodName Method name
     * @return array{reflection: ReflectionMethod, parameters: array<int, array{name: string, type: ?string, hasType: bool, isRequest: bool}>}
     */
    public function getReflectionData(string $controllerClass, string $methodName): array
    {
        $key = "reflection:{$controllerClass}::{$methodName}";

        return $this->remember($key, function () use ($controllerClass, $methodName) {
            $reflectionMethod = new ReflectionMethod($controllerClass, $methodName);
            $parameters = [];

            foreach ($reflectionMethod->getParameters() as $param) {
                $parameters[] = $this->compileParameterMetadata($param);
            }

            return [
                'reflection' => $reflectionMethod,
                'parameters' => $parameters,
            ];
        });
    }

    /**
     * Get cached compiled parameter binding rules.
     *
     * @param string $controllerClass Controller class name
     * @param string $methodName Method name
     * @return array Compiled binding rules
     */
    public function getCompiledBindings(string $controllerClass, string $methodName): array
    {
        $key = "bindings:{$controllerClass}::{$methodName}";

        return $this->remember($key, function () use ($controllerClass, $methodName) {
            $reflectionData = $this->getReflectionData($controllerClass, $methodName);
            $parameters = $reflectionData['parameters'];

            $bindings = [];
            foreach ($parameters as $index => $paramMeta) {
                $bindings[$index] = [
                    'name' => $paramMeta['name'],
                    'type' => $paramMeta['type'],
                    'hasType' => $paramMeta['hasType'],
                    'isRequest' => $paramMeta['isRequest'],
                    'transformer' => $this->getTransformer($paramMeta['type']),
                ];
            }

            return $bindings;
        });
    }

    /**
     * Cache route registration data.
     *
     * @param array $routes Route data
     */
    public function cacheRoutes(array $routes): void
    {
        if (!$this->cacheEnabled) {
            return;
        }

        $this->saveToPersistentCache('routes', [
            'timestamp' => time(),
            'routes' => $routes,
        ]);
    }

    /**
     * Get cached route registration data.
     *
     * @return array|null Cached routes or null if not available
     */
    public function getCachedRoutes(): ?array
    {
        if (!$this->cacheEnabled) {
            return null;
        }

        $cached = $this->loadFromPersistentCache('routes');
        
        // Check if cache is still valid (24 hours)
        if ($cached && isset($cached['timestamp']) && 
            (time() - $cached['timestamp']) < 86400) {
            return $cached['routes'];
        }

        return null;
    }

    /**
     * Pre-warm cache with common controllers and methods.
     *
     * @param array $controllers List of controller classes to pre-cache
     */
    public function warmup(array $controllers = []): void
    {
        if (empty($controllers)) {
            // Auto-discover controllers if none provided
            $controllers = $this->discoverControllers();
        }

        foreach ($controllers as $controller) {
            $reflection = new ReflectionClass($controller);
            foreach ($reflection->getMethods() as $method) {
                $this->getReflectionData($controller, $method->getName());
                $this->getCompiledBindings($controller, $method->getName());
            }
        }
    }

    /**
     * Clear all caches.
     */
    public function clear(): void
    {
        $this->memoryCache = [];
        
        if ($this->cacheEnabled && FileExistenceCache::isDir($this->cachePath)) {
            $files = glob($this->cachePath . '/*.php');
            foreach ($files as $file) {
                unlink($file);
            }
        }
    }

    /**
     * Get cache statistics.
     *
     * @return array<string, mixed> Cache statistics
     */
    public function getStats(): array
    {
        return [
            'memory_cache_size' => count($this->memoryCache),
            'persistent_cache_enabled' => $this->cacheEnabled,
            'cache_path' => $this->cachePath,
            'is_production' => $this->isProduction,
        ];
    }

    /**
     * Compile parameter metadata for caching.
     *
     * @param ReflectionParameter $param Reflection parameter
     * @return array Compiled parameter metadata
     */
    private function compileParameterMetadata(ReflectionParameter $param): array
    {
        $type = $param->getType();
        $typeName = null;
        $hasType = false;

        if ($type instanceof \ReflectionNamedType) {
            $typeName = $type->getName();
            $hasType = true;
        }

        return [
            'name' => $param->getName(),
            'type' => $typeName,
            'hasType' => $hasType,
            'isRequest' => $param->getName() === 'request',
        ];
    }

    /**
     * Get appropriate transformer for parameter type.
     *
     * @param string|null $type Parameter type
     * @return callable|null Transformer function or null
     */
    private function getTransformer(?string $type): ?callable
    {
        if ($type === null) {
            return null;
        }

        return match ($type) {
            'int' => fn($value) => (int) $value,
            'float' => fn($value) => (float) $value,
            'bool' => fn($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN),
            'string' => fn($value) => (string) $value,
            default => null,
        };
    }

    /**
     * Load data from persistent cache.
     *
     * @param string $key Cache key
     * @return mixed Cached data or null if not found
     */
    private function loadFromPersistentCache(string $key): mixed
    {
        $filename = $this->cachePath . '/' . md5($key) . '.php';
        
        if (!FileExistenceCache::exists($filename)) {
            return null;
        }

        $data = include $filename;
        return $data ?: null;
    }

    /**
     * Save data to persistent cache.
     *
     * @param string $key Cache key
     * @param mixed $data Data to cache
     */
    private function saveToPersistentCache(string $key, mixed $data): void
    {
        $filename = $this->cachePath . '/' . md5($key) . '.php';
        $content = '<?php return ' . var_export($data, true) . ';';
        file_put_contents($filename, $content);
    }

    /**
     * Ensure cache directory exists.
     *
     * @return bool True if directory exists or was created
     */
    private function ensureCacheDirectory(): bool
    {
        if (!FileExistenceCache::isDir($this->cachePath)) {
            return mkdir($this->cachePath, 0755, true);
        }
        return true;
    }

    /**
     * Detect if we're in production environment.
     *
     * @return bool True if production environment
     */
    private function detectEnvironment(): bool
    {
        $env = $_ENV['APP_ENV'] ?? $_SERVER['APP_ENV'] ?? 'production';
        return $env === 'production';
    }

    /**
     * Auto-discover controller classes.
     *
     * @return array<string> List of controller classes
     */
    private function discoverControllers(): array
    {
        $controllers = [];
        
        // Scan app controllers
        $appPath = BASE_PATH . '/app/Controllers';
        if (FileExistenceCache::isDir($appPath)) {
            $controllers = array_merge($controllers, $this->scanDirectory($appPath, 'App\\Controllers'));
        }
        
        // Scan module controllers
        $modulesPath = BASE_PATH . '/modules';
        if (FileExistenceCache::isDir($modulesPath)) {
            $allModules = scandir($modulesPath);
            $modulesToCheck = [];
            
            foreach ($allModules as $module) {
                if ($module[0] !== '.') {
                    $modulesToCheck[] = $modulesPath . '/' . $module . '/src/Controllers';
                }
            }
            
            if (!empty($modulesToCheck)) {
                FileExistenceCache::preload($modulesToCheck);
            }
            
            foreach ($allModules as $module) {
                if ($module[0] === '.') continue;
                
                $controllerPath = $modulesPath . '/' . $module . '/src/Controllers';
                if (FileExistenceCache::isDir($controllerPath)) {
                    $namespace = "App\\Modules\\{$module}\\Controllers";
                    $controllers = array_merge($controllers, $this->scanDirectory($controllerPath, $namespace));
                }
            }
        }
        
        return $controllers;
    }

    /**
     * Scan directory for PHP files and convert to class names.
     *
     * @param string $path Directory path
     * @param string $namespace Base namespace
     * @return array<string> List of class names
     */
    private function scanDirectory(string $path, string $namespace): array
    {
        $classes = [];
        $files = glob($path . '/*.php');
        
        foreach ($files as $file) {
            $className = basename($file, '.php');
            $classes[] = $namespace . '\\' . $className;
        }
        
        return $classes;
    }
}