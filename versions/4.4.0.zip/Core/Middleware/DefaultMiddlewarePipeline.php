<?php

declare(strict_types=1);

namespace Forge\Core\Middleware;

use Forge\Core\Contracts\MiddlewarePipelineInterface;
use Forge\Core\Helpers\FileExistenceCache;
use Forge\Core\Http\Request;

/**
 * Default middleware pipeline implementation that preserves current behavior.
 * Reads from config file and merges with route-specific middlewares.
 */
final class DefaultMiddlewarePipeline implements MiddlewarePipelineInterface
{
  private static ?array $cachedMiddlewareConfig = null;

  /**
   * Get global middlewares from config file, with caching to avoid file I/O on every request.
   *
   * @param Request $request The current request
   * @return array<string> Array of middleware class names
   */
  public function getGlobalMiddlewares(Request $request): array
  {
    if (self::$cachedMiddlewareConfig === null) {
      $configFile = BASE_PATH . "/config/middleware.php";
      if (FileExistenceCache::exists($configFile)) {
        self::$cachedMiddlewareConfig = require $configFile;
      } else {
        self::$cachedMiddlewareConfig = [];
      }
    }

    return self::$cachedMiddlewareConfig["global"] ?? [];
  }

  /**
   * Resolve the final middleware list for a route.
   * Combines global middlewares with route-specific middlewares.
   *
   * @param array<string> $routeMiddlewares Middlewares specified on the route
   * @param Request $request The current request
   * @param array<string, mixed> $route The route data
   * @return array<string> Final array of middleware class names in execution order
   */
  public function resolveMiddlewares(
    array $routeMiddlewares,
    Request $request,
    array $route
  ): array {
    $globalMiddlewares = $this->getGlobalMiddlewares($request);

    return array_merge(
      $globalMiddlewares,
      $routeMiddlewares
    );
  }
}
