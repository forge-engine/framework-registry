<?php

namespace Forge\Http\Exceptions;

class ValidationException extends \RuntimeException
{
    public function __construct(protected array $errors)
    {
        parent::__construct('Validation failed');
    }

    public function errors(): array
    {
        return $this->errors;
    }
}