<?php

declare(strict_types=1);

use App\Modules\ForgeDatabaseSQL\DB\Attributes\GroupMigration;
use App\Modules\ForgeDatabaseSQL\DB\Migrations\Migration;

#[GroupMigration(name: 'security')]
class CreateApiKeyPermissionsTable extends Migration
{
    public function up(): void
    {
        $sql = $this->createTable('api_key_permissions', [
            'id' => 'INTEGER PRIMARY KEY AUTOINCREMENT',
            'api_key_id' => 'INTEGER NOT NULL',
            'permission_id' => 'INTEGER NULL',
        ]);
        $this->execute($sql);
        
        $fk1Sql = $this->addForeignKey('api_key_permissions', 'api_key_id', 'api_keys', 'id', 'CASCADE');
        if ($fk1Sql !== null) {
            $this->execute($fk1Sql);
        }
        
        $fk2Sql = $this->addForeignKey('api_key_permissions', 'permission_id', 'permissions', 'id', 'CASCADE');
        if ($fk2Sql !== null) {
            $this->execute($fk2Sql);
        }
    }

    public function down(): void
    {
        $this->execute($this->dropTable('api_key_permissions'));
    }
}
