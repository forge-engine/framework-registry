<?php
declare(strict_types=1);

namespace Forge\Core\View;

use Attribute;
use Forge\Core\Helpers\Strings;
use Forge\Core\View\BaseComponent;
use ReflectionClass;
use ReflectionException;
use RuntimeException;

#[Attribute(Attribute::TARGET_CLASS)]
final class Component
{
    public function __construct(
        public string $name,
        public bool   $useDto = false,
    )
    {
    }

    /**
     * Render a component by attribute name.
     *
     * @throws ReflectionException
     */
    public static function render(string $name, array|object $props = [], bool $loadFromModule = false): string
    {
        $fqcn = self::resolveClassName($name, $loadFromModule);

        if (!class_exists($fqcn)) {
            throw new RuntimeException("Component class not found: {$fqcn}");
        }

        $reflection = new ReflectionClass($fqcn);
        if (!$reflection->isSubclassOf(BaseComponent::class)) {
            throw new RuntimeException("{$fqcn} is not a BaseComponent");
        }

        $attr = $reflection->getAttributes(self::class)[0] ?? null;
        if ($attr === null || $attr->newInstance()->name !== $name) {
            throw new RuntimeException("Attribute mismatch for {$fqcn}");
        }

        $attribute = $attr->newInstance();
        if ($attribute->useDto && !is_object($props)) {
            $dtoClass = $fqcn . 'PropsDto';
            if (!class_exists($dtoClass)) {
                throw new RuntimeException("DTO class {$dtoClass} not found");
            }
            $dto = new $dtoClass();
            foreach ((array)$props as $k => $v) {
                if (property_exists($dto, $k)) {
                    $dto->$k = $v;
                }
            }
            $props = $dto;
        }

        $component = $reflection->newInstance($props);
        return (string)$component->render();
    }

    private static function resolveClassName(string $name, bool $module): string
    {
        $parts = preg_split('#[/:]#', $name);
        $class = Strings::toPascalCase(array_pop($parts));

        if ($module) {
            $module = Strings::toPascalCase($parts[0]);
            $subNs = array_map([Strings::class, 'toPascalCase'], array_slice($parts, 1));
            return 'App\\Modules\\' . $module . '\\Resources\\Components'
                . ($subNs ? '\\' . implode('\\', $subNs) : '')
                . '\\' . $class;
        }

        $subNs = array_map([Strings::class, 'toPascalCase'], $parts);
        return 'App\\Components'
            . ($subNs ? '\\' . implode('\\', $subNs) : '')
            . '\\' . $class;
    }
}