<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Helpers\Strings;
use Forge\Core\Module\Attributes\CLICommand;

#[CLICommand(name: 'asset:unlink', description: 'Remove the symbolic link from public/assets')]
final class AssetUnlinkCommand extends Command
{
    private const APP_ASSET_PATH = BASE_PATH . '/app/resources/assets/';
    private const MODULE_ASSET_PATH = BASE_PATH . '/public/assets/modules/';

    private const ALLOWED_TYPES = ['app', 'module'];

    public function execute(array $args): int
    {
        if (count($args) < 1) {
            $this->error('Asset type required');
            $this->line('Usage: php forge.php asset:unlink --type=module|app <module-name>');
            return 1;
        }

        $type = $this->getPublishType($args);

        if ($type === 'app') {
            $this->unlinkDirectory(self::APP_ASSET_PATH);
            return 0;
        }

        if ($type === 'module') {
            if (!isset($args[1])) {
                $this->error('Module name required');
                $this->line('Usage: php forge.php asset:unlink --type=module|app <module-name>');
                return 1;
            }

            $moduleName = Strings::toKebabCase($args[1]);
            $this->unlinkDirectory(self::MODULE_ASSET_PATH . $moduleName);
            return 0;
        }

        return 0;
    }

    private function unlinkDirectory(string $path): int
    {
        if (file_exists($path)) {
            if (is_link($path)) {
                if (unlink($path)) {
                    $this->success("The [$path] link has been removed.");
                    return 0;
                } else {
                    $this->error("Failed to remove the [$path] link.");
                    return 1;
                }
            } else {
                $this->error("The [$path] path is not a symbolic link.");
                return 1;
            }
        } else {
            $this->info("The [$path] link does not exist.");
            return 0;
        }
    }

    private function getPublishType(array $args): string
    {
        foreach ($args as $arg) {
            if (str_starts_with($arg, '--type=')) {
                $type = strtolower(substr($arg, 7));
                if (in_array($type, self::ALLOWED_TYPES)) {
                    return $type;
                }
            }
        }
        return 'app';
    }
}
