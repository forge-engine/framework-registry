<?php

declare(strict_types=1);

use Forge\Core\Database\Migrations\Migration;

class CreateApiKeyPermissionsTable extends Migration
{
    public function up(): void
    {
        $this->queryBuilder->setTable('api_key_permissions')
            ->createTable(
                [
                    'id' => 'INTEGER PRIMARY KEY AUTOINCREMENT',
                    'api_key_id' => 'INTEGER NOT NULL',
                    'permission_id' => 'INTEGER',
                ],
                [
                    'CONSTRAINT fk_api_key_id FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE CASCADE',
                    'CONSTRAINT fk_permission_id FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE',
                ]
            );
        $this->execute($this->queryBuilder->getSql());
    }

    public function down(): void
    {
        $this->execute($this->queryBuilder->dropTable('api_key_permissions'));
    }
}
