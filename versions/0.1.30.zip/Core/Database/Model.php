<?php

declare(strict_types=1);

namespace Forge\Core\Database;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\Database\QueryBuilder;
use Forge\Core\DI\Container;
use Forge\Exceptions\MissingPrimaryKeyException;
use Forge\Exceptions\MissingTableAttributeException;
use ReflectionClass;
use ReflectionProperty;

#[Service]
abstract class Model
{
    protected static string $connection = "default";
    private array $original = [];
    protected static array $with = [];
    protected static array $scopes = [];
    protected bool $softDelete = false;
    protected string $deletedAtColumn = "deleted_at";

    /**
     * Properties that should be hidden from object dumps
     */
    protected array $hidden = [];
    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected array $casts = [];

    private static function getConnection(): \PDO
    {
        return Container::getInstance()->get(Connection::class);
    }

    private function getQueryBuilder(): QueryBuilder
    {
        return Container::getInstance()->get(QueryBuilder::class);
    }

    protected function newQuery(): QueryBuilder
    {
        return $this->getQueryBuilder()->setTable(static::getTable());
    }

    public function __construct(array $attributes = [])
    {
        foreach ($attributes as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $this->castAttribute($key, $value);
                $this->original[$key] = $this->$key;
            }
        }
    }

    /**
     * Cast an attribute to a native PHP type.
     *
     * @param  string  $key
     * @param  mixed  $value
     * @return mixed
     */
    protected function castAttribute(string $key, mixed $value): mixed
    {
        if (array_key_exists($key, $this->casts) && $value !== null) {
            $castType = $this->casts[$key];

            switch ($castType) {
                case 'int':
                case 'integer':
                    return (int) $value;
                case 'real':
                case 'float':
                case 'double':
                    return (float) $value;
                case 'bool':
                case 'boolean':
                    return (bool) $value;
                case 'array':
                case 'json':
                    return json_decode($value, true);
                case 'object':
                return json_decode($value, true);
                case 'string':
                    return (string) $value;
                case 'datetime':
                    return new \DateTimeImmutable($value);
                case 'date':
                    return new \DateTimeImmutable($value);
                case 'timestamp':
                    return new \DateTimeImmutable('@' . $value);
                default:
                    return $value;
            }
        }

        return $value;
    }

    /**
     * Convert the model to an array, hiding protected properties
     */
    public function toArray(): array
    {
        $array = [];
        $reflection = new ReflectionClass($this);

        foreach (
            $reflection->getProperties(ReflectionProperty::IS_PUBLIC)
            as $property
        ) {
            $name = $property->getName();
            if (!in_array($name, $this->hidden) && !$property->isStatic()) {
                $array[$name] = $this->$name;
            }
        }

        return $array;
    }

    /**
     * Convert the model to JSON
     */
    public function toJson(): string
    {
        return json_encode($this->toArray());
    }

    /**
     * Handle JSON serialization
     */
    public function jsonSerialize(): array
    {
        return $this->toArray();
    }

    public function save(): bool
    {
        $data = $this->getDirtyAttributes();

        if ($this->exists()) {
            return $this->performUpdate($data);
        }

        return $this->performInsert($data);
    }

    public function delete(): bool
    {
        $primaryKey = $this->getPrimaryKey();
        $value = $this->$primaryKey ?? null;

        if ($value === null) {
            return false;
        }

        if ($this->softDelete) {
            return $this->newQuery()
                ->where($primaryKey, "=", $value)
                ->update([$this->deletedAtColumn => date("Y-m-d H:i:s")]) > 0;
        }

        return $this->newQuery()
            ->where($primaryKey, "=", $value)
            ->delete() > 0;
    }

    public static function where(string $column, mixed $value, ?string $operator = '='): ?array
    {
        $instance = new static();

        $query = $instance
            ->newQuery()
            ->where($column, $operator ?? "=", $value);

        static::applySoftDeleteScope($query, $instance->softDelete, $instance->deletedAtColumn);

        $results = $query->get();

        return static::hydrateModels($results);
    }

    public static function find(int $id): ?static
    {
        $instance = new static();

        $query = $instance->newQuery()
            ->where(static::getPrimaryKey(), "=", $id);

        static::applySoftDeleteScope($query, $instance->softDelete, $instance->deletedAtColumn);

        $result = $query->first();
        $model = new static($result);

        return $model;
    }

    public static function all(): array
    {
        $instance = new static();

        $query = $instance->newQuery();

        static::applySoftDeleteScope($query, $instance->softDelete, $instance->deletedAtColumn);

        $results = $query->getRaw();

        return static::hydrateModels($results);
    }

    protected static function applySoftDeleteScope(QueryBuilder $query, bool $softDelete, string $deletedAtColumn): void
    {
        if ($softDelete) {
            $query->whereNull($deletedAtColumn);
        }
    }
    protected static function hydrateModels(array $results): array
    {
        $models = [];

        foreach ($results as $result) {
            $models[] = new static($result);
        }

        return $models;
    }

    protected function getDirtyAttributes(): array
    {
        $dirty = [];
        foreach ($this->getColumns() as $column) {
            if (!$this->exists() && isset($this->$column)) {
                $dirty[$column] = $this->$column;
            } elseif ($this->exists() && isset($this->original[$column]) && $this->$column !== $this->original[$column]) {
                $dirty[$column] = $this->$column;
            }
        }
        return $dirty;
    }

    protected function exists(): bool
    {
        $primaryKey = $this->getPrimaryKey();
        return isset($this->$primaryKey);
    }

    public static function getTable(): string
    {
        $reflection = new ReflectionClass(static::class);
        $attributes = $reflection->getAttributes(Table::class);

        if (empty($attributes)) {
            throw new MissingTableAttributeException();
        }

        return $attributes[0]->newInstance()->name;
    }

    public static function getPrimaryKey(): string
    {
        $reflection = new ReflectionClass(static::class);

        foreach ($reflection->getProperties() as $property) {
            $attributes = $property->getAttributes(Column::class);

            foreach ($attributes as $attribute) {
                $column = $attribute->newInstance();
                if ($column->primary) {
                    return $property->getName();
                }
            }
        }

        throw new MissingPrimaryKeyException();
    }

    private function getColumns(): array
    {
        $columns = [];
        $reflection = new ReflectionClass(static::class);

        foreach ($reflection->getProperties() as $property) {
            if ($property->getAttributes(Column::class)) {
                $columns[] = $property->getName();
            }
        }

        return $columns;
    }

    private function performInsert(array $data): bool
    {
        $result = $this->newQuery()
            ->insert($data);

        if ($result) {
            $primaryKey = $this->getPrimaryKey();
            $this->$primaryKey = $result;
        }

        return (bool) $result;
    }

    private function performUpdate(array $data): bool
    {
        $primaryKey = $this->getPrimaryKey();
        $value = $this->$primaryKey ?? null;

        if ($value === null) {
            return false;
        }

        return $this->newQuery()
            ->where($primaryKey, "=", $value)
            ->update($data) > 0;
    }

    /**
     * Force delete a soft deleted model
     */
    public function forceDelete(): bool
    {
        $primaryKey = $this->getPrimaryKey();
        $value = $this->$primaryKey ?? null;

        if ($value === null) {
            return false;
        }

        return $this->newQuery()
            ->where($primaryKey, "=", $value)
            ->delete() > 0;
    }

    /**
     * Restore a soft deleted model
     */
    public function restore(): bool
    {
        if (!$this->softDelete) {
            return false;
        }

        $primaryKey = $this->getPrimaryKey();
        $value = $this->$primaryKey ?? null;

        if ($value === null) {
            return false;
        }

        return $this->newQuery()
            ->where($primaryKey, "=", $value)
            ->update([$this->deletedAtColumn => null]) > 0;
    }

    /**
     *
     */
    public function __debugInfo(): array
    {
        $debugInfo = [];
        $reflection = new ReflectionClass($this);

        foreach (
            $reflection->getProperties(ReflectionProperty::IS_PUBLIC)
            as $property
        ) {
            $name = $property->getName();
            if (!in_array($name, $this->hidden) && !$property->isStatic()) {
                $debugInfo[$name] = $this->$name;
            }
        }

        foreach (
            $reflection->getProperties(
                ReflectionProperty::IS_PROTECTED |
                    ReflectionProperty::IS_PRIVATE
            )
            as $property
        ) {
            $name = $property->getName();
            if (
                $name === "hidden" ||
                $name === "original" ||
                $name === "softDelete" ||
                $name === "deletedAtColumn"
            ) {
                $property->setAccessible(true);
                $debugInfo[$name] = $property->getValue($this);
            }
        }

        return $debugInfo;
    }
}
