<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Attribute;
use Forge\Core\Helpers\Strings;
use ReflectionClass;

#[Attribute(Attribute::TARGET_CLASS)]
class Component
{
    public function __construct(public string $name, public bool $useDto = false)
    {
    }

    /**
     * Render a component.
     *
     * @throws \ReflectionException
     */
    public static function render(string $name, array $props = [], bool $loadFromModule = false): string
    {
        $componentClass = self::findComponentClass($name, $loadFromModule);

        if (!$componentClass) {
            throw new \RuntimeException("Component class not found for: {$name}");
        }
        //return '';
        return self::instantiateComponent($componentClass, $props);
    }

    /**
     * Finds a component class by scanning the app/views/components/ and modules.
     */
    private static function findComponentClass(string $name, bool $loadFromModule): ?string
    {
        // First, check already declared classes
        foreach (get_declared_classes() as $class) {
            if (self::isComponentMatch($class, $name)) {
                return $class;
            }
        }

        // If loadFromModule is true, scan the module components directories
        if ($loadFromModule) {
            return self::scanForModuleComponent($name);
        } else {
            // Then, scan the default app components directory
            $appComponentClass = self::scanForAppComponent($name);
            if ($appComponentClass) {
                return $appComponentClass;
            }
        }

        return null;
    }

    private static function scanForAppComponent(string $name): ?string
    {
        $className = Strings::toPascalCase($name);
        $basePath = BASE_PATH . "/app/resources/views/components/";

        foreach (glob($basePath . "*", GLOB_ONLYDIR) as $componentDir) {
            $componentFile = "{$componentDir}/{$className}.php";
            if (file_exists($componentFile)) {
                require_once $componentFile;

                $namespace = "App\\View\\Components\\" . str_replace('/', '\\', str_replace($basePath, '', $componentDir));
                $fullClassNameFromFile = rtrim($namespace, "\\") . "\\" . $className;

                if (class_exists($fullClassNameFromFile) && is_subclass_of($fullClassNameFromFile, BaseComponent::class)) {
                    if (self::isComponentMatchFromFile($fullClassNameFromFile, $name)) {
                        return $fullClassNameFromFile;
                    }
                }
            }
        }
        return null;
    }

    private static function normalizeName(string $name): string
    {
        return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $name));
    }

    private static function scanForModuleComponent(string $name): ?string
    {
        $parts = explode(':', $name, 2);
        $prefix = count($parts) === 2 ? $parts[0] : null;
        $componentName = count($parts) === 2 ? $parts[1] : $name;

        $className = Strings::toPascalCase($componentName);
        $componentRootPath = BASE_PATH . "/modules/";

        foreach (glob($componentRootPath . "*", GLOB_ONLYDIR) as $moduleDir) {
            $moduleName = basename($moduleDir);

            $normalizedPrefix = $prefix !== null ? self::normalizeName($prefix) : null;
            $normalizedModuleName = self::normalizeName($moduleName);

            if (
                $normalizedPrefix !== null &&
                strpos($normalizedModuleName, $normalizedPrefix) !== 0
            ) {
                continue;
            }

            $moduleNamePascalCase = Strings::toPascalCase($moduleName);
            $componentBasePath = $moduleDir . "/src/resources/components/";

            if (!is_dir($componentBasePath)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($componentBasePath)
            );

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getBasename('.php') === $className) {
                    require_once $file->getRealPath();

                    $relativePath = str_replace($componentBasePath, '', $file->getPath());
                    $namespace = "App\\Modules\\{$moduleNamePascalCase}\\Resources\\Components\\" . str_replace('/', '\\', $relativePath);
                    $fullClassName = rtrim($namespace, "\\") . "\\" . $className;

                    if (class_exists($fullClassName) && is_subclass_of($fullClassName, BaseComponent::class)) {
                        if (self::isComponentMatchFromFile($fullClassName, $name)) {
                            return $fullClassName;
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Checks if a given class is a component and matches the requested name (from file).
     */
    private static function isComponentMatchFromFile(string $class, string $name): bool
    {
        $reflection = new ReflectionClass($class);
        $attributes = $reflection->getAttributes(Component::class);

        foreach ($attributes as $attribute) {
            $instance = $attribute->newInstance();
            if ($instance->name === $name) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a given class is a component and matches the requested name (from declared classes).
     */
    private static function isComponentMatch(string $class, string $name): bool
    {
        if (!is_subclass_of($class, BaseComponent::class)) {
            return false;
        }

        $reflection = new ReflectionClass($class);
        $attributes = $reflection->getAttributes(Component::class);

        foreach ($attributes as $attribute) {
            $instance = $attribute->newInstance();
            if ($instance->name === $name) {
                return true;
            }
        }
        return false;
    }

    /**
     * Instantiates the component and handles props.
     */
    private static function instantiateComponent(string $componentClass, array $props): string
    {
        $reflection = new ReflectionClass($componentClass);
        $attributes = $reflection->getAttributes(Component::class);
        $componentInstance = $attributes[0]->newInstance();

        $componentProps = $props;
        if ($componentInstance->useDto) {
            $componentPropsClassName = $componentClass . "PropsDto";
            if (class_exists($componentPropsClassName)) {
                $propsDto = new $componentPropsClassName();
                foreach ($props as $key => $value) {
                    if (property_exists($propsDto, $key)) {
                        $propsDto->$key = $value;
                    }
                }
                $componentProps = $propsDto;
            }
        }

        $component = new $componentClass($componentProps);

        ob_start();
        $renderResult = $component->render();

        if (is_string($renderResult)) {
            return $renderResult;
        }

        return ob_get_clean();
    }
}
