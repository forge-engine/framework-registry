<?php

declare(strict_types=1);

namespace Forge\Core\Routing;

use Forge\Core\Http\Request;

/**
 * Route node in the prefix tree structure for efficient route matching.
 */
class RouteNode
{
    /** @var array<string, RouteNode> Child nodes indexed by path segment */
    public array $children = [];
    
    /** @var array<string, RouteNode> Parameter children (indexed by parameter name) */
    public array $paramChildren = [];
    
    /** @var array<string, mixed> Route data for this exact path */
    public array $routes = [];
    
    /** @var array<string, mixed> Wildcard route data (catch-all) */
    public array $wildcardRoutes = [];
    
    /** @var string|null Parameter name if this is a parameter node */
    public ?string $paramName = null;
    
    /** @var bool Whether this is a wildcard node */
    public bool $isWildcard = false;
    
    /** @var string|null Regex pattern for parameter validation */
    public ?string $regex = null;
}

/**
 * Tree-based route matcher using prefix tree (Trie) data structure.
 * Provides O(k) route matching where k is the number of path segments.
 */
class RouteTree
{
    private RouteNode $root;
    
    public function __construct()
    {
        $this->root = new RouteNode();
    }
    
    /**
     * Add a route to the tree.
     *
     * @param string $method HTTP method
     * @param string $path Route path
     * @param array $routeData Route data
     */
    public function addRoute(string $method, string $path, array $routeData): void
    {
        $segments = $this->parsePath($path);
        $current = $this->root;
        
        foreach ($segments as $segment) {
            if ($segment === '*') {
                // Wildcard route
                $current->isWildcard = true;
                $current->wildcardRoutes[$method] = $routeData;
                return;
            }
            
            if (str_starts_with($segment, '{') && str_ends_with($segment, '}')) {
                // Parameter segment
                $paramName = substr($segment, 1, -1);
                
                // Check for regex constraint: {param:regex}
                if (str_contains($paramName, ':')) {
                    [$paramName, $regex] = explode(':', $paramName, 2);
                    $current->regex = $this->convertRegex($regex);
                }
                
                if (!isset($current->paramChildren[$paramName])) {
                    $current->paramChildren[$paramName] = new RouteNode();
                    $current->paramChildren[$paramName]->paramName = $paramName;
                    if (isset($current->regex)) {
                        $current->paramChildren[$paramName]->regex = $current->regex;
                        $current->regex = null; // Reset for next segment
                    }
                }
                $current = $current->paramChildren[$paramName];
            } else {
                // Static segment
                if (!isset($current->children[$segment])) {
                    $current->children[$segment] = new RouteNode();
                }
                $current = $current->children[$segment];
            }
        }
        
        $current->routes[$method] = $routeData;
    }
    
    /**
     * Find a route matching the given request.
     *
     * @param string $method HTTP method
     * @param string $path Request path
     * @return array|null Matched route data or null if not found
     */
    public function findRoute(string $method, string $path): ?array
    {
        $segments = $this->parsePath($path);
        $params = [];
        
        $result = $this->traverse($this->root, $segments, 0, $method, $params);
        
        if ($result !== null) {
            $result['params'] = $params;
        }
        
        return $result;
    }
    
    /**
     * Traverse the tree to find a matching route.
     *
     * @param RouteNode $node Current node
     * @param array $segments Remaining path segments
     * @param int $index Current segment index
     * @param string $method HTTP method
     * @param array $params Accumulated parameters
     * @return array|null Matched route data or null
     */
    private function traverse(RouteNode $node, array $segments, int $index, string $method, array &$params): ?array
    {
        // Check for exact route match at this node
        if ($index === count($segments) && isset($node->routes[$method])) {
            return $node->routes[$method];
        }
        
        // Check for wildcard route
        if ($node->isWildcard && isset($node->wildcardRoutes[$method])) {
            return $node->wildcardRoutes[$method];
        }
        
        // If we've consumed all segments and no match found
        if ($index >= count($segments)) {
            return null;
        }
        
        $segment = $segments[$index];
        
        // Try static segment first (fast path)
        if (isset($node->children[$segment])) {
            $result = $this->traverse($node->children[$segment], $segments, $index + 1, $method, $params);
            if ($result !== null) {
                return $result;
            }
        }
        
        // Try parameter segments
        foreach ($node->paramChildren as $paramName => $paramNode) {
            // Validate against regex if provided
            if ($paramNode->regex !== null && !preg_match($paramNode->regex, $segment)) {
                continue;
            }
            
            $params[$paramName] = $segment;
            $result = $this->traverse($paramNode, $segments, $index + 1, $method, $params);
            if ($result !== null) {
                return $result;
            }
            
            // Backtrack: remove parameter if no match found
            unset($params[$paramName]);
        }
        
        return null;
    }
    
    /**
     * Parse path into segments.
     *
     * @param string $path Route path
     * @return array<string> Path segments
     */
    private function parsePath(string $path): array
    {
        if ($path === '/') {
            return [];
        }
        
        $segments = explode('/', trim($path, '/'));
        return array_filter($segments, fn($seg) => $seg !== '');
    }
    
    /**
     * Convert route regex to proper PCRE pattern.
     *
     * @param string $regex Route regex pattern
     * @return string PCRE pattern
     */
    private function convertRegex(string $regex): string
    {
        return match ($regex) {
            '.+' => '#^.+$#',
            '[^/]+', 'no-slash' => '#^[^/]+$#',
            '[a-zA-Z0-9_-]+' => '#^[a-zA-Z0-9_-]+$#',
            '\d+' => '#^\d+$#',
            '\w+' => '#^\w+$#',
            default => "#^{$regex}$#",
        };
    }
    
    /**
     * Get tree statistics for debugging and monitoring.
     *
     * @return array<string, mixed> Tree statistics
     */
    public function getStats(): array
    {
        return [
            'total_nodes' => $this->countNodes($this->root),
            'max_depth' => $this->getMaxDepth($this->root),
            'static_routes' => $this->countRoutes($this->root, static fn($n) => !empty($n->routes)),
            'parameter_routes' => $this->countRoutes($this->root, static fn($n) => !empty($n->paramChildren)),
            'wildcard_routes' => $this->countRoutes($this->root, static fn($n) => $n->isWildcard),
        ];
    }
    
    /**
     * Count total nodes in the tree.
     */
    private function countNodes(RouteNode $node): int
    {
        $count = 1;
        foreach ($node->children as $child) {
            $count += $this->countNodes($child);
        }
        foreach ($node->paramChildren as $child) {
            $count += $this->countNodes($child);
        }
        return $count;
    }
    
    /**
     * Get maximum tree depth.
     */
    private function getMaxDepth(RouteNode $node, int $depth = 0): int
    {
        $maxDepth = $depth;
        foreach ($node->children as $child) {
            $maxDepth = max($maxDepth, $this->getMaxDepth($child, $depth + 1));
        }
        foreach ($node->paramChildren as $child) {
            $maxDepth = max($maxDepth, $this->getMaxDepth($child, $depth + 1));
        }
        return $maxDepth;
    }
    
    /**
     * Count routes matching a condition.
     */
    private function countRoutes(RouteNode $node, callable $condition): int
    {
        $count = $condition($node) ? count($node->routes) : 0;
        foreach ($node->children as $child) {
            $count += $this->countRoutes($child, $condition);
        }
        foreach ($node->paramChildren as $child) {
            $count += $this->countRoutes($child, $condition);
        }
        return $count;
    }
}