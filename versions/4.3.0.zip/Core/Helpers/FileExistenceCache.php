<?php

declare(strict_types=1);

namespace Forge\Core\Helpers;

final class FileExistenceCache
{
    private static array $cache = [];
    private static array $statCache = [];
    private static ?int $requestTime = null;

    public static function exists(string $path): bool
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = $path;
        
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $exists = file_exists($path);
        self::$cache[$key] = $exists;

        return $exists;
    }

    public static function isFile(string $path): bool
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = 'is_file:' . $path;
        
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $isFile = is_file($path);
        self::$cache[$key] = $isFile;

        return $isFile;
    }

    public static function isDir(string $path): bool
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = 'is_dir:' . $path;
        
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $isDir = is_dir($path);
        self::$cache[$key] = $isDir;

        return $isDir;
    }

    public static function isReadable(string $path): bool
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = 'is_readable:' . $path;
        
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $isReadable = is_readable($path);
        self::$cache[$key] = $isReadable;

        return $isReadable;
    }

    public static function isWritable(string $path): bool
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = 'is_writable:' . $path;
        
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $isWritable = is_writable($path);
        self::$cache[$key] = $isWritable;

        return $isWritable;
    }

    public static function getMtime(string $path): ?int
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = 'mtime:' . $path;
        
        if (isset(self::$statCache[$key])) {
            return self::$statCache[$key];
        }

        if (!file_exists($path)) {
            self::$statCache[$key] = null;
            return null;
        }

        $stat = stat($path);
        $mtime = $stat ? $stat['mtime'] : null;
        self::$statCache[$key] = $mtime;

        return $mtime;
    }

    public static function getSize(string $path): ?int
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $key = 'size:' . $path;
        
        if (isset(self::$statCache[$key])) {
            return self::$statCache[$key];
        }

        if (!is_file($path)) {
            self::$statCache[$key] = null;
            return null;
        }

        $stat = stat($path);
        $size = $stat ? $stat['size'] : null;
        self::$statCache[$key] = $size;

        return $size;
    }

    public static function clear(): void
    {
        self::$cache = [];
        self::$statCache = [];
    }

    public static function clearPath(string $path): void
    {
        foreach (self::$cache as $key => $value) {
            if (str_ends_with($key, $path)) {
                unset(self::$cache[$key]);
            }
        }
        
        foreach (self::$statCache as $key => $value) {
            if (str_ends_with($key, $path)) {
                unset(self::$statCache[$key]);
            }
        }
    }

    public static function preload(array $paths): void
    {
        if (self::$requestTime === null) {
            self::$requestTime = time();
        }

        $pathsToStat = [];
        
        foreach ($paths as $path) {
            $key = $path;
            $fileKey = 'is_file:' . $path;
            $dirKey = 'is_dir:' . $path;
            
            if (!isset(self::$cache[$key])) {
                $pathsToStat[] = $path;
            }
            
            if (!isset(self::$cache[$fileKey]) || !isset(self::$cache[$dirKey])) {
                $pathsToStat[] = $path;
            }
        }

        $uniquePaths = array_unique($pathsToStat);
        
        foreach ($uniquePaths as $path) {
            $exists = file_exists($path);
            $isFile = $isDir = false;
            $stat = null;
            
            if ($exists) {
                $isFile = is_file($path);
                $isDir = is_dir($path);
                $stat = stat($path);
            }
            
            self::$cache[$path] = $exists;
            self::$cache['is_file:' . $path] = $isFile;
            self::$cache['is_dir:' . $path] = $isDir;
            self::$cache['is_readable:' . $path] = is_readable($path);
            self::$cache['is_writable:' . $path] = is_writable($path);
            
            if ($stat) {
                self::$statCache['mtime:' . $path] = $stat['mtime'];
                self::$statCache['size:' . $path] = $stat['size'];
            }
        }
    }

    public static function getCacheStats(): array
    {
        return [
            'file_checks' => count(self::$cache),
            'stat_checks' => count(self::$statCache),
            'total_memory_estimate' => (count(self::$cache) + count(self::$statCache)) * 100,
        ];
    }
}
