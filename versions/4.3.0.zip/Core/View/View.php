<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\DI\Container;
use Forge\Core\Helpers\ModuleHelper;
use Forge\Core\Http\Response;
use Forge\Core\Structure\StructureResolver;
use RuntimeException;

final class View
{
    private static array $pathCache = [];
    private static array $componentPathCache = [];

    private static ?ViewState $sharedState = null;

    public function __construct(
        private readonly Container $container,
        private ?string $viewPath = null,
        private ?string $componentPath = null,
        private readonly ?string $module = null,
    ) {
        $basePath = defined("BASE_PATH") ? BASE_PATH : dirname(__DIR__, 5);

        if ($viewPath === null || $componentPath === null) {
            $structureResolver = $container->has(StructureResolver::class)
                ? $container->get(StructureResolver::class)
                : null;

            if ($structureResolver) {
                try {
                    $this->viewPath =
                        $viewPath ??
                        BASE_PATH .
                            "/" .
                            $structureResolver->getAppPath("views");
                    $this->componentPath =
                        $componentPath ??
                        BASE_PATH .
                            "/" .
                            $structureResolver->getAppPath("components");
                } catch (\InvalidArgumentException $e) {
                    $this->viewPath =
                        $viewPath ?? $basePath . "/app/resources/views";
                    $this->componentPath =
                        $componentPath ??
                        $basePath . "/app/resources/components";
                }
            } else {
                $this->viewPath =
                    $viewPath ?? $basePath . "/app/resources/views";
                $this->componentPath =
                    $componentPath ?? $basePath . "/app/resources/components";
            }
        } else {
            $this->viewPath = $viewPath;
            $this->componentPath = $componentPath;
        }
    }

    private static function getState(): ViewState
    {
        return self::$sharedState ??= new ViewState();
    }

    public static function suppressLayout(bool $suppress = true): void
    {
        self::getState()->setShouldSuppressLayout($suppress);
    }

    public static function layout(
        string $name,
        bool $loadFromModule = false,
        ?string $moduleName = null,
    ): void {
        if (self::getState()->shouldSuppressLayout()) {
            return;
        }
        self::getState()->setLayout([
            "name" => $name,
            "useModulePath" => $loadFromModule,
            "moduleName" => $moduleName,
        ]);
    }

    public static function startSection(string $name): void
    {
        self::getState()->startSection($name);
    }

    public static function endSection(): void
    {
        self::getState()->endSection();
    }

    public static function section(string $name): string
    {
        return self::getState()->getSection($name);
    }

    public static function slot(
        string $name = "default",
        string $default = "",
    ): string {
        return self::getState()->getSlot($name, $default);
    }

    public static function component(
        string $name,
        array|object $props = [],
        bool $loadFromModule = false,
    ): string {
        return Component::render($name, $props, $loadFromModule);
    }

    public function render(string $view, array $data = []): Response
    {
        $state = self::getState();
        $viewContent = $this->compileView($view, $data);

        if ($state->getLayout()) {
            $layoutName = $state->getLayout()["name"];
            $useModulePath = $state->getLayout()["useModulePath"] ?? false;
            $moduleName = $state->getLayout()["moduleName"] ?? null;

            $layoutData = array_merge(
                $data,
                ["content" => $viewContent],
                $state->getSections(),
            );
            $layoutFile = $this->resolveLayoutFile(
                $layoutName,
                $moduleName,
                $useModulePath,
            );
            $viewContent = $this->executeFile($layoutFile, $layoutData);
        }

        $state->reset();

        return new Response($viewContent);
    }

    private function compileView(
        string $view,
        array $data,
        ?string $basePath = null,
    ): string {
        $viewFile = $this->resolveViewFile($view, $basePath);
        return $this->executeFile($viewFile, $data);
    }

    private function resolveViewFile(
        string $view,
        ?string $basePath = null,
    ): string {
        $cacheKey =
            $view .
            "|" .
            ($basePath ?? $this->viewPath) .
            "|" .
            ($this->module ?? "");

        if (isset(self::$pathCache[$cacheKey])) {
            return self::$pathCache[$cacheKey];
        }

        $structureResolver = $this->container->has(StructureResolver::class)
            ? $this->container->get(StructureResolver::class)
            : null;

        $resolvedPath = null;

        if (str_contains($view, ":")) {
            [$module, $relative] = explode(":", $view, 2);
            if (ModuleHelper::isModuleDisabled($module)) {
                throw new RuntimeException(
                    "View file not found: {$view} (Module {$module} is disabled)",
                );
            }

            $resolvedPath = $this->resolveModuleViewPath(
                $module,
                $relative,
                $structureResolver,
            );
        } elseif ($this->module) {
            if (ModuleHelper::isModuleDisabled($this->module)) {
                throw new RuntimeException(
                    "View file not found: {$view} (Module {$this->module} is disabled)",
                );
            }

            $resolvedPath = $this->resolveModuleViewPath(
                $this->module,
                $view,
                $structureResolver,
            );
        }

        if ($resolvedPath === null) {
            $basePath = $basePath ?? $this->viewPath;
            $file = "{$basePath}/{$view}.php";

            if (!is_file($file)) {
                throw new RuntimeException(
                    "View file not found: {$view} (Searched in: {$file})",
                );
            }

            $resolvedPath = $file;
        }

        self::$pathCache[$cacheKey] = $resolvedPath;
        return $resolvedPath;
    }

    private function getStructureResolver(): ?StructureResolver
    {
        return $this->container->has(StructureResolver::class)
            ? $this->container->get(StructureResolver::class)
            : null;
    }

    private function resolveModuleViewPath(
        string $module,
        string $relative,
        ?StructureResolver $structureResolver,
    ): ?string {
        if ($structureResolver) {
            try {
                $moduleViewsPath = $structureResolver->getModulePath(
                    $module,
                    "views",
                );
                $modulePath =
                    BASE_PATH .
                    "/modules/{$module}/{$moduleViewsPath}/{$relative}.php";
                if (is_file($modulePath)) {
                    return $modulePath;
                }
            } catch (\InvalidArgumentException $e) {
            }
        }

        foreach (["Resources", "resources"] as $res) {
            $modulePath =
                BASE_PATH .
                "/modules/{$module}/src/{$res}/views/{$relative}.php";
            if (is_file($modulePath)) {
                return $modulePath;
            }
        }

        return null;
    }

    private function resolveLayoutFile(
        string $layoutName,
        ?string $moduleName,
        bool $useModulePath,
    ): string {
        if ($moduleName) {
            return $this->resolveViewFile(
                "{$moduleName}:layouts/{$layoutName}",
            );
        }

        if ($useModulePath || str_contains($layoutName, ":")) {
            return $this->resolveViewFile("layouts/{$layoutName}");
        }

        $appViewPath = $this->getAppViewPath();
        return $this->resolveViewFile("layouts/{$layoutName}", $appViewPath);
    }

    private function getAppViewPath(): string
    {
        $structureResolver = $this->getStructureResolver();

        if ($structureResolver) {
            try {
                $appViewsPath = $structureResolver->getAppPath("views");
                return BASE_PATH . "/" . $appViewsPath;
            } catch (\InvalidArgumentException $e) {
            }
        }

        return defined("BASE_PATH")
            ? BASE_PATH . "/app/resources/views"
            : $this->viewPath;
    }

    private function buildModulePaths(
        string $module,
        string $relative,
        string $type,
    ): array {
        $paths = [];
        $structureResolver = $this->getStructureResolver();

        if ($structureResolver) {
            try {
                $modulePath = $structureResolver->getModulePath($module, $type);
                $paths[] =
                    BASE_PATH .
                    "/modules/{$module}/{$modulePath}/{$relative}.php";

                if ($type === "components") {
                    $moduleViewsPath = $structureResolver->getModulePath(
                        $module,
                        "views",
                    );
                    $paths[] =
                        BASE_PATH .
                        "/modules/{$module}/{$moduleViewsPath}/components/{$relative}.php";
                }
            } catch (\InvalidArgumentException $e) {
            }
        }

        foreach (["Resources", "resources"] as $res) {
            $paths[] =
                BASE_PATH .
                "/modules/{$module}/src/{$res}/{$type}/{$relative}.php";

            if ($type === "components") {
                $paths[] =
                    BASE_PATH .
                    "/modules/{$module}/src/{$res}/views/components/{$relative}.php";
            }
        }

        return array_unique($paths);
    }

    private function executeFile(string $file, array|object|null $data): string
    {
        $vars = is_object($data) ? get_object_vars($data) : $data;
        if (!empty($vars)) {
            extract($vars, EXTR_SKIP);
        }

        if (is_object($data)) {
            $props = $data;
        } else {
            $props = $data ?? [];
        }

        ob_start();
        try {
            include $file;
            return ob_get_clean();
        } catch (\Throwable $e) {
            $buffer = ob_get_clean();
            throw new \RuntimeException(
                "Error rendering view [{$file}]: {$e->getMessage()}\n\nBuffer Content:\n{$buffer}",
                (int) $e->getCode(),
                $e,
            );
        }
    }

    public static function viewComponent(
        string $path,
        array|object|null $props = [],
        ?string $module = null,
        array $slots = [],
    ): string {
        $view = new self(container: Container::getInstance(), module: $module);
        $processedSlots = $view->processSlots($slots);
        return $view->renderComponentView($path, $props, $processedSlots);
    }

    private function processSlots(array $slots): array
    {
        if (empty($slots)) {
            return [];
        }

        $processed = [];

        foreach ($slots as $name => $content) {
            if (is_array($content) && isset($content["name"])) {
                $processed[$name] = function () use ($content) {
                    $componentName = $content["name"];
                    $componentProps = $content["props"] ?? [];
                    $componentSlots = $content["slots"] ?? [];

                    $componentModule = null;
                    if (str_contains($componentName, ":")) {
                        [$componentModule, $componentName] = explode(
                            ":",
                            $componentName,
                            2,
                        );
                    }

                    $nestedSlots = $this->processSlots($componentSlots);

                    return $this->renderComponentView(
                        $componentName,
                        $componentProps,
                        $nestedSlots,
                        $componentModule,
                    );
                };

                continue;
            }

            $processed[$name] = fn() => (string) $content;
        }

        return $processed;
    }

    public function renderComponentView(
        string $viewSubPath,
        array|object|null $data = [],
        array $slots = [],
        ?string $module = null,
    ): string {
        $state = self::getState();
        $previousSlots = $state->getSlots();
        $state->setSlots($slots);

        $view =
            $module !== null
                ? new self(container: $this->container, module: $module)
                : $this;

        $file = $view->resolveComponentFile($viewSubPath, $view->module);
        $result = $view->executeFile($file, $data);

        $state->setSlots($previousSlots);

        return $result;
    }

    private function resolveComponentFile(
        string $component,
        ?string $module = null,
    ): string {
        $cacheKey =
            $component .
            "|" .
            ($module ?? ($this->module ?? "")) .
            "|" .
            $this->componentPath;

        if (isset(self::$componentPathCache[$cacheKey])) {
            return self::$componentPathCache[$cacheKey];
        }

        $structureResolver = $this->container->has(StructureResolver::class)
            ? $this->container->get(StructureResolver::class)
            : null;

        $resolvedPath = null;

        if (str_contains($component, ":")) {
            [$moduleName, $relative] = explode(":", $component, 2);
            if (ModuleHelper::isModuleDisabled($moduleName)) {
                throw new RuntimeException(
                    "Module component template not found: {$relative} in module {$moduleName} (Module is disabled)",
                );
            }

            $resolvedPath = $this->resolveModuleComponentPath(
                $moduleName,
                $relative,
                $structureResolver,
            );
        } elseif ($module) {
            if (ModuleHelper::isModuleDisabled($module)) {
                throw new RuntimeException(
                    "Component template not found: {$component} (Module {$module} is disabled)",
                );
            }

            $resolvedPath = $this->resolveModuleComponentPath(
                $module,
                $component,
                $structureResolver,
            );
        }

        if ($resolvedPath === null) {
            $file = "{$this->componentPath}/{$component}.php";
            if (is_file($file)) {
                $resolvedPath = $file;
            }
        }

        if ($resolvedPath === null) {
            throw new RuntimeException(
                "Component template not found: {$component}",
            );
        }

        self::$componentPathCache[$cacheKey] = $resolvedPath;
        return $resolvedPath;
    }

    private function resolveModuleComponentPath(
        string $module,
        string $relative,
        ?StructureResolver $structureResolver,
    ): ?string {
        $paths = $this->buildModulePaths($module, $relative, "components");

        foreach ($paths as $file) {
            if (is_file($file)) {
                return $file;
            }
        }

        return null;
    }
}
