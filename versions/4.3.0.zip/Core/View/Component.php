<?php
declare(strict_types=1);

namespace Forge\Core\View;

use Attribute;
use Forge\Core\DI\Container;
use Forge\Core\Helpers\Strings;
use Forge\Core\Structure\StructureResolver;
use ReflectionClass;
use ReflectionException;
use RuntimeException;

#[Attribute(Attribute::TARGET_CLASS)]
final class Component
{
  private static array $reflectionCache = [];
  
  public function __construct(
    public string $name
  ) {
  }

  /**
   * Render a component by attribute name.
   *
   * @throws ReflectionException
   */
  public static function render(string $name, array|object $props = [], bool $loadFromModule = false): string
  {
    $fqcn = self::resolveClassName($name, $loadFromModule);

    if (!class_exists($fqcn)) {
      throw new RuntimeException("Component class not found: {$fqcn}");
    }

    $cacheKey = $fqcn . '|' . $name;
    
    if (!isset(self::$reflectionCache[$cacheKey])) {
      $reflection = new ReflectionClass($fqcn);
      $attr = $reflection->getAttributes(self::class)[0] ?? null;
      if ($attr === null || $attr->newInstance()->name !== $name) {
        throw new RuntimeException("Attribute mismatch for {$fqcn}");
      }
      self::$reflectionCache[$cacheKey] = $reflection;
    }

    $reflection = self::$reflectionCache[$cacheKey];
    $component = $reflection->newInstance($props);
    return (string) $component->render();
  }

  private static function resolveClassName(string $name, bool $module): string
  {
    $parts = preg_split('#[/:]#', $name);
    $class = Strings::toPascalCase(array_pop($parts));

    if ($module) {
      $moduleName = Strings::toPascalCase($parts[0]);
      $subNs = array_map([Strings::class, 'toPascalCase'], array_slice($parts, 1));

      $container = Container::getInstance();
      $structureResolver = $container->has(StructureResolver::class)
        ? $container->get(StructureResolver::class)
        : null;

      $componentsPath = 'Resources/Components';
      if ($structureResolver) {
        try {
          $moduleComponentsPath = $structureResolver->getModulePath($moduleName, 'components');
          $componentsPath = str_replace('/', '\\', $moduleComponentsPath);
          if (str_starts_with($componentsPath, 'src\\')) {
            $componentsPath = substr($componentsPath, 4);
          }
          $componentsPath = str_replace('\\', '/', $componentsPath);
          $pathParts = explode('/', $componentsPath);
          $componentsPath = implode('\\', array_map([Strings::class, 'toPascalCase'], $pathParts));
        } catch (\InvalidArgumentException $e) {
          $componentsPath = 'Resources\\Components';
        }
      } else {
        $componentsPath = 'Resources\\Components';
      }

      return 'App\\Modules\\' . $moduleName . '\\' . $componentsPath
        . ($subNs ? '\\' . implode('\\', $subNs) : '')
        . '\\' . $class;
    }

    $subNs = array_map([Strings::class, 'toPascalCase'], $parts);
    return 'App\\Components'
      . ($subNs ? '\\' . implode('\\', $subNs) : '')
      . '\\' . $class;
  }
}
