<?php

declare(strict_types=1);

namespace Forge\Core\View;

final class ViewState
{
  private ?array $layout = null;
  private bool $shouldSuppressLayout = false;
  private array $sections = [];
  private string $currentSection = "";
  private array $slots = [];

  public function getLayout(): ?array
  {
    return $this->layout;
  }

  public function setLayout(?array $layout): void
  {
    $this->layout = $layout;
  }

  public function shouldSuppressLayout(): bool
  {
    return $this->shouldSuppressLayout;
  }

  public function setShouldSuppressLayout(bool $suppress): void
  {
    $this->shouldSuppressLayout = $suppress;
  }

  public function getSections(): array
  {
    return $this->sections;
  }

  public function getSection(string $name): string
  {
    return $this->sections[$name] ?? "";
  }

  public function startSection(string $name): void
  {
    $this->currentSection = $name;
    ob_start();
  }

  public function endSection(): void
  {
    $this->sections[$this->currentSection] = ob_get_clean();
    $this->currentSection = "";
  }

  public function getSlots(): array
  {
    return $this->slots;
  }

  public function setSlots(array $slots): void
  {
    $this->slots = $slots;
  }

  public function getSlot(string $name = 'default', string $default = ''): string
  {
    if (!isset($this->slots[$name])) {
      return $default;
    }

    $slot = $this->slots[$name];

    return is_callable($slot)
      ? (string) $slot()
      : (string) $slot;
  }

  public function reset(): void
  {
    $this->layout = null;
    $this->shouldSuppressLayout = false;
    $this->sections = [];
    $this->currentSection = "";
    $this->slots = [];
  }
}