<?php
declare(strict_types=1);

namespace Forge\Traits;

trait CacheLifecycleHooks
{
    public static function onCacheHit($instance, $args, $key, $data): void
    {
        echo "Cache hit for {$key}\n";
    }

    public static function onCacheMiss($instance, $args, $key): void
    {
        echo "Cache miss for {$key}\n";
    }

    public static function onCacheSave($instance, $args, $key, $data): void
    {
        echo "Saved to cache {$key}\n";
    }

    public static function onCacheError($instance, $args, $key, $e): void
    {
        echo "Cache error for {$key}: {$e->getMessage()}\n";
    }
}