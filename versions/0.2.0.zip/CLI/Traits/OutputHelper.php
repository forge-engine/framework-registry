<?php

declare(strict_types=1);

namespace Forge\CLI\Traits;

trait OutputHelper
{
    /**
     * Outputs a blue (info) message to the console.
     *
     * @param string $message The message to output.
     * @param string $context Optional context string to prepend to the message (e.g., a module name).
     */
    protected function info(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[0;34m" . $prefix . $message . "\033[0m");
    }

    /**
     * Clears the terminal screen.
     * Uses ANSI escape codes for broader compatibility.
     */
    protected function clearScreen(): void
    {
        echo "\033[H\033[2J";
    }

    /**
     * Outputs a yellow (warning) message to the console.
     *
     * @param string $message The message to output.
     * @param string $context Optional context string to prepend to the message (e.g., a module name).
     */
    protected function warning(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[1;33m" . $prefix . $message . "\033[0m");
    }

    /**
     * Outputs a red (error) message to the console.
     *
     * @param string $message The message to output.
     * @param string $context Optional context string to prepend to the message (e.g., a module name).
     */
    protected function error(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[0;31m" . $prefix . $message . "\033[0m");
    }

    /**
     * Outputs a yellow/brown (comment) message to the console.
     *
     * @param string $message The message to output.
     * @param string $context Optional context string to prepend to the message (e.g., a module name).
     */
    protected function comment(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[0;33m" . $prefix . $message . "\033[0m");
    }

    /**
     * Outputs a magenta (debug) message to the console.
     *
     * @param string $message The message to output.
     * @param string $context Optional context string to prepend to the message (e.g., a module name).
     */
    protected function debug(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        // Note: The original debug function used echo directly without PHP_EOL, I'm keeping it line-ending-less but adding context.
        echo "\033[35m{$prefix}{$message}\033[0m\n";
    }

    /**
     * Outputs a timestamped log message with optional context.
     *
     * @param string $message The message to output.
     * @param string $context Optional context for the log entry. Defaults to 'LOG'.
     */
    protected function log(string $message, string $context = 'LOG'): void
    {
        $logMessage = "[" . date('Y-m-d H:i:s') . "] [" . $context . "]: {$message}";
        $this->output($logMessage);
    }

    /**
     * Outputs a cyan (prompt) message to the console.
     *
     * @param string $message The prompt message.
     */
    protected function prompt(string $message): void
    {
        echo "\033[36m{$message}\033[0m ";
    }

    /**
     * Outputs an array in a readable, formatted way, optionally with a title.
     * Recursively handles nested arrays.
     *
     * @param array<string|int, mixed> $data The array data to display.
     * @param string|null $title Optional title for the array output.
     */
    protected function array(array $data, ?string $title = null): void
    {
        if ($title) {
            $this->info($title);
        }

        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $this->array($value, (string)$key);
                continue;
            }
            $this->output(sprintf("\033[0;36m%s:\033[0m %s", $key, $value));
        }
    }

    /**
     * Outputs a simple line of text followed by a line ending.
     *
     * @param string $message The message to output. Defaults to an empty line.
     */
    protected function line(string $message = ""): void
    {
        $this->output($message);
    }

    /**
     * Outputs a green (success) message to the console.
     *
     * @param string $message The message to output.
     * @param string $context Optional context string to prepend to the message (e.g., a module name).
     */
    protected function success(string $message, string $context = ''): void
    {
        $prefix = $context ? "[{$context}] " : '';
        $this->output("\033[1;32m" . $prefix . $message . "\033[0m");
    }

    /**
     * Internal helper to output a message followed by a line ending.
     *
     * @param string $message The message to output.
     */
    private function output(string $message): void
    {
        echo $message . PHP_EOL;
    }

    /**
     * Outputs data in a formatted console table.
     *
     * @param array<int, string> $headers An indexed array of header names.
     * @param array<int, array<string, mixed>|object> $rows An array of row data (associative arrays or objects).
     */
    protected function table(array $headers, array $rows): void
    {
        if (empty($headers) || empty($rows)) {
            return;
        }

        $columnsWidth = array_map('strlen', $headers);

        // Calculate maximum column width
        foreach ($rows as $row) {
            if (is_array($row)) {
                foreach ($headers as $index => $header) {
                    $value = $row[$header] ?? '';
                    $columnsWidth[$index] = max($columnsWidth[$index], strlen((string)$value));
                }
            } elseif (is_object($row)) {
                foreach ($headers as $index => $header) {
                    if (isset($row->$header)) {
                        $columnsWidth[$index] = max($columnsWidth[$index], strlen((string)$row->$header));
                    } else {
                        $columnsWidth[$index] = max($columnsWidth[$index], strlen(''));
                    }
                }
            }
        }

        // Print header
        $headerLine = '| ' . implode(' | ', array_map(function ($header, $width) {
                return str_pad($header, $width);
            }, $headers, $columnsWidth)) . ' |';
        $this->line($headerLine);

        // Print separator
        $separator = '+';
        foreach ($columnsWidth as $width) {
            $separator .= str_repeat('-', $width + 2) . '+';
        }
        $this->line($separator);

        // Print rows
        foreach ($rows as $row) {
            $rowOutput = '| ';

            foreach ($headers as $index => $header) {
                $value = '';
                if (is_array($row) && array_key_exists($header, $row)) {
                    $value = $row[$header];
                } elseif (is_object($row) && isset($row->$header)) {
                    $value = $row->$header;
                }

                $rowOutput .= str_pad((string)$value, $columnsWidth[$index]) . ' | ';
            }

            $this->line($rowOutput);
        }
    }
}