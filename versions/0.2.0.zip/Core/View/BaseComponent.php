<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\DI\Container;
use Forge\Core\View\View;
use ReflectionClass;

abstract class BaseComponent
{
    protected array|object $props;

    public function __construct(array|object $props)
    {
        $this->props = $props;
    }

    abstract public function render(): mixed;

    protected function renderview(string $viewPath, array|object $data = [], bool $loadFromModule = false): string
    {
        $componentPath =  $loadFromModule ? BASE_PATH . "/modules/{$this->getModuleName()}/src/resources/components" : null;
        $view = new View(
            container: Container::getInstance(),
            componentPath: $componentPath
        );
        return $view->renderComponent($viewPath, $data);
    }

    private function convertDtoToArray(object $dto): array
    {
        $reflection = new ReflectionClass($dto);
        $propsArray = [];
        foreach ($reflection->getProperties() as $prop) {
            $prop->setAccessible(true);
            $propsArray[$prop->getName()] = $prop->getValue($dto);
        }
        return $propsArray;
    }

    protected function getModuleName(): string
    {
        $class = static::class;
        preg_match('/\\\\Modules\\\\([^\\\\]+)\\\\/', $class, $matches);
        return $matches[1] ?? throw new \Exception("Unable to determine module name from class {$class}");
    }
}
