<?php

declare(strict_types=1);

namespace Forge\Core\Database\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
final class MetaData
{
    public function __construct(
        public string $column = 'metadata'
    ) {
    }
}
