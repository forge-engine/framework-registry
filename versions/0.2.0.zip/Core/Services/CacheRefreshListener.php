<?php
declare(strict_types=1);

namespace Forge\Core\Services;

use App\Modules\ForgeEvents\Attributes\EventListener;
use Forge\Core\Cache\CacheManager;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Events\CacheRefreshEvent;

#[Service]
final readonly class CacheRefreshListener
{
    public function __construct(private CacheManager $cache)
    {
    }

    /**
     * @throws \ReflectionException
     * @throws \JsonException
     */
    #[EventListener(CacheRefreshEvent::class)]
    public function handle(CacheRefreshEvent $event): void
    {
        $manager = $event->driver ? new CacheManager($event->driver) : $this->cache;

        $method = new \ReflectionMethod($event->instance, $event->method);
        $result = $method->invokeArgs($event->instance, $event->args);

        $manager->set($event->key, $result, ttl: null);
    }
}