<?php
declare(strict_types=1);

namespace Forge\Core\Cache;

use Forge\Core\Cache\Drivers\FileCacheDriver;
use Forge\Core\Cache\Drivers\MemoryCacheDriver;
use Forge\Core\Cache\Drivers\SqliteCacheDriver;
use Forge\Core\Config\Environment;
use Forge\Core\Database\Model;

final class CacheManager
{
    private CacheDriverInterface $driver;

    public function __construct(?string $driver = null)
    {
        $env = Environment::getInstance();
        $driver = $driver ?? $env->get('CACHE_DRIVER', 'file');

        $this->driver = match ($driver) {
            'memory' => new MemoryCacheDriver(),
            'sqlite' => new SqliteCacheDriver(),
            default => new FileCacheDriver(),
        };
    }

    /**
     * @throws \JsonException
     */
    public function get(string $key): mixed
    {
        $raw = $this->driver->get($key);
        return $this->handleData($raw);
    }

    /**
     * @throws \JsonException
     */
    public function getExpired(string $key): mixed
    {
        $raw = $this->driver->getExpired($key);
        return $this->handleData($raw);
    }

    /**
     * @throws \JsonException
     */
    private function handleData(mixed $raw): mixed
    {
        if ($raw === null) {
            return null;
        }

        $payload = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);

        if (!isset($payload['d'])) {
            return null;
        }

        if (($payload['c'] ?? null) === null || !class_exists($payload['c'])) {
            return $payload['d'];
        }

        $class = $payload['c'];
        $data = $payload['d'];
        return new $class($payload['d']);
    }


    /**
     * @throws \JsonException
     */
    public function set(string $key, mixed $value, ?int $ttl = null): void
    {
        $class = null;
        $data = $value;

        if ($value instanceof Model) {
            $class = get_class($value);
            $data = $value->jsonSerialize();
        }

        $payload = [
            'c' => $class,
            'd' => $data,
        ];

        $this->driver->set($key, json_encode($payload, JSON_THROW_ON_ERROR), $ttl);
    }

    public function delete(string $key): void
    {
        $this->driver->delete($key);
    }

    public function clear(): void
    {
        $this->driver->clear();
    }
}