<?php

declare(strict_types=1);

namespace Forge\Core\Cache\Drivers;

use Forge\Core\Cache\CacheDriverInterface;

final class FileCacheDriver implements CacheDriverInterface
{
    private string $path;

    public function __construct(string $path = BASE_PATH . '/storage/framework/cache')
    {
        $this->path = rtrim($path, '/');
        if (!is_dir($this->path)) {
            mkdir($this->path, 0755, true);
        }
    }

    private function filePath(string $key): string
    {
        return $this->path . '/' . md5($key) . '.cache';
    }

    /**
     * @throws \JsonException
     */
    public function get(string $key): mixed
    {
        $file = $this->filePath($key);
        if (!is_file($file)) return null;

        $raw = file_get_contents($file);
        $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);

        return $data['value'];
    }

    /**
     * @throws \JsonException
     */
    public function getExpired(string $key): mixed
    {
        $file = $this->filePath($key);
        if (!is_file($file)) return null;

        $raw = file_get_contents($file);
        $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);

        return $data['value'];
    }

    /**
     * @throws \JsonException
     */
    public function set(string $key, mixed $value, ?int $ttl = null): void
    {
        $file = $this->filePath($key);
        $expiresAt = $ttl ? time() + $ttl : null;

        $payload = json_encode([
            'value' => $value,
            'expires_at' => $expiresAt,
        ], JSON_THROW_ON_ERROR);

        file_put_contents($file, $payload, LOCK_EX);
    }

    public function delete(string $key): void
    {
        $file = $this->filePath($key);
        if (is_file($file)) {
            unlink($file);
        }
    }

    public function clear(): void
    {
        foreach (glob($this->path . '/*.cache') as $f) {
            unlink($f);
        }
    }
}