<?php
declare(strict_types=1);

namespace Forge\tests\Engine\Fixtures;

final class NeedsInt
{
    public function __construct(int $value)
    {
    }
}
