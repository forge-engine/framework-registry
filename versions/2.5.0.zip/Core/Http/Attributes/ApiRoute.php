<?php

declare(strict_types=1);

namespace Forge\Core\Http\Attributes;

use Attribute;
use Forge\Core\Routing\Route;

#[Attribute(Attribute::TARGET_METHOD)]
final class ApiRoute extends Route
{
    public function __construct(
        string $path,
        string $method = 'GET',
        public array $middlewares = [],
        string $prefix = 'api',
        string $version = 'v1',
        public array $permissions = []
    ) {
        $apiPath = "/{$prefix}/{$version}{$path}";
        parent::__construct($apiPath, $method, $middlewares, $permissions);
    }
}
