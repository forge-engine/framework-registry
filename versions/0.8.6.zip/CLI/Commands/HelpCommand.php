<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\Core\DI\Attributes\Service;
use ReflectionClass;
use ReflectionException;

#[Service]
#[Cli(command: 'help', description: 'Displays help for available commands.')]
class HelpCommand extends Command
{
    /**
     * @throws ReflectionException
     */
    public function execute(array $args): int
    {
        if ($cmd = $this->option('command', $GLOBALS['argv'] ?? [])) {
            $this->showCommandHelp($cmd, $args);
            return 0;
        }

        $this->showGlobalHelp($args);

        return 0;
    }

    /**
     * @throws ReflectionException
     */
    private function showCommandHelp(string $name, array $commands): void
    {
        if (!isset($commands[$name])) {
            $this->error("Command $name not found.");
            return;
        }

        [$class] = $commands[$name];
        $ref = new ReflectionClass($class);

        $cliAttrs = $ref->getAttributes(Cli::class);
        $cli = count($cliAttrs) ? $cliAttrs[0]->newInstance() : null;

        $this->line('');
        $this->info("Command: $name");
        $this->line($cli?->description ?? '');
        $this->line('');

        if ($cli?->usage) {
            $this->comment('Usage:');
            $this->line('  php forge.php ' . $cli->usage);
            $this->line('');
        }

        $args = [];
        foreach ($ref->getProperties() as $p) {
            $argAttrs = $p->getAttributes(Arg::class);
            $arg = count($argAttrs) ? $argAttrs[0]->newInstance() : null;
            if (!$arg) continue;

            $args[] = [
                'OPTION' => '--' . $arg->name,
                'DESCRIPTION' => $arg->description . ($arg->required ? ' (required)' : ''),
            ];
        }

        if ($args) {
            $this->comment('Arguments:');
            $this->table(['OPTION', 'DESCRIPTION'], $args);
            $this->line('');
        }

        if ($cli?->examples) {
            $this->comment('Examples:');
            foreach ($cli->examples as $ex) {
                $this->line('  php forge.php ' . $ex);
            }
            $this->line('');
        }
    }

    /**
     * @throws ReflectionException
     */
    private function showGlobalHelp(array $args): void
    {
        $this->line();
        $this->info("Forge Framework CLI Tool");

        $grouped = [];

        foreach ($args as $name => $commandInfo) {
            $commandClass = $commandInfo[0] ?? null;
            if (!$commandClass) continue;

            $reflectionClass = new ReflectionClass($commandClass);
            $cliAttrs = $reflectionClass->getAttributes(Cli::class);
            $cli = count($cliAttrs) ? $cliAttrs[0]->newInstance() : null;
            if (!$cli) continue;

            $prefix = strstr($name, ':', true) ?: 'General';
            $grouped[$prefix][$name] = $cli->description;
        }

        ksort($grouped);

        foreach ($grouped as $group => $commands) {
            $this->line("\n\033[1;34m" . ucfirst($group) . " commands\033[0m");

            ksort($commands);

            $headers = ['COMMAND', 'DESCRIPTION'];
            $rows = [];
            foreach ($commands as $cmd => $desc) {
                $rows[] = ['COMMAND' => $cmd, 'DESCRIPTION' => $desc];
            }

            $this->table($headers, $rows);
        }

        $this->line('');
        $this->comment("Run php forge.php help --command=<name> for detailed usage and examples.");
    }
}