<?php

declare(strict_types=1);

use Forge\Core\Database\Migrations\Migration;

class CreatePermissionsTable extends Migration
{
    public function up(): void
    {
        $this->queryBuilder->setTable('permissions')
            ->createTable([
                'id' => 'INTEGER PRIMARY KEY AUTOINCREMENT',
                'name' => 'VARCHAR(255) UNIQUE NOT NULL',
                'description' => 'TEXT',
            ]);
        $this->execute($this->queryBuilder->getSql());
    }

    public function down(): void
    {
        $this->execute($this->queryBuilder->dropTable('permissions'));
    }
}
