<?php

declare(strict_types=1);

namespace Forge\Core\Repository;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\Database\Model;
use Forge\Core\Database\QueryBuilder;
use Forge\Core\Dto\Attributes\Sanitize;
use Forge\Core\Dto\BaseDto;
use Forge\Traits\PaginationHelper;
use ReflectionClass;

#[Service]
abstract class BaseRepository
{
    use PaginationHelper;

    protected string $modelClass;
    protected ?string $dtoClass = null;
    protected array $propertiesToSanitize = [];
    protected array $searchableFields = [];

    /**
     * @param string $modelClass
     * @param string|null $dtoClass DTO class to hydrate results into (optional)
     */
    public function __construct(
        private QueryBuilder $queryBuilder,
        string $modelClass,
        ?string $dtoClass = null
    ) {
        $this->queryBuilder = $queryBuilder;
        $this->modelClass = $modelClass;
        $this->dtoClass = $dtoClass;
        $this->queryBuilder->setTable($modelClass::getTable());
        $this->loadSanitizePropertiesFromAttribute();
    }

    /**
     * Loads the searchable fields. You might want to define this logic based on attributes or a specific method in your Model.
     */
    protected function loadSearchableFields(): void
    {
    }

    /**
    * Loads the properties to sanitize from the Sanitize attribute on the DTO class.
    */
    private function loadSanitizePropertiesFromAttribute(): void
    {
        if ($this->dtoClass !== null) {
            $reflection = new ReflectionClass($this->dtoClass);
            $attributes = $reflection->getAttributes(Sanitize::class);

            if (!empty($attributes)) {
                $sanitizeAttribute = $attributes[0]->newInstance();
                $this->propertiesToSanitize = $sanitizeAttribute->properties;
            }
        }
    }

    /**
     * Sanitize a DTO object by setting specified properties to null.
     *
     * @param BaseDto|null $dto
     * @return BaseDto|null
     */
    protected function sanitizeDto(?BaseDto $dto): ?BaseDto
    {
        if ($dto === null) {
            return null;
        }

        $reflection = new ReflectionClass($dto);
        foreach ($this->propertiesToSanitize as $propertyName) {
            $property = $reflection->getProperty($propertyName);
            $property->setAccessible(true);
            $property->setValue($dto, null);
        }
        return $dto;
    }

    /**
     * @template T of object
     * @param QueryBuilder $query
     * @return array<T>|T|Model|null
     */
    protected function fetch(QueryBuilder $query): array|object|null
    {
        if ($this->dtoClass !== null) {
            $results = $query->get($this->dtoClass);
            if (is_array($results)) {
                return array_map(fn ($dto) => $this->sanitizeDto($dto), $results);
            }
            return $this->sanitizeDto($results);
        }
        return $query->get($this->modelClass);
    }

    /**
     * @template T of object
     * @return array<T>|array<Model>
     */
    public function findAll(): array
    {
        return $this->fetch($this->queryBuilder->select("*"));
    }

    /**
     * @template T of object
     * @return T|Model|null
     */
    public function findById(mixed $id): object|null
    {
        if ($this->dtoClass !== null) {
            $results = $this->queryBuilder
                ->where($this->getModelPrimaryKey(), "=", $id)
                ->first($this->dtoClass);
            return $this->sanitizeDto($results);
        }
        return $this->queryBuilder
            ->where($this->getModelPrimaryKey(), "=", $id)
            ->first($this->modelClass);
    }

    /**
     * @template T of object
     * @return T|Model|null
     */
    public function findByProperty(string $property, mixed $value): object|null
    {
        if ($this->dtoClass !== null) {
            $results = $this->queryBuilder
                ->where($property, "=", $value)
                ->first($this->dtoClass);
            return $this->sanitizeDto($results);
        }
        return $this->queryBuilder
            ->where($property, "=", $value)
            ->first($this->modelClass);
    }

    /**
     * @template T of object
     * @return array<T>|array<Model>
     */
    public function find(int $limit, int $offset): array
    {
        return $this->fetch(
            $this->queryBuilder
                ->select("*")
                ->limit($limit)
                ->offset($offset)
                ->orderBy('created_at', 'ASC')
        );
    }

    public function create(array $data): int|false
    {
        return $this->queryBuilder->insert($data);
    }

    public function update(mixed $id, array $data): int
    {
        return $this->queryBuilder
            ->where($this->getModelPrimaryKey(), "=", $id)
            ->update($data);
    }

    public function delete(mixed $id): int
    {
        return $this->queryBuilder
            ->where($this->getModelPrimaryKey(), "=", $id)
            ->delete();
    }

    /**
     * @param int $page
     * @param int $perPage
     * @param string $baseUrl
     * @return array
     */
    public function paginate(
        int $page,
        int $perPage,
        ?string $column = 'created_at',
        ?string $direction = 'ASC',
        ?string $search = ''
    ): array {
        $offset = ($page - 1) * $perPage;

        // Create base query
        $baseQuery = clone $this->queryBuilder;

        // Apply search if needed
        if ($search && $this->searchableFields) {
            $this->applySearch($baseQuery, $search);
        }

        // Get paginated results
        $dataQuery = clone $baseQuery;
        $items = $this->fetch(
            $dataQuery
                ->select("*")
                ->limit($perPage)
                ->offset($offset)
                ->orderBy($column, $direction)
        );

        // Get total count
        $total = $this->getTotalCount($baseQuery);

        return $this->formatPaginationResult(
            $items,
            $total,
            $page,
            $perPage,
            $column,
            $direction,
            $search
        );
    }

    private function applySearch(QueryBuilder $query, string $search): void
    {
        $searchTerms = array_map(fn ($field) => "$field LIKE :search", $this->searchableFields);
        $query->whereRaw('(' . implode(' OR ', $searchTerms) . ')', [
            'search' => "%$search%"
        ]);
    }

    private function getTotalCount(QueryBuilder $baseQuery): int
    {
        $countQuery = clone $baseQuery;
        return $countQuery
            ->select($this->getModelPrimaryKey())
            ->count();
    }

    private function formatPaginationResult(
        array $items,
        int $total,
        int $page,
        int $perPage,
        string $column,
        string $direction,
        string $search
    ): array {
        $totalPages = (int) ceil($total / $perPage);

        return [
            'data' => $items,
            'meta' => [
                'total' => $total,
                'page' => $page,
                'perPage' => $perPage,
                'totalPages' => $totalPages,
                'links' => $this->getPaginationLinks(
                    $page,
                    $perPage,
                    $totalPages,
                    $column,
                    $direction,
                    $search
                )
            ]
        ];
    }

    protected function getModelPrimaryKey(): string
    {
        return $this->modelClass::getPrimaryKey();
    }
}
