<?php

declare(strict_types=1);

namespace Forge\Core\Database\Migrations;

use Forge\Core\Database\Attributes\Column;
use Forge\Core\Database\Attributes\Index;
use Forge\Core\Database\Attributes\Relationships\BelongsTo;
use Forge\Core\Database\Attributes\Relationships\ManyToMany;
use Forge\Core\Database\Attributes\Table;
use Forge\Core\Database\Connection;
use Forge\Core\Database\QueryBuilder;
use Forge\Core\Database\Schema\FormatterInterface;
use Forge\Core\Helpers\Strings;
use PDOException;
use ReflectionClass;

abstract class Migration
{
    protected array $schema = [];
    protected array $indexes = [];
    protected array $relationships = [];
    protected QueryBuilder $queryBuilder;

    public function __construct(
        protected Connection $pdo,
        protected FormatterInterface $formatter,
    ) {
        $this->queryBuilder = new QueryBuilder($this->pdo);
        $this->formatter = $formatter;
        $this->reflectSchema();
        $this->reflectRelationships();
    }

    private function reflectSchema(): void
    {
        $reflector = new ReflectionClass($this);

        // Get table attributes
        $tableAttributes = $reflector->getAttributes(Table::class);
        if (!empty($tableAttributes)) {
            $table = $tableAttributes[0]->newInstance();
            $this->schema['table'] = $table->name;
        }

        // Get column attributes
        foreach ($reflector->getProperties() as $property) {
            $columnAttributes = $property->getAttributes(Column::class);
            if (!empty($columnAttributes)) {
                $column = $columnAttributes[0]->newInstance();
                $this->schema['columns'][$column->name] = [
                   'type' => $column->type,
                   'primary' => $column->primaryKey,
                   'nullable' => $column->nullable,
                   'unique' => $column->unique,
                   'default' => $column->default
               ];
            }
        }

        // Get index attributes
        foreach ($reflector->getAttributes(Index::class) as $indexAttribute) {
            $index = $indexAttribute->newInstance();
            $this->indexes[] = [
               'name' => $index->name,
               'columns' => $index->columns,
               'unique' => $index->unique,
               'table' => $this->schema['table'],
           ];
        }
    }

    private function reflectRelationships(): void
    {
        $reflector = new ReflectionClass($this);

        foreach ($reflector->getAttributes(BelongsTo::class) as $attr) {
            $relation = $attr->newInstance();
            $this->formatter->addRelationship('belongsTo', [
                'foreignKey' => $relation->foreignKey ?: Strings::toSnakeCase($relation->related).'_id',
                'relatedTable' => Strings::toPlural(Strings::toSnakeCase($relation->related)),
                'onDelete' => $relation->onDelete
            ]);
        }

        foreach ($reflector->getAttributes(ManyToMany::class) as $attr) {
            $relation = $attr->newInstance();
            $this->formatter->addRelationship('manyToMany', [
                'joinTable' => $relation->joinTable,
                'foreignKey' => $relation->foreignKey,
                'relatedKey' => $relation->relatedKey,
                'sourceTable' => $this->schema['table'],
                'relatedTable' => Strings::toPlural(Strings::toSnakeCase($relation->related))
            ]);
        }
    }

    public function up(): void
    {
        if (empty($this->schema)) {
            return;
        }
        $sql = $this->queryBuilder
            ->setTable($this->schema['table'])
            ->createTableFromAttributes(
                $this->schema['table'],
                $this->schema['columns'],
                $this->indexes
            );
        $sql .= "\n" . $this->formatter->formatRelationships($this->schema['table']);

        $this->queryBuilder->execute($sql);
    }
    public function down(): void
    {
        if (empty($this->schema)) {
            return;
        }

        $sql = $this->queryBuilder
           ->setTable($this->schema['table'])
           ->dropTable($this->schema['table']);

        $this->queryBuilder->execute($sql);
    }

    protected function execute(string $sql): void
    {
        try {
            $this->pdo->exec($sql);
        } catch (PDOException $e) {
            throw new MigrationException(
                "Migration failed: " . $e->getMessage(),
                $sql
            );
        }
    }
}
