<?php

declare(strict_types=1);

namespace Forge\Core\Database\Enums;

enum ColumnType: string
{
    case UUID = 'UUID';
    case STRING = 'STRING';
    case TEXT = 'TEXT';
    case INTEGER = 'INTEGER';
    case TIMESTAMP = 'TIMESTAMP';
    case ENUM = 'ENUM';
    case JSON = 'JSON';

    public function withLength(int $length): string
    {
        return match ($this) {
            self::STRING => "VARCHAR($length)",
            default => $this->value,
        };
    }

    public function defaultValue(): mixed
    {
        return match ($this) {
            self::INTEGER => 0,
            self::STRING => '',
            self::TIMESTAMP => 'CURRENT_TIMESTAMP',
            default => null,
        };
    }
}
