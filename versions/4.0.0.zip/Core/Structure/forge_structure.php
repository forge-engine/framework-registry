<?php

return [
  'app' => [
    'controllers' => 'app/Controllers',
    'services' => 'app/Services',
    'migrations' => 'app/Database/Migrations',
    'views' => 'app/resources/views',
    'components' => 'app/resources/components',
    'commands' => 'app/Commands',
    'events' => 'app/Events',
    'tests' => 'app/tests',
    'models' => 'app/Models',
    'dto' => 'app/Dto',
    'seeders' => 'app/Database/Seeders',
    'middlewares' => 'app/Middlewares',
  ],
  'modules' => [
    'controllers' => 'src/Controllers',
    'services' => 'src/Services',
    'migrations' => 'src/Database/Migrations',
    'views' => 'src/Resources/views',
    'components' => 'src/Resources/components',
    'commands' => 'src/Commands',
    'events' => 'src/Events',
    'tests' => 'src/tests',
    'models' => 'src/Models',
    'dto' => 'src/Dto',
    'seeders' => 'src/Database/Seeders',
    'middlewares' => 'src/Middlewares',
  ],
];
