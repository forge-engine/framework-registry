<?php

declare(strict_types=1);

namespace Forge\Core\Http;

use App\Modules\ForgeDebugbar\Collectors\RequestCollector;
use Forge\Core\Routing\Router;
use Forge\Core\DI\Container;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;

final class Kernel
{
    public function __construct(
        private Router $router,
        private Container $container
    ) {
    }

    public function handler(Request $request): Response
    {
        HookManager::triggerHook(LifecycleHookName::BEFORE_REQUEST, $request);
        RequestCollector::collect($request);

        $content = null;
        try {
            $content = $this->router->dispatch($request);
        } catch (\Throwable $exception) {
            $response = new Response('Error: ' . $exception->getMessage(), 500);
            HookManager::triggerHook(LifecycleHookName::AFTER_REQUEST, $request, $response);
            throw $exception;
        }

        if ($content instanceof Response) {
            HookManager::triggerHook(LifecycleHookName::AFTER_REQUEST, $request, $content);
            return $content;
        }

        $response = new Response((string) $content);
        HookManager::triggerHook(LifecycleHookName::AFTER_REQUEST, $request, $response);
        return $response;
    }
}
