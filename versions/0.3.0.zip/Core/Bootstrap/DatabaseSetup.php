<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\Core\Config\Environment;
use Forge\Core\Database\Connection;
use Forge\Core\Database\DatabaseConfig;
use Forge\Core\Database\QueryBuilder;
use Forge\Core\Debug\Metrics;
use Forge\Core\DI\Container;
use PDO;

final class DatabaseSetup
{
    public static function setup(Container $container, Environment $env): void
    {
        Metrics::start('db_resolution');
        self::ensureDatabaseDirectoryExists($env);
        Metrics::start('db_connection_resolution');
        self::initConnection($container, $env);
        Metrics::stop('db_connection_resolution');
        self::bindQueryBuilder($container);
        Metrics::stop('db_resolution');
    }

    private static function ensureDatabaseDirectoryExists(Environment $env): void
    {
        $dbPath = BASE_PATH . $env->get('SQLITE_PATH', '/storage/database');

        if (!is_dir($dbPath)) {
            mkdir($dbPath, 0755, true);
        }

        $sqliteFile = $dbPath . $env->get('SQLITE_DB', '/database.sqlite');

        if (!file_exists($sqliteFile)) {
            touch($sqliteFile);
        }
    }
    /**
     * @throws \ReflectionException
     */
    private static function initConnection(
        Container $container,
        Environment $env
    ): void {
        $container->singleton(DatabaseConfig::class, function () use ($env) {
            return new DatabaseConfig(
                driver: $env->get("DB_DRIVER", 'sqlite'),
                database: $env->get("DB_DRIVER") === "sqlite"
                ? BASE_PATH . $env->get('SQLITE_PATH', '/storage/database') . $env->get('SQLITE_DB', '/database.sqlite')
                : $env->get("DB_NAME", 'forge'),
                host: $env->get("DB_HOST", 'localhost'),
                username: $env->get("DB_USER", 'root'),
                password: $env->get("DB_PASS", ''),
                port: $env->get("DB_PORT", 3306)
            );
        });

        $container->bind(Connection::class, function () use ($container) {
            $config = $container->get(DatabaseConfig::class);
            return new Connection($config);
        });

        $container->bind(PDO::class, function () use ($container) {
            $connection = $container->get(Connection::class);
            return $connection->getPdo();
        });
    }

    private static function bindQueryBuilder(Container $container): void
    {
        $container->bind(QueryBuilder::class, function () use ($container) {
            return new QueryBuilder($container->get(Connection::class));
        });
    }
}
