<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Module\Attributes\CLICommand;
use Forge\Core\Services\ModuleAssetManager;

#[CLICommand(name: 'serve', description: 'Start the PHP Development Server')]
class ServeCommand extends Command
{
    public function __construct(private ModuleAssetManager $moduleAssetManager)
    {
    }
    public function execute(array $args): int
    {
        $host = $this->argument("host", $args) ?? "localhost";
        $port = $this->argument("port", $args) ?? "8000";
        $publicDir = BASE_PATH . "/public";

        if (PHP_SAPI === 'cli') {
            \Forge\Core\Bootstrap\ModuleSetup::compileHooks();
        }

        $this->linkAssets();
        $this->info("Server running on http://$host:$port");
        passthru("php -S $host:$port -t $publicDir");
        return 0;
    }

    private function linkAssets(): void
    {
        $this->moduleAssetManager::initialize();
        $this->info("Assets cache regenerated");
    }
}
