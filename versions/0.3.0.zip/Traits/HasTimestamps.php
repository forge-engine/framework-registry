<?php

declare(strict_types=1);

namespace Forge\Traits;

use Forge\Core\Database\Attributes\Column;

trait Hastimestamps
{
    #[Column("timestamp", nullable: true)]
    public ?string $created_at = null;

    #[Column("timestamp", nullable: true)]
    public ?string $updated_at = null;
}
