<?php

declare(strict_types=1);

use App\Modules\ForgeDatabaseSQL\DB\Attributes\GroupMigration;
use App\Modules\ForgeDatabaseSQL\DB\Migrations\Migration;

#[GroupMigration(name: 'security')]
class CreatePermissionsTable extends Migration
{
    public function up(): void
    {
        $this->queryBuilder->setTable('permissions')
            ->createTable('permissions', [
                'id' => 'INTEGER PRIMARY KEY AUTOINCREMENT',
                'name' => 'VARCHAR(255) UNIQUE NOT NULL',
                'description' => 'TEXT',
            ]);
        $this->execute($this->queryBuilder->getSql());
    }

    public function down(): void
    {
        $this->execute($this->queryBuilder->dropTable('permissions'));
    }
}
