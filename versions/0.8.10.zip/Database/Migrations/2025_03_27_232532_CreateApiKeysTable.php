<?php

declare(strict_types=1);

use App\Modules\ForgeDatabaseSQL\DB\Attributes\GroupMigration;
use App\Modules\ForgeDatabaseSQL\DB\Migrations\Migration;

#[GroupMigration(name: 'security')]
class CreateApiKeysTable extends Migration
{
    public function up(): void
    {
        $this->queryBuilder->setTable('api_keys')
            ->createTable('api_keys', [
                'id' => 'INTEGER PRIMARY KEY AUTOINCREMENT',
                'api_key' => 'VARCHAR(255) UNIQUE NOT NULL',
                'description' => 'TEXT',
                'created_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
                'updated_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
            ]);
        $this->execute($this->queryBuilder->getSql());
    }

    public function down(): void
    {
        $this->execute($this->queryBuilder->dropTable('api_keys'));
    }
}
