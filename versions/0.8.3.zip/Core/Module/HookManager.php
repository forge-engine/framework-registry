<?php

declare(strict_types=1);

namespace Forge\Core\Module;

final class HookManager
{
    private static array $hooks = [];
    private static bool $compiledHooksLoaded = false;

    public static function addHook(LifecycleHookName $hookName, callable|array $callback): void
    {
        $name = $hookName->value;

        if (!isset(self::$hooks[$name])) {
            self::$hooks[$name] = [];
        }

        foreach (self::$hooks[$name] as $registeredCallback) {
            if (is_array($registeredCallback) && is_array($callback) &&
                $registeredCallback[0] === $callback[0] && $registeredCallback[1] === $callback[1]) {
                return;
            } elseif ($registeredCallback === $callback) {
                return;
            }
        }

        self::$hooks[$name][] = $callback;
    }

    public static function triggerHook(LifecycleHookName $hookName, ...$args): void
    {
        if (!self::$compiledHooksLoaded) {
            self::loadCompiledHooks();
            self::$compiledHooksLoaded = true;
        }

        $name = $hookName->value;

        if (isset(self::$hooks[$name])) {
            foreach (self::$hooks[$name] as $callback) {
                if (is_callable($callback)) {
                    call_user_func_array($callback, $args);
                } elseif (is_array($callback) && count($callback) === 2) {
                    call_user_func_array($callback, $args);
                } else {
                    error_log("Invalid callback format: " . print_r($callback, true));
                }
            }
        }
    }

    private static function loadCompiledHooks(): void
    {
        $compiledFile = BASE_PATH . '/storage/framework/cache/compiled_hooks.php';
        if (file_exists($compiledFile)) {
            $compiledHooks = include $compiledFile;

            foreach ($compiledHooks as $hookName => $hooks) {
                foreach ($hooks as $hook) {
                    if ($hook['type'] === 'method') {
                        try {
                            $instance = new $hook['class']();
                            $callback = [$instance, $hook['method']];

                            if (!isset(self::$hooks[$hookName])) {
                                self::$hooks[$hookName] = [];
                            }
                            self::$hooks[$hookName][] = $callback;
                        } catch (\Throwable $e) {
                            error_log("Failed to load compiled hook {$hook['class']}::{$hook['method']}: " . $e->getMessage());
                        }
                    }
                }
            }
        } else {
        }
    }

    public static function debugGetHooks(): array
    {
        return self::$hooks;
    }
}
