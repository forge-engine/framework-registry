<?php

declare(strict_types=1);

namespace Forge\Traits;

use Forge\Core\Database\Attributes\Column;

trait HasMetaData
{
    #[Column("json", nullable: true)]
    public ?array $metadata = null;
}
