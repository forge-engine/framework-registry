<?php

declare(strict_types=1);

use Forge\Core\Config\Environment;
use Forge\Core\DI\Container;
use Forge\Core\Security\CsrfTokenManager;

/**
    * Get the environment instance.
    *
    * @return mixed
    */
    if (!function_exists("env")) {
        function env(string $key, mixed $default = null): mixed
        {
            return Environment::getInstance()->get($key) ?? $default;
        }
    }


/**
 * Escape HTML entities in a string.
 *
 * @param string $value The string to escape.
 * @return string Returns the escaped string.
 */
if (!function_exists("e")) {
    function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
    }
}
/**
 * Output a value without escaping.
 *
 * @param mixed $value The value to output raw.
 * @return string Returns the raw string representation of the value.
 */
if (!function_exists("raw")) {
    function raw(mixed $value): string
    {
        return (string)$value;
    }
}

if (!function_exists("csrf_token")) {
    function csrf_token(): string
    {
        /** @var CsrfTokenManager $mgr */
        $mgr = Container::getInstance()->make(CsrfTokenManager::class);
        return $mgr->getToken('web');
    }
}

if (!function_exists("forgewire")) {
    function forgewire(): string
    {
        return '<script defer src="/forgewire.js" defer></script>';
    }
}

if (!function_exists("csrf_meta")) {
    function csrf_meta(): string
    {
        return '<meta name="csrf-token" content="'.htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8').'">';
    }
}

if (!function_exists("csrf_input")) {
    function csrf_input(): string
    {
        return '<input type="hidden" name="_token" value="'.htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8').'">';
    }
}

if (!function_exists('forgewire_is_available')) {
    function forgewire_is_available(): bool
    {
        return class_exists(\App\Modules\ForgeWire\Support\Renderer::class)
            && class_exists(\App\Modules\ForgeWire\Core\WireComponent::class);
    }
}

/**
 * Render a ForgeWire component.
 *
 * Call forms:
 *  - wire(ProductsTable::class)
 *  - wire(ProductsTable::class, ['perPage' => 5])
 *  - wire(ProductsTable::class, 'products-1')
 *  - wire(ProductsTable::class, 'products-1', ['perPage' => 5])
 */
if (!function_exists('wire')) {
    function wire(string $componentClass, mixed $a = null, mixed $b = null): string
    {
        if (class_exists(App\Modules\ForgeWire\ForgeWireModule::class)) {
            [$id, $props] = (static function ($a, $b) {
                if (is_array($a)) {
                    return [null, $a];
                }
                if (is_string($a)) {
                    return [is_array($b) ? $a : $a, is_array($b) ? $b : []];
                }
                if (is_array($b)) {
                    return [null, $b];
                }
                return [null, []];
            })($a, $b);

            $id = $id ?? ('fw-'.bin2hex(random_bytes(6)));

            $container = \Forge\Core\DI\Container::getInstance();
            $instance  = $container->make($componentClass);

            (static function (object $instance, \Forge\Core\DI\Container $c): void {
                static $serviceMap = [];
                $cls = $instance::class;
                if (!isset($serviceMap[$cls])) {
                    $map = [];
                    $ref = new \ReflectionClass($instance);
                    foreach ($ref->getProperties() as $prop) {
                        foreach ($prop->getAttributes() as $attr) {
                            if ($attr->getName() === 'App\\Modules\\ForgeWire\\Attributes\\Service') {
                                $args  = $attr->getArguments();
                                $class = $args['class'] ?? ($args[0] ?? $prop->getType()?->getName());
                                if ($class) {
                                    $map[$prop->getName()] = $class;
                                }
                            }
                        }
                    }
                    $serviceMap[$cls] = $map;
                }
                if ($serviceMap[$cls]) {
                    $ref = new \ReflectionClass($instance);
                    foreach ($serviceMap[$cls] as $propName => $svcClass) {
                        $p = $ref->getProperty($propName);
                        $p->setAccessible(true);
                        $p->setValue($instance, $c->make($svcClass));
                    }
                }
            })($instance, $container);

            if (method_exists($instance, 'mount')) {
                $instance->mount($props ?? []);
            }

            /** @var \App\Modules\ForgeWire\Support\Renderer $renderer */
            $renderer = $container->make(\App\Modules\ForgeWire\Support\Renderer::class);
            $html = $renderer->render($instance, $id, $componentClass);

            $session  = $container->make(\Forge\Core\Session\SessionInterface::class);
            $hydrator = $container->make(\App\Modules\ForgeWire\Core\Hydrator::class);
            $sessionKey = "forgewire:{$id}";
            $hydrator->dehydrate($instance, $session, $sessionKey);
            // $checksum = $container->make(\App\Modules\ForgeWire\Support\Checksum::class)->sign($sessionKey, $session);

            return $html;
        }
    }
}


/**
 * Alias: shorter name, same semantics
 *   w(ProductsTable::class, ['perPage' => 5])
 *   w(ProductsTable::class, 'products-1')
 */
if (!function_exists('w') && function_exists('wire')) {
    function w(string $componentClass, mixed $props = null, mixed $componentId = null): string
    {
        return wire($componentClass, $props, $componentId);
    }
}

/**
 * Name-based resolver (optional):
 *   wire_name('products-table', ['perPage'=>5])
 * => App\Components\ProductsTable
 */
if (!function_exists('wire_name') && function_exists('wire')) {
    function wire_name(string $name, mixed $props = null, mixed $componentId = null): string
    {
        $pascal = str_replace(' ', '', ucwords(str_replace(['-', '_', '.'], ' ', $name)));
        $class  = "App\\Components\\{$pascal}";
        return wire($class, $props, $componentId);
    }
}

if (!function_exists('tap')) {
    function tap(mixed $value, callable $cb): mixed
    {
        $cb($value);
        return $value;
    }
}
