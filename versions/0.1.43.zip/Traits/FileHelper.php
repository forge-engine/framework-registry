<?php

declare(strict_types=1);

namespace Forge\Traits;

trait FileHelper
{
    protected function ensureDirectoryExists(string $path): void
    {
        if (!file_exists($path)) {
            mkdir($path, 0755, true);
        }
    }
}
