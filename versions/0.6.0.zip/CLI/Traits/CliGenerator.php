<?php
declare(strict_types=1);

namespace Forge\CLI\Traits;

trait CliGenerator
{
    use OutputHelper;
    use Wizard;

    protected function generateFromStub(
        string $stub,
        string $targetPath,
        array  $tokens,
        bool   $force = false
    ): void
    {
        if (is_file($targetPath) && !$force) {
            $this->error("File exists: $targetPath  (--force to overwrite)");
            exit(1);
        }

        $dir = dirname($targetPath);
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $content = file_get_contents($this->stubPath($stub));
        $content = strtr($content, $tokens);

        file_put_contents($targetPath, $content);
        $this->success("Created: $targetPath");
    }

    private function stubPath(string $stub): string
    {
        return BASE_PATH . "/engine/resources/stubs/$stub.stub";
    }

    private function controllerPath(): string
    {
        return $this->resolve('controller')['path'];
    }

    private function resolve(string $type): array
    {
        $map = [
            'controller' => ['Controllers', 'Controller.php'],
            'middleware' => ['Middlewares', 'Middleware.php'],
            'event' => ['Events', 'Event.php'],
            'migration' => ['Database/Migrations', 'Table.php'],
            'seeder' => ['Database/Seeders', 'Seeder.php'],
            'model' => ['Models', 'Model.php'],
            'view' => ['resources/views/pages', ''],
            'command' => ['Commands', 'Command.php'],
        ];

        if (!isset($map[$type])) {
            throw new \InvalidArgumentException("Unknown type: $type");
        }

        [$subdir, $suffix] = $map[$type];
        $subPath = $this->normalizePath($this->path ?? '');

        $baseDir = $this->type === 'app'
            ? BASE_PATH . "/app/$subdir"
            : BASE_PATH . "/modules/{$this->module}/src/$subdir";

        if ($subPath !== '') $baseDir .= '/' . $subPath;

        if ($type === 'migration' || $type === 'seeder') {
            $file = date("Y_m_d_His") . "_" . $this->toPascalCase($this->name) . "Table.php";
        } elseif ($type === 'view') {
            $file = "{$this->toKebabCase($this->name)}/index.php";
        } else {
            $file = "{$this->name}{$suffix}";
        }

        $baseNamespace = $this->type === 'app'
            ? 'App'
            : "Modules\\{$this->module}";
        $namespace = $baseNamespace . '\\' . str_replace('/', '\\', $subdir);
        if ($subPath !== '') $namespace .= '\\' . str_replace('/', '\\', $subPath);

        return [
            'path' => "$baseDir/$file",
            'namespace' => $namespace,
        ];
    }

    private function normalizePath(?string $path): string
    {
        $path = trim((string)$path);
        if ($path === '') return '';
        return trim(str_replace(['\\', '//'], '/', $path), '/');
    }

    private function controllerNamespace(): string
    {
        return $this->resolve('controller')['namespace'];
    }

    private function middlewarePath(): string
    {
        return $this->resolve('middleware')['path'];
    }

    private function middlewareNamespace(): string
    {
        return $this->resolve('middleware')['namespace'];
    }

    private function eventPath(): string
    {
        return $this->resolve('event')['path'];
    }

    private function commandPath(): string
    {
        return $this->resolve('command')['path'];
    }

    private function eventNamespace(): string
    {
        return $this->resolve('event')['namespace'];
    }

    private function modelNamespace(): string
    {
        return $this->resolve('model')['namespace'];
    }

    private function migrationPath(): string
    {
        return $this->resolve('migration')['path'];
    }

    private function seederPath(): string
    {
        return $this->resolve('seeder')['path'];
    }

    private function modelPath(): string
    {
        return $this->resolve('model')['path'];
    }

    private function viewPath(): string
    {
        return $this->resolve('view')['path'];
    }
}