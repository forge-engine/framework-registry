<?php

namespace Forge\Core\Helpers;

use Forge\Http\Request;
use Forge\Http\Response;

class Redirect
{
    /**
     * Create a redirect response
     *
     * @param string $url Uri to redirect to
     * @param int $status Http status code for redirect defautl to 302 found
     * @param array<string, string> $headers Additional headers.
     * @return Response
     */
    public static function to(string $uri, int $status = 302, array $headers = []): Response
    {

        return (new Response())->setHeaders(array_merge($headers, ['Location' => $uri]))->setStatusCode($status)->setContent('')->send();
    }

    /**
     * Create a redirect response to the back url referer header
     *
     * @param array<string, string> $headers additional headers
     * @return Response
     */
    public static function back(Request $request, array $headers = []): Response
    {
        $referer = $request->getHeaderLine('Referer');
        $uri = $referer ?: '/';

        $response = (new Response())->setStatusCode(302);
        $response->setHeader('Location', $uri);
        if (!empty($headers)) {
            $response->setHeaders($headers);
        }
        return $response->send();
    }
}