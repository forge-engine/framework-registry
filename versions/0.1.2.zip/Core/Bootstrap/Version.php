<?php

namespace Forge\Core\Bootstrap;

define('FRAMEWORK_VERSION', '0.1.0');