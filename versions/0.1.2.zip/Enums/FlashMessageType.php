<?php

namespace Forge\Enums;

/**
 * Enum with the list of flash messages type
 */
enum FlashMessageType: string
{
    case SUCCESS = 'success';
    case ERROR = 'error';
    case WARNING = 'warning';
    case INFO = 'info';
}