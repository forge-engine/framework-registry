<?php

declare(strict_types=1);

use Forge\Core\Cache\CacheManager;
use Forge\Core\Config\Environment;
use Forge\Core\DI\Container;
use Forge\Core\Helpers\Debuger;
use Forge\Core\Services\TokenManager;
use Forge\Core\View\Component;
use Forge\Core\View\View;
use Forge\Core\Config\Config;
use Forge\Core\Routing\Router;

use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;

if (!function_exists("env")) {
    /**
     * Get environment value by key.
     *
     * @param string $key
     * @param mixed|null $default
     * @return mixed
     */
    function env(string $key, mixed $default = null): mixed
    {
        return Environment::getInstance()->get($key) ?? $default;
    }
}


if (!function_exists("cache")) {
    /**
     * Get cache data by key.
     *
     * @param string $key
     * @param mixed|null $value
     * @param int|null $ttl
     * @return mixed
     * @throws MissingServiceException
     * @throws ReflectionException
     * @throws ResolveParameterException
     */
    function cache(string $key, mixed $value = null, ?int $ttl = null): mixed
    {
        $cache = Container::getInstance()->make(
            CacheManager::class,
        );

        if (func_num_args() === 1) {
            return $cache->get($key);
        }

        $cache->set($key, $value, $ttl);
        return $value;
    }
}

if (!function_exists("config")) {
    /**
     * Get the config value by key.
     * @param string $key
     * @param mixed|null $default
     * @return mixed
     * @throws MissingServiceException
     */
    function config(string $key, mixed $default = null): mixed
    {
        /** @var Config $config */
        $config = Container::getInstance()->make(Config::class);
        return $config->get($key, $default);
    }
}

if (!function_exists("request_host")) {
    /**
     * Get the current request host (domain + port if available).
     *
     */
    function request_host(): string
    {
        $host = $_SERVER["HTTP_HOST"] ?? "localhost";
        return strtolower(trim($host));
    }
}

if (!function_exists("get_data")) {
    /**
     * Get an item from an array or object using dot notation.
     *
     * @param mixed $target The array or object to retrieve from.
     * @param string $key The key, in dot notation (e.g., 'user.address.street').
     * @param mixed $default The default value to return if the key is not found.
     * @return mixed
     */
    function data_get(mixed $target, string $key, mixed $default = null): mixed
    {
        if (empty($key)) {
            return $target;
        }

        $keys = explode(".", $key);
        $current = $target;
        foreach ($keys as $segment) {
            if (is_array($current) && array_key_exists($segment, $current)) {
                $current = $current[$segment];
            } elseif (
                is_object($current) &&
                property_exists($current, $segment)
            ) {
                $current = $current->$segment;
            } else {
                return $default;
            }
        }

        return $current;
    }
}


if (!function_exists("e")) {
    /**
     * Escape HTML entities in a string.
     *
     * @param string $value The string to escape.
     * @return string Returns the escaped string.
     */
    function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
    }
}

if (!function_exists("raw")) {
    /**
     * Output a value without escaping.
     *
     * @param mixed $value The value to output raw.
     * @return string Returns the raw string representation of the value.
     */
    function raw(mixed $value): string
    {
        return (string) $value;
    }
}

if (!function_exists("csrf_token")) {
    /**
     * @throws MissingServiceException
     */
    function csrf_token(): string
    {
        /** @var TokenManager $mgr */
        $mgr = Container::getInstance()->make(TokenManager::class);
        return $mgr->getToken("web");
    }
}

if (!function_exists("csrf_meta")) {

    function csrf_meta(): string
    {
        return '<meta name="csrf-token" content="' .
            htmlspecialchars(csrf_token(), ENT_QUOTES, "UTF-8") .
            '">';
    }
}

if (!function_exists("window_csrf_token")) {
    function window_csrf_token(): string
    {
        return "<script>
        window.csrfToken = document.querySelector('meta[name='csrf-token']')?.getAttribute('content') || '';
        </script>";
    }
}

if (!function_exists("csrf_input")) {
    function csrf_input(): string
    {
        return '<input type="hidden" name="_token" value="' .
            htmlspecialchars(csrf_token(), ENT_QUOTES, "UTF-8") .
            '">';
    }
}

if (!function_exists("tap")) {
    function tap(mixed $value, callable $cb): mixed
    {
        $cb($value);
        return $value;
    }
}


if (!function_exists("component")) {
    function component(string $name, array|object $props = [], ?bool $fromModule = false): string
    {
        $module = null;
        if (str_contains($name, ":")) {
            [$module, $name] = explode(":", $name, 2);
        }

        return View::viewComponent($name, $props, $module);
    }
}

if (!function_exists("layout")) {
    /**
     * Helper to load a layout.
     *
     * @param string $name Layout name
     * @param bool $fromModule Load layout from a module if true
     * @param string|null $moduleName Specific module name to load layout from
     */
    function layout(string $name, bool $fromModule = false, ?string $moduleName = null): void
    {
        View::layout(name: $name, loadFromModule: $fromModule, moduleName: $moduleName);
    }
}

if (!function_exists("section")) {
    /**
     * Helper to render a section.
     *
     * @param string $name Section name
     * @return string
     */
    function section(string $name): string
    {
        return View::section(name: $name);
    }
}

if (!function_exists('form_open')) {
    /**
     * Open a form with CSRF protection and method spoofing support.
     */
    function form_open(string $action, string $method = 'POST', array $attrs = []): string
    {
        $method = strtoupper($method);
        $realMethod = in_array($method, ['GET', 'POST']) ? $method : 'POST';

        $attrString = '';
        foreach ($attrs as $key => $value) {
            $attrString .= sprintf(' %s="%s"', htmlspecialchars($key), htmlspecialchars($value));
        }

        $html = sprintf('<form action="%s" method="%s"%s>', htmlspecialchars($action), $realMethod, $attrString);

        if (function_exists('csrf_input')) {
            $html .= csrf_input();
        }

        if ($realMethod === 'POST' && $method !== 'POST') {
            $html .= sprintf('<input type="hidden" name="_method" value="%s">', htmlspecialchars($method));
        }

        return $html;
    }
}

if (!function_exists('form_close')) {
    /**
     * Close the form tag.
     */
    function form_close(): string
    {
        return '</form>';
    }
}

if (!function_exists('dd')) {
    function dd(...$vars): void
    {
        Debuger::dumpAndExit($vars);
    }
}

if (!function_exists('fw_id')) {
    function fw_id(string $id): string
    {
        $idAttr = 'fw:id="' . htmlspecialchars($id) . '"';
        $checksumAttr = '';

        $modulePath = BASE_PATH . '/modules/ForgeWire/src/ForgeWireModule.php';
        if (!is_file($modulePath) || !class_exists('\App\Modules\ForgeWire\ForgeWireModule')) {
            return $idAttr;
        }

        try {
            $router = Router::getInstance();
            $route = $router->getCurrentRoute();
            if ($route && isset($route['controller'])) {
                $container = Container::getInstance();
                $serviceClass = '\App\Modules\ForgeWire\Services\ComponentIdentityService';
                $servicePath = BASE_PATH . '/modules/ForgeWire/src/Services/ComponentIdentityService.php';

                if (is_file($servicePath) && class_exists($serviceClass)) {
                    $routePath = $route['path'] ?? ($route['pattern'] ?? '');
                    $isWire = ($route['controller'] === \App\Modules\ForgeWire\Controllers\WireController::class || $routePath === '/__wire');

                    if (!$isWire) {
                        /** @var \App\Modules\ForgeWire\Services\ComponentIdentityService $identityService */
                        $identityService = $container->make($serviceClass);
                        $checksumAttr = $identityService->getFingerprint($id, $route['controller'], $route['method'] ?? 'index');
                    }
                }
            }
        } catch (\Throwable $e) {
        }
        return $idAttr . $checksumAttr;
    }
}
