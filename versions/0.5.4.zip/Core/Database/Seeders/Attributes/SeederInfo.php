<?php

declare(strict_types=1);

namespace Forge\Core\Database\Seeders\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
final class SeederInfo
{
    public function __construct(
        public ?string $description = null,
        public ?string $author = null
    ) {}
}