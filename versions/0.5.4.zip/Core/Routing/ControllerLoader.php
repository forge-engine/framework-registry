<?php

declare(strict_types=1);
namespace Forge\Core\Routing;
use FilesystemIterator;
use Forge\Core\DI\Container;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final readonly class ControllerLoader
{
    public function __construct(
        private Container $container,
        private array     $controllerDirs = []
    ) {
    }

    /** Auto-register controllers from directory (recursively)
     * @throws \ReflectionException
     */
    public function registerControllers(): array
    {
        $registeredControllers = [];
        foreach ($this->controllerDirs as $dir) {
            if (is_dir($dir)) {
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
                );
                foreach ($iterator as $file) {
                    if ($file->isFile() && $file->getExtension() === 'php' && str_contains($file->getFilename(), 'Controller')) {
                        $class = $this->fileToClass($file->getPathname(), $dir);
                        if ($class) {
                            $this->container->register($class);
                            $registeredControllers[] = $class;
                        }
                    }
                }
            }
        }
        return $registeredControllers;
    }

    private function fileToClass(string $file, string $baseDir): ?string
    {
        $relativePath = str_replace($baseDir, '', $file);
        $class = str_replace(['/', '.php'], ['\\', ''], trim($relativePath, '/'));
        if (str_starts_with($baseDir, BASE_PATH . "/app/Controllers")) {
            return "App\\Controllers\\$class";
        }
        if (preg_match('#modules/([^/]+)/src/Controllers#', $baseDir, $matches)) {
            return "App\\Modules\\{$matches[1]}\\Controllers\\$class";
        }
        throw new \RuntimeException("Invalid controller path: $file");
    }
}
