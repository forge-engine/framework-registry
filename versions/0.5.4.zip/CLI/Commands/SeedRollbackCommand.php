<?php


declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Seeders\SeederManager;
use Forge\Core\Module\Attributes\CLICommand;

#[CLICommand(name: 'seed:rollback', description: 'Rollback database seeders')]
class SeedRollbackCommand extends Command
{
    public function __construct(private readonly SeederManager $manager)
    {
    }

    /**
     * @throws \Throwable
     */
    public function execute(array $args): int
    {
        $steps = 1;
        foreach ($args as $arg) {
            if (preg_match('/--steps=(\d+)/', $arg, $m)) {
                $steps = (int)$m[1];
            }
        }

        $this->manager->rollback($steps);
        $this->success("Rolled back {$steps} batch(es) successfully");
        return 0;
    }
}