<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Migrator;
use Forge\Core\Module\Attributes\CLICommand;
use Throwable;

#[CLICommand(name: 'migrate:rollback', description: 'Rollback Database migrations')]
class MigrateRollBackCommand extends Command
{
    public function __construct(private readonly Migrator $migrator)
    {
    }

    /**
     * @throws Throwable
     */
    public function execute(array $args): int
    {
        $steps = 1;
        $preview = false;
        $type = null;
        $module = null;
        $group = null;
        $batch = null;

        foreach ($args as $arg) {
            if (is_numeric($arg) && !str_starts_with($arg, '-')) {
                $steps = (int) $arg;
            } elseif ($arg === '--preview') {
                $preview = true;
            }
        }

        $type = $this->getArgValue($args, '--type');
        $module = $this->getArgValue($args, '--module');
        $group = $this->getArgValue($args, '--group');
        $batchValue = $this->getArgValue($args, '--batch');

        if ($batchValue !== null) {
            $batch = (int) $batchValue;
            $steps = 1;
        }

        $migratorType = match (strtolower($type ?? '')) {
            'app' => 'app',
            'module' => 'module',
            'engine' => 'core',
            default => 'all',
        };

        $infoMessage = "Processing rollback";
        if ($migratorType) $infoMessage .= " (Type: {$migratorType})";
        if ($module) $infoMessage .= " (Module: {$module})";
        if ($group) $infoMessage .= " (Group: {$group})";

        if ($batch !== null) {
            $infoMessage .= " targeting batch {$batch}";
        } else {
            $infoMessage .= " for {$steps} batch(es)";
        }

        $this->info($infoMessage . "...");


        if ($preview) {
            $migrations = $this->migrator->getRanMigrations($steps, $migratorType, $module, $group, $batch);

            if (empty($migrations)) {
                $this->info('No migrations to rollback matching the criteria.');
            } else {
                $this->info('The following migrations would be rolled back:');
                foreach ($migrations as $migration) {
                    $this->info("- {$migration}");
                }
            }
            return 0;
        }

        $this->migrator->rollback($steps, $migratorType, $module, $group, $batch);

        $this->success("Rollback completed successfully.");
        return 0;
    }

    /**
     * Helper to extract the value of a key from the arguments array (e.g., --type=app).
     */
    private function getArgValue(array $args, string $key): ?string
    {
        foreach ($args as $arg) {
            if (str_starts_with($arg, $key . '=')) {
                // Return the value after the '='
                return explode('=', $arg)[1] ?? null;
            }
        }
        return null;
    }
}
