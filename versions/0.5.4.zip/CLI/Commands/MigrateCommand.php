<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Command;
use Forge\Core\Database\Migrator;
use Forge\Core\Module\Attributes\CLICommand;
use Throwable;

#[CLICommand(name: 'migrate', description: 'Run Database migrations')]
class MigrateCommand extends Command
{
    public function __construct(private readonly Migrator $migrator) {}

    /**
     * @throws Throwable
     */
    public function execute(array $args): int
    {
        $type = $this->getArgValue($args, '--type') ?? 'app';
        $module = $this->getArgValue($args, '--module');
        $group = $this->getArgValue($args, '--group');
        $preview = in_array('--preview', $args);

        $migratorScope = match (strtolower($type)) {
            'app' => 'app',
            'module' => 'module',
            'engine' => 'core',
            default => 'all',
        };

        $infoMessage = "Processing migrations for scope '{$migratorScope}'";
        if ($module) {
            $infoMessage .= " on module '{$module}'";
        }
        if ($group) {
            $infoMessage .= " in group '{$group}'";
        }

        $this->info($infoMessage . "...");

        if ($preview) {
            $migrations = $this->migrator->previewRun($migratorScope, $module, $group);

            if (empty($migrations)) {
                $this->info('No migrations are currently PENDING matching the specified criteria.');
            } else {
                $this->info('The following migrations are PENDING and would be run:');
                foreach ($migrations as $migrationPath) {
                    $this->info("- " . basename($migrationPath));
                }
            }
            return 0;
        }

        $this->migrator->run($migratorScope, $module, $group);

        $this->success("Migrations completed successfully");
        return 0;
    }

    private function getArgValue(array $args, string $key): ?string
    {
        foreach ($args as $arg) {
            if (str_starts_with($arg, $key . '=')) {
                return explode('=', $arg)[1] ?? null;
            }
        }
        return null;
    }
}
