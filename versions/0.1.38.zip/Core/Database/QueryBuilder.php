<?php

declare(strict_types=1);

namespace Forge\Core\Database;

use DateTimeInterface;
use Forge\Core\DI\Attributes\Service;
use PDO;
use PDOStatement;
use RuntimeException;

#[Service(singleton: false)]
final class QueryBuilder
{
    private string $table;
    private array $select = [];
    private array $where = [];
    private array $params = [];
    private ?string $orderBy = null;
    private ?int $limit = null;
    private array $joins = [];
    private array $groupBy = [];
    private ?string $having = null;
    private ?int $offset = null;
    private bool $inTransaction = false;
    private ?string $createTableSql = null;
    private ?string $dropTableSql = null;
    private int $paramCounter = 0;
    private bool $lockForUpdate = false;

    public function __construct(private Connection $pdo)
    {
        $this->table = "";
    }

    public function lockForUpdate(): self
    {
        $this->lockForUpdate = true;
        return $this;
    }

    public function getConnection(): Connection
    {
        return $this->pdo;
    }

    public function setTable(string $table): self
    {
        $this->table = $table;
        return $this;
    }

    public function select(string ...$columns): self
    {
        $this->select = $columns;
        return $this;
    }

    public function where(string $column, string $operator, mixed $value): self
    {
        $paramName = "param" . $this->paramCounter++;
        $placeholder = ":" . $paramName;
        $this->where[] = "$column $operator $placeholder";
        $this->params[$placeholder] = $value;
        return $this;
    }

    public function whereRaw(string $sql, array $params = []): self
    {
        $this->where[] = $sql;
        $this->params = array_merge($this->params, $params);
        return $this;
    }

    /**
     * Add a where IS NULL clause to the query
     */
    public function whereNull(string $column): self
    {
        $this->where[] = "$column IS NULL";
        return $this;
    }

    /**
     * Add a where IS NOT NULL clause to the query
     */
    public function whereNotNull(string $column): self
    {
        $this->where[] = "$column IS NOT NULL";
        return $this;
    }

    public function orderBy(string $column, string $direction = "ASC"): self
    {
        $this->orderBy = "$column $direction";
        return $this;
    }

    public function limit(int $count): self
    {
        $this->limit = $count;
        return $this;
    }

    public function offset(int $count): self
    {
        $this->offset = $count;
        return $this;
    }

    public function createTableFromAttributes(string $table, array $columns, array $indexes = []): string
    {
        $columnDefinitions = [];
        foreach ($columns as $name => $attributes) {
            $columnDefinitions[] = $this->buildColumnDefinition($name, $attributes);
        }

        $this->createTableSql = "CREATE TABLE $table (\n" .
            implode(",\n", $columnDefinitions) .
            "\n)";

        foreach ($indexes as $index) {
            $this->createTableSql .= ";\n" . $this->buildIndexDefinition($index);
        }

        return $this->createTableSql;
    }

    private function buildColumnDefinition(string $name, array $attributes): string
    {
        $definition = [
            $name,
            $attributes['type'],
            $attributes['primary'] ? 'PRIMARY KEY' : '',
            $attributes['nullable'] ? 'NULL' : 'NOT NULL',
            $attributes['unique'] ? 'UNIQUE' : '',
        ];

        if (isset($attributes['default'])) {
            $definition[] = 'DEFAULT ' . $this->formatDefault($attributes['default']);
        }

        return implode(' ', array_filter($definition));
    }

    private function buildIndexDefinition(array $index): string
    {
        return sprintf(
            'CREATE %sINDEX %s ON %s (%s)',
            $index['unique'] ? 'UNIQUE ' : '',
            $index['name'],
            $index['table'],
            implode(', ', $index['columns'])
        );
    }

    private function formatDefault(mixed $value): string
    {
        if (is_string($value)) {
            return "'$value'";
        }
        if (is_bool($value)) {
            return $value ? 'TRUE' : 'FALSE';
        }
        if ($value instanceof DateTimeInterface) {
            return "'" . $value->format('Y-m-d H:i:s') . "'";
        }
        return (string)$value;
    }

    /**
     * @return array<string, mixed>
     */
    public function get(): array
    {
        $stmt = $this->prepareStatement();
        $stmt->execute($this->params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getRaw(): array
    {
        $stmt = $this->prepareStatement();
        $stmt->execute($this->params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function insert(array $data): int
    {
        $columns = implode(", ", array_keys($data));
        $placeholders = ":" . implode(", :", array_keys($data));
        $sql = "INSERT INTO $this->table ($columns) VALUES ($placeholders)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($data);
        return (int) $this->pdo->getPdo()->lastInsertId();
    }

    public function update(array $data): int
    {
        $set = [];
        foreach ($data as $column => $value) {
            $placeholder = ":" . $column;
            $set[] = "$column = $placeholder";
            $this->params[$placeholder] = $value;
        }
        $sql = "UPDATE $this->table SET " . implode(", ", $set);

        if (!empty($this->where)) {
            $sql .= " WHERE " . implode(" AND ", $this->where);
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($this->params);
        return $stmt->rowCount();
    }

    public function delete(): int
    {
        $sql = "DELETE FROM $this->table";
        if (!empty($this->where)) {
            $sql .= " WHERE " . implode(" AND ", $this->where);
        }
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($this->params);
        return $stmt->rowCount();
    }

    /**
     * @return array<string, mixed>|null
     */
    public function first(): ?array
    {
        $stmt = $this->prepareStatement();
        $stmt->execute($this->params);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function find(int $id): ?array
    {
        $primaryKey = $this->getPrimaryKey();
        if ($primaryKey === null) {
            throw new RuntimeException(
                "Primary key not found for table: {$this->table}"
            );
        }
        $this->where($primaryKey, "=", $id);
        return $this->first();
    }

    /**
     * Join another table
     */
    public function join(
        string $table,
        string $first,
        string $operator,
        string $second,
        string $type = "INNER"
    ): self {
        $this->joins[] = "$type JOIN $table ON $first $operator $second";
        return $this;
    }

    /**
     * Left join another table
     */
    public function leftJoin(
        string $table,
        string $first,
        string $operator,
        string $second
    ): self {
        return $this->join($table, $first, $operator, $second, "LEFT");
    }

    /**
     * Right join another table
     */
    public function rightJoin(
        string $table,
        string $first,
        string $operator,
        string $second
    ): self {
        return $this->join($table, $first, $operator, $second, "RIGHT");
    }

    /**
     * Add a GROUP BY clause
     */
    public function groupBy(string ...$columns): self
    {
        $this->groupBy = array_merge($this->groupBy, $columns);
        return $this;
    }

    /**
     * Add a HAVING clause
     */
    public function having(string $column, string $operator, mixed $value): self
    {
        $paramName = "having" . $this->paramCounter++;
        $placeholder = ":" . $paramName;
        $this->having = "$column $operator $placeholder";
        $this->params[$placeholder] = $value;
        return $this;
    }

    /**
     * Start a database transaction
     */
    public function beginTransaction(): self
    {
        if (!$this->inTransaction) {
            $this->pdo->beginTransaction();
            $this->inTransaction = true;
        }
        return $this;
    }

    /**
     * Commit the active database transaction
     */
    public function commit(): self
    {
        if ($this->inTransaction) {
            $this->pdo->commit();
            $this->inTransaction = false;
        }
        return $this;
    }

    /**
     * Rollback the active database transaction
     */
    public function rollback(): self
    {
        if ($this->inTransaction) {
            $this->pdo->rollBack();
            $this->inTransaction = false;
        }
        return $this;
    }

    public function exists(): bool
    {
        $this->select = ['1'];
        $this->limit = 1;

        $stmt = $this->prepareStatement();
        $stmt->execute($this->params);

        return (bool) $stmt->fetchColumn();
    }

    public function reset(): self
    {
        $this->select = [];
        $this->where = [];
        $this->params = [];
        $this->joins = [];
        $this->groupBy = [];
        $this->having = null;
        $this->limit = null;
        $this->offset = null;
        return $this;
    }

    /**
     * Execute a function within a transaction
     */
    public function transaction(callable $callback): mixed
    {
        $this->beginTransaction();

        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (\Exception $e) {
            $this->rollback();
            throw $e;
        }
    }

    /**
     * @throws \ReflectionException
     */
    private function getPrimaryKey(): ?string
    {
        $reflection = new \ReflectionClass(Model::class);
        foreach ($reflection->getProperties() as $property) {
            $attributes = $property->getAttributes(Column::class);
            if (
                !empty($attributes) &&
                $attributes[0]->getArguments()["primary"] === true
            ) {
                return $property->getName();
            }
        }
        return null;
    }

    /**
     * Count the number of records
     */
    public function count(string $column = "*"): int
    {
        return $this->aggregate("COUNT", $column);
    }

    /**
     * Get the sum of a column
     */
    public function sum(string $column): float
    {
        return $this->aggregate("SUM", $column);
    }

    /**
     * Get the average of a column
     */
    public function avg(string $column): float
    {
        return $this->aggregate("AVG", $column);
    }

    /**
     * Get the minimum value of a column
     */
    public function min(string $column): float
    {
        return $this->aggregate("MIN", $column);
    }

    /**
     * Get the maximum value of a column
     */
    public function max(string $column): float
    {
        return $this->aggregate("MAX", $column);
    }

    /**
     * Execute an aggregate function on the database
     */
    private function aggregate(string $function, string $column): mixed
    {
        $this->select = ["$function($column) as aggregate"];

        $stmt = $this->prepareStatement();
        $stmt->execute($this->params);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result["aggregate"] ?? 0 : 0;
    }

    private function prepareStatement(): PDOStatement
    {
        $sql = "SELECT " . implode(", ", $this->select ?: ["*"]);
        $sql .= " FROM $this->table";

        // Add joins if any
        if (!empty($this->joins)) {
            $sql .= " " . implode(" ", $this->joins);
        }

        if (!empty($this->where)) {
            $sql .= " WHERE " . implode(" AND ", $this->where);
        }

        // Add GROUP BY if any
        if (!empty($this->groupBy)) {
            $sql .= " GROUP BY " . implode(", ", $this->groupBy);
        }

        // Add HAVING if any
        if ($this->having) {
            $sql .= " HAVING $this->having";
        }

        if ($this->orderBy) {
            $sql .= " ORDER BY $this->orderBy";
        }

        if ($this->limit) {
            $sql .= " LIMIT $this->limit";
        }

        // Add OFFSET if any
        if ($this->offset) {
            $sql .= " OFFSET $this->offset";
        }

        if ($this->lockForUpdate) {
            $driver = $this->pdo->getPdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
            if (in_array($driver, ['mysql', 'pgsql'])) {
                $sql .= " FOR UPDATE";
            }
        }

        return $this->pdo->prepare($sql);
    }

    public function table(): string
    {
        return $this->table;
    }

    public function createTable(
        string $tableName,
        array $columns,
        bool $ifNotExists = false
    ): string {
        return $this->createTableSql = sprintf(
            "CREATE TABLE %s%s (\n%s\n)",
            $ifNotExists ? 'IF NOT EXISTS ' : '',
            $tableName,
            implode(",\n", array_map(
                fn ($name, $def) => "  $name $def",
                array_keys($columns),
                $columns
            ))
        );
    }

    public function createIndex(
        string $indexName,
        array $columns,
        bool $unique = false
    ): string {
        return sprintf(
            "CREATE %sINDEX %s ON %s (%s)",
            $unique ? 'UNIQUE ' : '',
            $indexName,
            $this->table,
            implode(', ', $columns)
        );
    }

    public function dropTable(string $tableName): string
    {
        $this->dropTableSql = "DROP TABLE IF EXISTS $tableName";
        return $this->dropTableSql;
    }

    public function execute(string $sql): void
    {
        $this->pdo->exec($sql);
    }

    public function getSql(): string
    {
        return $this->createTableSql ?? $this->dropTableSql ?? "";
    }
}
