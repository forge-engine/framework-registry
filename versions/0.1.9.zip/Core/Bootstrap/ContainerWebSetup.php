<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

use Forge\CLI\Application;
use Forge\Core\Config\Config;
use Forge\Core\Config\Environment;
use Forge\Core\DI\Container;
use Forge\Core\Session\Drivers\FileSessionDriver;
use Forge\Core\Session\Session;
use Forge\Core\Session\SessionInterface;

final class ContainerWebSetup
{
    private static bool $containerLoaded = false;

    public static function setup(): Container
    {
        $env = Environment::getInstance();
        $container = Container::getInstance();
        $container->singleton(Config::class, function () {
            return new Config(BASE_PATH . '/config');
        });

        $container->singleton(Application::class, function () use ($container) {
            $application = Application::getInstance($container);
            return $application;
        });

        $container->singleton(SessionInterface::class, function () {
            $fileDriver = new FileSessionDriver();
            return new Session($fileDriver);
        });

        DatabaseSetup::setup($container, $env);
        ModuleSetup::loadModules($container);
        ServiceDiscoverSetup::setup($container);

        return $container;
    }

    public static function initOnce(): Container
    {
        if (!self::$containerLoaded) {
            $container = self::setup();
            self::$containerLoaded = true;
            return $container;
        }
        return Container::getInstance();
    }
}
