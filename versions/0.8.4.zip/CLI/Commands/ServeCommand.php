<?php

declare(strict_types=1);

namespace Forge\CLI\Commands;

use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\Wizard;
use Forge\Core\Bootstrap\ModuleSetup;
use Forge\Core\Services\ModuleAssetManager;

#[Cli(
    command: 'serve',
    description: 'Start the PHP Development Server',
    usage: 'serve [--host=localhost] [--port=8000]',
    examples: [
        'serve',
        'serve --host=127.0.0.1 --port=8080'
    ]
)]
final class ServeCommand extends Command
{
    use Wizard;

    #[Arg(
        name: 'host',
        description: 'Server host (default: localhost)',
        default: 'localhost',
        required: false
    )]
    private string $host;
    #[Arg(
        name: 'port',
        description: 'Server port (default: 8000)',
        default: '8000',
        required: false,
        validate: '/^\d{2,5}$/'
    )]
    private string $port;

    public function __construct(private readonly ModuleAssetManager $moduleAssetManager)
    {
    }

    public function execute(array $args): int
    {
        $this->wizard($args);

        if (PHP_SAPI === 'cli') {
            ModuleSetup::compileHooks();
        }

        $this->linkAssets();

        $publicDir = BASE_PATH . "/public";
        $this->info("Server running on http://{$this->host}:{$this->port}");
        passthru("php -S {$this->host}:{$this->port} -t $publicDir");

        return 0;
    }

    private function linkAssets(): void
    {
        $this->moduleAssetManager::initialize();
        $this->info("Assets cache regenerated");
    }
}