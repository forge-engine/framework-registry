<?php

declare(strict_types=1);

namespace Forge\Core\Database\Attributes;

use Attribute;
use InvalidArgumentException;

#[Attribute(Attribute::TARGET_PROPERTY)]
final class Column
{
    public function __construct(
        public string $name,
        public string $type,
        public bool $nullable = false,
        public mixed $default = null,
        public bool $unique = false,
        public bool $primaryKey = false,
        public bool $autoIncrement = false,
        public ?array $enum = null
    ) {
        if ($this->type === 'UUID' && $this->autoIncrement) {
            throw new InvalidArgumentException("UUID columns cannont be auto-incremented");
        }
    }
}
