<?php

declare(strict_types=1);

namespace Forge\Core\Http\Middlewares;

use Forge\Core\Database\QueryBuilder;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Traits\ResponseHelper;

#[Service]
class ApiKeyMiddleware extends Middleware
{
    use ResponseHelper;

    public function __construct(private QueryBuilder $queryBuilder)
    {
    }

    public function handle(Request $request, callable $next): Response
    {
        $apiKey = $request->getHeader('X-API-KEY', null);
        $requiredPermissions = $request->getAttribute('required_permissions', []);

        if (!$apiKey) {
            return $this->createResponse($request, 'Unauthorized: API key missing', 401);
        }

        $queryBuilder = $this->queryBuilder->reset()->setTable('api_keys');
        $keyRecord = $queryBuilder->setTable('api_keys')
            ->select('id')
            ->where('api_key', '=', $apiKey)
            ->first();

        if (!$keyRecord) {
            return $this->createResponse($request, 'Unauthorized: Invalid API key', 401);
        }

        $resolvedPermissions = [];
        foreach ($requiredPermissions as $permissionName) {
            $queryBuilder = $this->queryBuilder->reset()->setTable('api_key_permissions');
            $hasPermission = $queryBuilder->setTable('api_key_permissions')
                ->join('permissions', 'api_key_permissions.permission_id', '=', 'permissions.id')
                ->where('api_key_permissions.api_key_id', '=', $keyRecord['id'])
                ->where('permissions.name', '=', $permissionName)
                ->exists();

            if (!$hasPermission) {
                return $this->createResponse($request, 'Unauthorized: Insufficient Permissions', 403);
            }
            $resolvedPermissions[] = $permissionName;
        }

        $request->setAttribute('api_key_permissions', $resolvedPermissions);

        return $next($request);
    }
}
