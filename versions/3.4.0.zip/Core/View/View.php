<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\DI\Container;
use Forge\Core\Helpers\ModuleHelper;
use Forge\Core\Http\Response;
use Forge\Core\Structure\StructureResolver;
use RuntimeException;

final class View
{
  private static ?array $layout = null;
  private static bool $shouldSuppressLayout = false;
  private static array $sections = [];
  private static string $currentSection = "";
  private static array $slots = [];

  public static function suppressLayout(bool $suppress = true): void
  {
    self::$shouldSuppressLayout = $suppress;
  }

  public function __construct(
    private readonly Container $container,
    private ?string $viewPath = null,
    private ?string $componentPath = null,
    private readonly ?string $module = null
  ) {
    $basePath = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 5);

    if ($viewPath === null || $componentPath === null) {
      $structureResolver = $container->has(StructureResolver::class)
        ? $container->get(StructureResolver::class)
        : null;

      if ($structureResolver) {
        try {
          $this->viewPath = $viewPath ?? BASE_PATH . '/' . $structureResolver->getAppPath('views');
          $this->componentPath = $componentPath ?? BASE_PATH . '/' . $structureResolver->getAppPath('components');
        } catch (\InvalidArgumentException $e) {
          $this->viewPath = $viewPath ?? $basePath . "/app/resources/views";
          $this->componentPath = $componentPath ?? $basePath . "/app/resources/components";
        }
      } else {
        $this->viewPath = $viewPath ?? $basePath . "/app/resources/views";
        $this->componentPath = $componentPath ?? $basePath . "/app/resources/components";
      }
    } else {
      $this->viewPath = $viewPath;
      $this->componentPath = $componentPath;
    }
  }

  public static function layout(string $name, bool $loadFromModule = false, ?string $moduleName = null): void
  {
    if (self::$shouldSuppressLayout) {
      return;
    }
    self::$layout = [
      'name' => $name,
      'useModulePath' => $loadFromModule,
      'moduleName' => $moduleName
    ];
  }

  public static function startSection(string $name): void
  {
    self::$currentSection = $name;
    ob_start();
  }

  public static function endSection(): void
  {
    self::$sections[self::$currentSection] = ob_get_clean();
    self::$currentSection = "";
  }

  public static function section(string $name): string
  {
    return self::$sections[$name] ?? "";
  }

  public static function slot(string $name = 'default', string $default = ''): string
  {
    if (!isset(self::$slots[$name])) {
      return $default;
    }

    $slot = self::$slots[$name];

    return is_callable($slot)
      ? (string) $slot()
      : (string) $slot;
  }

  public static function component(string $name, array|object $props = [], bool $loadFromModule = false): string
  {
    return Component::render($name, $props, $loadFromModule);
  }

  public function render(string $view, array $data = []): Response
  {
    $viewContent = $this->compileView($view, $data);

    if (self::$layout) {
      $layoutName = self::$layout['name'];
      $useModulePath = self::$layout['useModulePath'] ?? false;
      $moduleName = self::$layout['moduleName'] ?? null;

      $layoutData = array_merge($data, ["content" => $viewContent], self::$sections);

      if ($moduleName) {
        $layoutFile = $this->resolveViewFile("{$moduleName}:layouts/{$layoutName}");
        $viewContent = $this->executeFile($layoutFile, $layoutData);
      } elseif ($useModulePath || str_contains($layoutName, ':')) {
        $layoutFile = $this->resolveViewFile("layouts/{$layoutName}");
        $viewContent = $this->executeFile($layoutFile, $layoutData);
      } else {
        $structureResolver = $this->container->has(StructureResolver::class)
          ? $this->container->get(StructureResolver::class)
          : null;

        if ($structureResolver) {
          try {
            $appViewsPath = $structureResolver->getAppPath('views');
            $appViewPath = BASE_PATH . '/' . $appViewsPath;
          } catch (\InvalidArgumentException $e) {
            $appViewPath = defined('BASE_PATH') ? BASE_PATH . "/app/resources/views" : $this->viewPath;
          }
        } else {
          $appViewPath = defined('BASE_PATH') ? BASE_PATH . "/app/resources/views" : $this->viewPath;
        }
        $layoutFile = $this->resolveViewFile("layouts/{$layoutName}", $appViewPath);
        $viewContent = $this->executeFile($layoutFile, $layoutData);
      }
    }

    self::$layout = null;
    self::$shouldSuppressLayout = false;
    self::$sections = [];
    self::$currentSection = "";

    return new Response($viewContent);
  }

  private function compileView(string $view, array $data, ?string $basePath = null): string
  {
    $viewFile = $this->resolveViewFile($view, $basePath);
    return $this->executeFile($viewFile, $data);
  }

  private function resolveViewFile(string $view, ?string $basePath = null): string
  {
    $structureResolver = $this->container->has(StructureResolver::class)
      ? $this->container->get(StructureResolver::class)
      : null;

    if (str_contains($view, ":")) {
      [$module, $relative] = explode(":", $view, 2);
      if (ModuleHelper::isModuleDisabled($module)) {
        throw new RuntimeException("View file not found: {$view} (Module {$module} is disabled)");
      }

      if ($structureResolver) {
        try {
          $moduleViewsPath = $structureResolver->getModulePath($module, 'views');
          $modulePath = BASE_PATH . "/modules/{$module}/{$moduleViewsPath}/{$relative}.php";
          if (is_file($modulePath)) {
            return $modulePath;
          }
        } catch (\InvalidArgumentException $e) {
        }
      }

      foreach (['Resources', 'resources'] as $res) {
        $modulePath = BASE_PATH . "/modules/{$module}/src/{$res}/views/{$relative}.php";
        if (is_file($modulePath)) {
          return $modulePath;
        }
      }
    }

    if ($this->module) {
      if (ModuleHelper::isModuleDisabled($this->module)) {
        throw new RuntimeException("View file not found: {$view} (Module {$this->module} is disabled)");
      }

      if ($structureResolver) {
        try {
          $moduleViewsPath = $structureResolver->getModulePath($this->module, 'views');
          $modulePath = BASE_PATH . "/modules/{$this->module}/{$moduleViewsPath}/{$view}.php";
          if (is_file($modulePath)) {
            return $modulePath;
          }
        } catch (\InvalidArgumentException $e) {
        }
      }

      foreach (['Resources', 'resources'] as $res) {
        $modulePath = BASE_PATH . "/modules/{$this->module}/src/{$res}/views/{$view}.php";
        if (is_file($modulePath)) {
          return $modulePath;
        }
      }
    }

    $basePath = $basePath ?? $this->viewPath;
    $file = "{$basePath}/{$view}.php";

    if (!is_file($file)) {
      throw new RuntimeException("View file not found: {$view} (Searched in: {$file})");
    }

    return $file;
  }

  private function executeFile(string $file, array|object|null $data): string
  {
    $vars = is_object($data) ? get_object_vars($data) : $data;
    if (!empty($vars)) {
      extract($vars, EXTR_SKIP);
    }

    if (is_object($data)) {
      $props = $data;
    } else {
      $props = $data ?? [];
    }

    ob_start();
    try {
      include $file;
      return ob_get_clean();
    } catch (\Throwable $e) {
      $buffer = ob_get_clean();
      throw new \RuntimeException(
        "Error rendering view [{$file}]: {$e->getMessage()}\n\nBuffer Content:\n{$buffer}",
        (int) $e->getCode(),
        $e
      );
    }
  }

  public static function viewComponent(string $path, array|object|null $props = [], ?string $module = null, array $slots = []): string
  {
    $view = new self(container: Container::getInstance(), module: $module);
    $processedSlots = $view->processSlots($slots);
    return $view->renderComponentView($path, $props, $processedSlots);
  }

  private function processSlots(array $slots): array
  {
    if (empty($slots)) {
      return [];
    }

    $processed = [];

    foreach ($slots as $name => $content) {
      if (is_array($content) && isset($content['name'])) {
        $processed[$name] = function () use ($content) {
          $componentName = $content['name'];
          $componentProps = $content['props'] ?? [];
          $componentSlots = $content['slots'] ?? [];

          $componentModule = null;
          if (str_contains($componentName, ':')) {
            [$componentModule, $componentName] = explode(':', $componentName, 2);
          }

          $nestedSlots = $this->processSlots($componentSlots);

          return $this->renderComponentView(
            $componentName,
            $componentProps,
            $nestedSlots,
            $componentModule
          );
        };

        continue;
      }

      $processed[$name] = fn() => (string) $content;
    }

    return $processed;
  }

  public function renderComponentView(
    string $viewSubPath,
    array|object|null $data = [],
    array $slots = [],
    ?string $module = null
  ): string {
    $previousSlots = self::$slots;
    self::$slots = $slots;

    $view = $module !== null
      ? new self(container: $this->container, module: $module)
      : $this;

    $file = $view->resolveComponentFile($viewSubPath, $view->module);
    $result = $view->executeFile($file, $data);

    self::$slots = $previousSlots;

    return $result;
  }

  private function resolveComponentFile(string $component, ?string $module = null): string
  {
    $structureResolver = $this->container->has(StructureResolver::class)
      ? $this->container->get(StructureResolver::class)
      : null;

    if (str_contains($component, ":")) {
      [$moduleName, $relative] = explode(":", $component, 2);
      if (ModuleHelper::isModuleDisabled($moduleName)) {
        throw new RuntimeException("Module component template not found: {$relative} in module {$moduleName} (Module is disabled)");
      }

      if ($structureResolver) {
        try {
          $moduleComponentsPath = $structureResolver->getModulePath($moduleName, 'components');
          $moduleViewsPath = $structureResolver->getModulePath($moduleName, 'views');
          $paths = [
            BASE_PATH . "/modules/{$moduleName}/{$moduleComponentsPath}/{$relative}.php",
            BASE_PATH . "/modules/{$moduleName}/{$moduleViewsPath}/components/{$relative}.php",
          ];
          foreach ($paths as $file) {
            if (is_file($file)) {
              return $file;
            }
          }
        } catch (\InvalidArgumentException $e) {
        }
      }

      foreach (['Resources', 'resources'] as $res) {
        $paths = [
          BASE_PATH . "/modules/{$moduleName}/src/{$res}/components/{$relative}.php",
          BASE_PATH . "/modules/{$moduleName}/src/{$res}/views/components/{$relative}.php",
        ];
        foreach ($paths as $file) {
          if (is_file($file)) {
            return $file;
          }
        }
      }
      throw new RuntimeException("Module component template not found: {$relative} in module {$moduleName}");
    }

    if ($module) {
      if (ModuleHelper::isModuleDisabled($module)) {
        throw new RuntimeException("Component template not found: {$component} (Module {$module} is disabled)");
      }

      if ($structureResolver) {
        try {
          $moduleComponentsPath = $structureResolver->getModulePath($module, 'components');
          $moduleViewsPath = $structureResolver->getModulePath($module, 'views');
          $paths = [
            BASE_PATH . "/modules/{$module}/{$moduleComponentsPath}/{$component}.php",
            BASE_PATH . "/modules/{$module}/{$moduleViewsPath}/components/{$component}.php",
          ];
          foreach ($paths as $file) {
            if (is_file($file)) {
              return $file;
            }
          }
        } catch (\InvalidArgumentException $e) {
        }
      }

      foreach (['Resources', 'resources'] as $res) {
        $paths = [
          BASE_PATH . "/modules/{$module}/src/{$res}/components/{$component}.php",
          BASE_PATH . "/modules/{$module}/src/{$res}/views/components/{$component}.php",
        ];
        foreach ($paths as $file) {
          if (is_file($file)) {
            return $file;
          }
        }
      }
    }

    $file = "{$this->componentPath}/{$component}.php";
    if (is_file($file))
      return $file;

    throw new RuntimeException("Component template not found: {$component}");
  }
}
