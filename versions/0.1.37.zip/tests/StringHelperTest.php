<?php

declare(strict_types=1);

namespace Forge\Tests;

use App\Modules\ForgeTesting\Attributes\Group;
use App\Modules\ForgeTesting\Attributes\Test;
use App\Modules\ForgeTesting\TestCase;
use Forge\Core\Helpers\Strings;

#[Group('helpers')]
final class StringHelperTest extends TestCase
{
    #[Test('String converted to camelCase')]
    public function string_to_camel_case(): void
    {
        $expected = 'thisIsATest';
        $actual = Strings::toCamelCase('this is a test');
        $this->assertEquals($expected, $actual);
    }

    #[Test('String converted to PascalCase')]
    public function string_to_pascal_case(): void
    {
        $expected = 'ThisIsATest';
        $actual = Strings::toPascalCase('this is a test');
        $this->assertEquals($expected, $actual);
    }

    #[Test('String converted to_snake_case')]
    public function string_to_snake_case(): void
    {
        $expected = 'this_is_a_test';
        $actual = Strings::slugify('this is a test', '_');
        $this->assertEquals($expected, $actual);
    }

    #[Test('String converted to-friendly-url')]
    public function string_to_friendly_url(): void
    {
        $expected = 'this-is-a-test';
        $actual = Strings::slugify('this is a test');
        $this->assertEquals($expected, $actual);
    }

    #[Test('String converted to plural')]
    public function string_to_plural(): void
    {
        $expected = 'tests';
        $actual = Strings::toPlural('test');
        $this->assertEquals($expected, $actual);
    }

    #[Test('Truncate string to spesified length')]
    public function truncate_string(): void
    {
        $string = 'this is just some random test';
        $expected = 'this...';
        $actual = Strings::truncate($string, 4);
        $this->assertEquals($expected, $actual);
    }

    #[Test('Truncate should fail')]
    public function truncate_string_should_fail(): void
    {
        $string = 'this is just some random test';
        $expected = 'this...';
        $actual = Strings::truncate($string, 10);
        $this->shouldFail(function () use ($expected, $actual) {
            $this->assertEquals($expected, $actual);
        });
    }

    #[Test('String to Title Case')]
    public function string_to_title_case(): void
    {
        $string = 'this is a test';
        $expected = 'This Is A Test';
        $actual = Strings::toTitleCase($string);
        $this->assertEquals($expected, $actual);
    }

    #[Test('is camelCase')]
    public function string_is_camel_case(): void
    {
        $string = 'isCamelCase';
        $expected = Strings::isCamelCase($string);
        $this->assertTrue($expected);
    }

    #[Test('is PascalCase')]
    public function string_is_pascal_case(): void
    {
        $string = 'IsPascalCase';
        $expected = Strings::isPascalCase($string);
        $this->assertTrue($expected);
    }

    #[Test('is snake_case')]
    public function string_is_snake_case(): void
    {
        $string = 'is_snake_case';
        $expected = Strings::isSnakeCase($string);
        $this->assertTrue($expected);
    }

    #[Test('is kebab-case')]
    public function string_is_kebab_case(): void
    {
        $string = 'is-kebab-case';
        $expected = Strings::isKebabCase($string);
        $this->assertTrue($expected);
    }
}
