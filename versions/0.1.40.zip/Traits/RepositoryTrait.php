<?php

namespace Forge\Traits;

use Forge\Core\Database\QueryBuilder;
use Forge\Core\DI\Container;

trait RepositoryTrait
{
    // protected static ?string $dtoClass = null;
    // protected static array $searchableFields = [];
    // protected static array $propertiesToSanitize = [];
    use PaginationHelper;

    protected static function query(): QueryBuilder
    {
        /*** @var QueryBuilder $queryBuilder */
        $queryBuilder = Container::getInstance()->get(QueryBuilder::class);
        $queryBuilder->reset()->setTable(static::getTable());
        return $queryBuilder;
    }

    /** @return static[]|BaseDto[] */
    public static function findAll(): array
    {
        return static::fetch(static::query()->select("*"));
    }

    public static function findById(mixed $id): static|null
    {
        $result = static::query()
            ->where(static::getPrimaryKey(), '=', $id)
            ->first();

        return new static($result);
    }

    public static function findBy(string $property, mixed $value): static|null
    {
        $result = static::query()
            ->where($property, '=', $value)
            ->first();
        if ($result) {
            return new static($result);
        } else {
            return null;
        }
    }

    private static function applySearch(QueryBuilder $query, string $search): void
    {
        $searchTerms = array_map(fn ($field) => "$field LIKE :search", static::$searchableFields);
        $query->whereRaw('(' . implode(' OR ', $searchTerms) . ')', [
            'search' => "%$search%"
        ]);
    }

    private static function getTotalCount(QueryBuilder $baseQuery): int
    {
        $countQuery = clone $baseQuery;
        return $countQuery
            ->select(static::getModelPrimaryKey())
            ->count();
    }

    protected static function getModelPrimaryKey(): string
    {
        return self::getPrimaryKey();
    }

    public static function paginate(
        int $page,
        int $perPage,
        string $column = 'created_at',
        string $direction = 'ASC',
        string $search = ''
    ): array {
        $offset = ($page - 1) * $perPage;
        $query = static::query();

        $baseQuery = clone $query;

        if ($search && static::$searchableFields) {
            static::applySearch($baseQuery, $search);
        }

        $dataQuery = clone $baseQuery;
        $results = static::fetch(
            $dataQuery
                ->select("*")
                ->limit($perPage)
                ->offset($offset)
                ->orderBy($column, $direction)
        );

        $items = $results;

        $total = static::getTotalCount($baseQuery);

        return static::formatPaginationResult(
            $items,
            $total,
            $page,
            $perPage,
            $column,
            $direction,
            $search
        );
    }

    private static function formatPaginationResult(
        array $items,
        int $total,
        int $page,
        int $perPage,
        string $column,
        string $direction,
        string $search
    ): array {
        $totalPages = (int) ceil($total / $perPage);

        return [
            'data' => $items,
            'meta' => [
                'total' => $total,
                'page' => $page,
                'perPage' => $perPage,
                'totalPages' => $totalPages,
                'links' => static::getPaginationLinks(
                    $page,
                    $perPage,
                    $totalPages,
                    $column,
                    $direction,
                    $search
                )
            ]
        ];
    }

    protected static function fetch(QueryBuilder $query): array
    {
        $results = $query->get();
        $items = [];
        if (is_array($results)) {
            foreach ($results as $result) {
                $dtoClass = static::$dtoClass ?? null;
                if ($dtoClass && class_exists($dtoClass)) {
                    $dto = new $dtoClass($result);
                    $items[] = static::sanitizeDto($dto);
                } else {
                    $items[] = $result;
                }
            }
        } elseif ($results) {
            $dtoClass = static::$dtoClass ?? null;
            if ($dtoClass && class_exists($dtoClass)) {
                $dto = new $dtoClass($results);
                $items[] = static::sanitizeDto($dto);
            } else {
                $items[] = $results;
            }
        }
        return $items;
    }
}
