<?php

declare(strict_types=1);

use Forge\Core\Config\Environment;

/**
    * Get the environment instance.
    *
    * @return mixed
    */
    if (!function_exists("env")) {
        function env(string $key, mixed $default = null): mixed
        {
            return Environment::getInstance()->get($key) ?? $default;
        }
    }


/**
 * Escape HTML entities in a string.
 *
 * @param string $value The string to escape.
 * @return string Returns the escaped string.
 */
if (!function_exists("e")) {
    function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
    }
}
/**
 * Output a value without escaping.
 *
 * @param mixed $value The value to output raw.
 * @return string Returns the raw string representation of the value.
 */
if (!function_exists("raw")) {
    function raw(mixed $value): string
    {
        return (string)$value;
    }
}
