<?php

declare(strict_types=1);

namespace Forge\Core\Database\Enums;

use Forge\Traits\EnumHelper;

enum ActiveStatus: string
{
    use EnumHelper;

    case ACTIVE = 'ACTIVE';
    case COMPLETED = 'DELETED';
    case PENDING_DELETION = 'PENDING_DELETION';
    case ARCHIVED = 'ARCHIVED';
}
